import gzip
import os

def decompress_csv_gzip(gzip_file_path, output_file_path=None):
    """
    解压缩 .csv.gzip 文件
    
    Args:
        gzip_file_path: 输入的 .csv.gzip 文件路径
        output_file_path: 输出的 .csv 文件路径，如果为None则自动生成
    """
    if output_file_path is None:
        # 自动生成输出文件名（移除.gzip后缀）
        output_file_path = gzip_file_path.replace('.gzip', '')
    
    try:
        with gzip.open(gzip_file_path, 'rt', encoding='utf-8') as f_in:
            with open(output_file_path, 'w', encoding='utf-8') as f_out:
                f_out.write(f_in.read())
        
        print(f"成功解压: {gzip_file_path} -> {output_file_path}")
        
        # 显示文件大小信息
        original_size = os.path.getsize(gzip_file_path)
        decompressed_size = os.path.getsize(output_file_path)
        print(f"原始文件大小: {original_size / 1024:.2f} KB")
        print(f"解压后大小: {decompressed_size / 1024:.2f} KB")
        
    except Exception as e:
        print(f"解压失败: {e}")

if __name__ == "__main__":
    # 解压 features.csv.gzip 文件
    gzip_file = "features.csv.gzip"
    
    if os.path.exists(gzip_file):
        decompress_csv_gzip(gzip_file)
    else:
        print(f"文件不存在: {gzip_file}")