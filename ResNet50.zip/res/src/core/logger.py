"""
日志系统 - 提供结构化日志记录和监控

遵循单一职责原则，专注于日志记录和管理功能。
"""

import logging
import logging.handlers
import json
import sys
import traceback
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone
from .config import LoggingConfig
from .exceptions import ConfigurationError


class StructuredFormatter(logging.Formatter):
    """结构化日志格式化器"""
    
    def __init__(self, include_extra_fields: bool = True):
        super().__init__()
        self.include_extra_fields = include_extra_fields
    
    def format(self, record: logging.LogRecord) -> str:
        """格式化日志记录"""
        log_data = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # 添加异常信息
        if record.exc_info:
            log_data["exception"] = {
                "type": record.exc_info[0].__name__,
                "message": str(record.exc_info[1]),
                "traceback": traceback.format_exception(*record.exc_info)
            }
        
        # 添加额外字段
        if self.include_extra_fields and hasattr(record, '__dict__'):
            extra_fields = {}
            for key, value in record.__dict__.items():
                if key not in ['name', 'msg', 'args', 'levelname', 'levelno', 'pathname', 
                              'filename', 'module', 'lineno', 'funcName', 'created', 
                              'msecs', 'relativeCreated', 'thread', 'threadName', 
                              'processName', 'process', 'message', 'exc_info', 'exc_text', 
                              'stack_info']:
                    try:
                        # 确保值可以JSON序列化
                        json.dumps(value)
                        extra_fields[key] = value
                    except (TypeError, ValueError):
                        extra_fields[key] = str(value)
            
            if extra_fields:
                log_data["extra"] = extra_fields
        
        return json.dumps(log_data, ensure_ascii=False, separators=(',', ':'))


class ConsoleFormatter(logging.Formatter):
    """控制台日志格式化器 - 人类可读格式"""
    
    COLORS = {
        'DEBUG': '\033[36m',    # 青色
        'INFO': '\033[32m',     # 绿色
        'WARNING': '\033[33m',  # 黄色
        'ERROR': '\033[31m',    # 红色
        'CRITICAL': '\033[35m'  # 紫色
    }
    RESET = '\033[0m'
    
    def __init__(self, use_colors: bool = True):
        super().__init__()
        self.use_colors = use_colors and hasattr(sys.stderr, 'isatty') and sys.stderr.isatty()
    
    def format(self, record: logging.LogRecord) -> str:
        """格式化控制台日志"""
        timestamp = datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S')
        level = record.levelname
        logger_name = record.name.split('.')[-1]  # 只显示最后一部分
        message = record.getMessage()
        
        # 添加颜色
        if self.use_colors and level in self.COLORS:
            level = f"{self.COLORS[level]}{level}{self.RESET}"
        
        base_msg = f"{timestamp} | {level:8} | {logger_name:15} | {message}"
        
        # 添加异常信息
        if record.exc_info:
            base_msg += f"\n{self.formatException(record.exc_info)}"
        
        # 添加重要的额外信息
        if hasattr(record, 'error_code'):
            base_msg += f" [错误代码: {record.error_code}]"
        
        if hasattr(record, 'file_path'):
            base_msg += f" [文件: {Path(record.file_path).name}]"
        
        return base_msg


class PerformanceLogger:
    """性能日志记录器"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self.timers = {}
    
    def start_timer(self, operation: str) -> None:
        """开始计时"""
        self.timers[operation] = datetime.now()
        self.logger.debug(f"开始操作: {operation}")
    
    def end_timer(self, operation: str, extra_info: Dict[str, Any] = None) -> float:
        """结束计时并记录"""
        if operation not in self.timers:
            self.logger.warning(f"未找到操作的开始时间: {operation}")
            return 0.0
        
        start_time = self.timers.pop(operation)
        duration = (datetime.now() - start_time).total_seconds()
        
        log_data = {
            "operation": operation,
            "duration_seconds": duration,
            "performance_metric": True
        }
        
        if extra_info:
            log_data.update(extra_info)
        
        self.logger.info(f"完成操作: {operation} (耗时: {duration:.2f}秒)", extra=log_data)
        return duration


class LogManager:
    """日志管理器 - 遵循单一职责原则"""
    
    def __init__(self):
        self.loggers: Dict[str, logging.Logger] = {}
        self.performance_loggers: Dict[str, PerformanceLogger] = {}
        self._configured = False
    
    def configure_logging(self, config: LoggingConfig) -> None:
        """配置日志系统"""
        try:
            # 验证配置
            self._validate_logging_config(config)
            
            # 设置根日志级别
            root_logger = logging.getLogger()
            root_logger.setLevel(getattr(logging, config.log_level.upper()))
            
            # 清除现有处理器
            root_logger.handlers.clear()
            
            # 配置控制台处理器
            if config.console_output:
                console_handler = logging.StreamHandler(sys.stdout)
                console_handler.setFormatter(ConsoleFormatter())
                console_handler.setLevel(getattr(logging, config.log_level.upper()))
                root_logger.addHandler(console_handler)
            
            # 配置文件处理器
            if config.log_file:
                self._setup_file_handler(root_logger, config)
            
            self._configured = True
            
            # 记录配置完成信息
            logger = self.get_logger("LogManager")
            logger.info("日志系统配置完成", extra={
                "log_level": config.log_level,
                "console_output": config.console_output,
                "log_file": config.log_file
            })
            
        except Exception as e:
            raise ConfigurationError("logging", f"配置日志系统失败: {str(e)}")
    
    def get_logger(self, name: str) -> logging.Logger:
        """获取指定名称的日志记录器"""
        if name not in self.loggers:
            self.loggers[name] = logging.getLogger(name)
        return self.loggers[name]
    
    def get_performance_logger(self, name: str) -> PerformanceLogger:
        """获取性能日志记录器"""
        if name not in self.performance_loggers:
            logger = self.get_logger(f"{name}.performance")
            self.performance_loggers[name] = PerformanceLogger(logger)
        return self.performance_loggers[name]
    
    def log_system_info(self, logger_name: str = "SystemInfo") -> None:
        """记录系统信息"""
        logger = self.get_logger(logger_name)
        
        import platform
        import torch
        
        system_info = {
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "pytorch_version": torch.__version__,
            "cuda_available": torch.cuda.is_available(),
        }
        
        if torch.cuda.is_available():
            system_info.update({
                "cuda_version": torch.version.cuda,
                "gpu_count": torch.cuda.device_count(),
                "gpu_name": torch.cuda.get_device_name(0) if torch.cuda.device_count() > 0 else None
            })
        
        logger.info("系统信息", extra={"system_info": system_info})
    
    def create_operation_context(self, operation_name: str, **context) -> 'OperationContext':
        """创建操作上下文，用于跟踪特定操作的日志"""
        return OperationContext(self, operation_name, **context)
    
    def _validate_logging_config(self, config: LoggingConfig) -> None:
        """验证日志配置"""
        valid_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if config.log_level.upper() not in valid_levels:
            raise ValueError(f"无效的日志级别: {config.log_level}")
        
        if config.log_file:
            log_file_path = Path(config.log_file)
            try:
                log_file_path.parent.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                raise ValueError(f"无法创建日志文件目录: {str(e)}")
    
    def _setup_file_handler(self, root_logger: logging.Logger, config: LoggingConfig) -> None:
        """设置文件处理器"""
        log_file_path = Path(config.log_file)
        
        # 使用旋转文件处理器
        file_handler = logging.handlers.RotatingFileHandler(
            filename=log_file_path,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        
        file_handler.setFormatter(StructuredFormatter())
        file_handler.setLevel(getattr(logging, config.log_level.upper()))
        root_logger.addHandler(file_handler)


class OperationContext:
    """操作上下文 - 用于跟踪特定操作的日志"""
    
    def __init__(self, log_manager: LogManager, operation_name: str, **context):
        self.log_manager = log_manager
        self.operation_name = operation_name
        self.context = context
        self.logger = log_manager.get_logger(f"Operation.{operation_name}")
        self.performance_logger = log_manager.get_performance_logger(operation_name)
        self.errors: List[Exception] = []
    
    def __enter__(self):
        """进入上下文"""
        self.logger.info(f"开始操作: {self.operation_name}", extra=self.context)
        self.performance_logger.start_timer(self.operation_name)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出上下文"""
        duration = self.performance_logger.end_timer(self.operation_name, self.context)
        
        if exc_type is not None:
            self.logger.error(
                f"操作失败: {self.operation_name}",
                extra={**self.context, "error_count": len(self.errors)},
                exc_info=(exc_type, exc_val, exc_tb)
            )
        else:
            self.logger.info(
                f"操作完成: {self.operation_name}",
                extra={**self.context, "duration": duration, "error_count": len(self.errors)}
            )
    
    def log_progress(self, message: str, **extra):
        """记录进度信息"""
        self.logger.info(message, extra={**self.context, **extra})
    
    def log_error(self, error: Exception, **extra):
        """记录错误"""
        self.errors.append(error)
        self.logger.error(f"操作中发生错误: {str(error)}", extra={**self.context, **extra}, exc_info=error)
    
    def log_warning(self, message: str, **extra):
        """记录警告"""
        self.logger.warning(message, extra={**self.context, **extra})


# 全局日志管理器实例
log_manager = LogManager()