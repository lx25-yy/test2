"""
自定义异常类 - 提供明确的错误分类和处理

遵循单一职责原则，每个异常类专注于特定类型的错误场景。
"""


class DICOMFeatureExtractionError(Exception):
    """DICOM特征提取系统的基础异常类"""
    
    def __init__(self, message: str, error_code: str = None, details: dict = None):
        super().__init__(message)
        self.message = message
        self.error_code = error_code or "UNKNOWN_ERROR"
        self.details = details or {}
    
    def __str__(self):
        return f"[{self.error_code}] {self.message}"


class DICOMLoadError(DICOMFeatureExtractionError):
    """DICOM文件加载相关错误"""
    
    def __init__(self, file_path: str, message: str, error_code: str = "DICOM_LOAD_ERROR"):
        super().__init__(
            message=f"无法加载DICOM文件 '{file_path}': {message}",
            error_code=error_code,
            details={"file_path": file_path}
        )


class DICOMValidationError(DICOMFeatureExtractionError):
    """DICOM文件验证错误"""
    
    def __init__(self, file_path: str, validation_issues: list, error_code: str = "DICOM_VALIDATION_ERROR"):
        issues_str = "; ".join(validation_issues)
        super().__init__(
            message=f"DICOM文件验证失败 '{file_path}': {issues_str}",
            error_code=error_code,
            details={"file_path": file_path, "validation_issues": validation_issues}
        )


class ImagePreprocessingError(DICOMFeatureExtractionError):
    """图像预处理错误"""
    
    def __init__(self, image_info: str, processing_step: str, message: str, error_code: str = "PREPROCESSING_ERROR"):
        super().__init__(
            message=f"图像预处理失败 ({image_info}) 在步骤 '{processing_step}': {message}",
            error_code=error_code,
            details={"image_info": image_info, "processing_step": processing_step}
        )


class FeatureExtractionError(DICOMFeatureExtractionError):
    """特征提取错误"""
    
    def __init__(self, model_info: str, layer_name: str, message: str, error_code: str = "FEATURE_EXTRACTION_ERROR"):
        super().__init__(
            message=f"特征提取失败 (模型: {model_info}, 层: {layer_name}): {message}",
            error_code=error_code,
            details={"model_info": model_info, "layer_name": layer_name}
        )


class BatchProcessingError(DICOMFeatureExtractionError):
    """批处理错误"""
    
    def __init__(self, batch_info: str, message: str, error_code: str = "BATCH_PROCESSING_ERROR"):
        super().__init__(
            message=f"批处理失败 ({batch_info}): {message}",
            error_code=error_code,
            details={"batch_info": batch_info}
        )


class MemoryError(DICOMFeatureExtractionError):
    """内存相关错误"""
    
    def __init__(self, operation: str, memory_info: dict, error_code: str = "MEMORY_ERROR"):
        super().__init__(
            message=f"内存不足，无法执行操作 '{operation}'",
            error_code=error_code,
            details={"operation": operation, "memory_info": memory_info}
        )


class OutputError(DICOMFeatureExtractionError):
    """输出保存错误"""
    
    def __init__(self, output_path: str, output_format: str, message: str, error_code: str = "OUTPUT_ERROR"):
        super().__init__(
            message=f"输出失败 (路径: {output_path}, 格式: {output_format}): {message}",
            error_code=error_code,
            details={"output_path": output_path, "output_format": output_format}
        )


class ConfigurationError(DICOMFeatureExtractionError):
    """配置错误"""
    
    def __init__(self, config_key: str, message: str, error_code: str = "CONFIGURATION_ERROR"):
        super().__init__(
            message=f"配置错误 '{config_key}': {message}",
            error_code=error_code,
            details={"config_key": config_key}
        )


class ModelError(DICOMFeatureExtractionError):
    """模型相关错误"""
    
    def __init__(self, model_name: str, operation: str, message: str, error_code: str = "MODEL_ERROR"):
        super().__init__(
            message=f"模型错误 ({model_name}) 在操作 '{operation}': {message}",
            error_code=error_code,
            details={"model_name": model_name, "operation": operation}
        )


class PipelineError(DICOMFeatureExtractionError):
    """流水线执行错误"""
    
    def __init__(self, pipeline_stage: str, message: str, error_code: str = "PIPELINE_ERROR"):
        super().__init__(
            message=f"流水线错误在阶段 '{pipeline_stage}': {message}",
            error_code=error_code,
            details={"pipeline_stage": pipeline_stage}
        )


class ResourceError(DICOMFeatureExtractionError):
    """资源相关错误（GPU、文件系统等）"""
    
    def __init__(self, resource_type: str, resource_info: str, message: str, error_code: str = "RESOURCE_ERROR"):
        super().__init__(
            message=f"资源错误 ({resource_type}: {resource_info}): {message}",
            error_code=error_code,
            details={"resource_type": resource_type, "resource_info": resource_info}
        )


def handle_exception_with_logging(logger, exception: Exception, context: dict = None):
    """
    统一的异常处理和日志记录函数
    
    Args:
        logger: 日志记录器
        exception: 捕获的异常
        context: 额外的上下文信息
    """
    context = context or {}
    
    if isinstance(exception, DICOMFeatureExtractionError):
        error_details = {
            "error_code": exception.error_code,
            "error_details": exception.details,
            "context": context
        }
        logger.error(f"系统错误: {exception}", extra=error_details)
    else:
        error_details = {
            "error_type": type(exception).__name__,
            "context": context
        }
        logger.error(f"未预期错误: {exception}", extra=error_details)


def create_error_summary(errors: list) -> dict:
    """
    创建错误摘要，用于最终报告
    
    Args:
        errors: 错误列表
    
    Returns:
        错误摘要字典
    """
    error_summary = {
        "total_errors": len(errors),
        "error_types": {},
        "critical_errors": [],
        "error_details": []
    }
    
    for error in errors:
        if isinstance(error, DICOMFeatureExtractionError):
            error_type = error.error_code
            error_summary["error_types"][error_type] = error_summary["error_types"].get(error_type, 0) + 1
            
            if error_type in ["MEMORY_ERROR", "MODEL_ERROR", "RESOURCE_ERROR"]:
                error_summary["critical_errors"].append(str(error))
            
            error_summary["error_details"].append({
                "type": error_type,
                "message": error.message,
                "details": error.details
            })
        else:
            error_type = type(error).__name__
            error_summary["error_types"][error_type] = error_summary["error_types"].get(error_type, 0) + 1
            error_summary["error_details"].append({
                "type": error_type,
                "message": str(error),
                "details": {}
            })
    
    return error_summary