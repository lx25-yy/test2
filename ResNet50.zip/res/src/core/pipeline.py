# -*- coding: utf-8 -*-
"""
Core pipeline orchestration system

Implements the main processing pipeline that integrates all components.
"""

import os
import time
import traceback
import numpy as np
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Callable, Tuple
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field

from .interfaces import (
    IDICOMLoader, IImagePreprocessor, IFeatureExtractor, 
    IBatchManager, IOutputManager, IPipelineOrchestrator,
    ExtractionResult
)
from .exceptions import (
    PipelineError, DICOMLoadError, ImagePreprocessingError, 
    FeatureExtractionError, BatchProcessingError, OutputError,
    handle_exception_with_logging, create_error_summary
)
from .logger import log_manager
from .config import SystemConfig

from ..data.loaders import DICOMLoaderFactory
from ..data.preprocessors import PreprocessorFactory
from ..models.feature_extractors import FeatureExtractorFactory
from ..processing.batch_factory import BatchProcessingFactory
from ..output.output_manager import FeatureOutputManager
from ..output.data_structures import (
    FeatureRecord, FeatureDataset, OutputConfig, OutputFormat, CompressionType
)


@dataclass
class PipelineStage:
    """流水线阶段定义"""
    name: str
    description: str
    is_critical: bool = True  # 是否为关键阶段（失败则停止）
    retry_count: int = 0      # 重试次数
    timeout_seconds: Optional[float] = None  # 超时时间


@dataclass
class PipelineConfig:
    """流水线配置"""
    # 输入配置
    input_directory: str
    file_patterns: List[str] = field(default_factory=lambda: ["*.dcm", "*.DCM"])
    recursive_scan: bool = True
    
    # 处理配置
    target_layer: str = "layer4.2.conv3"
    image_size: Tuple[int, int] = (224, 224)
    normalize_method: str = "imagenet"
    device: str = "auto"
    
    # 批处理配置
    batch_size: Optional[int] = None  # None表示自动优化
    enable_batch_optimization: bool = True
    memory_threshold: float = 0.85
    
    # 输出配置
    output_directory: str = "extracted_features"
    output_formats: List[OutputFormat] = field(default_factory=lambda: [OutputFormat.NUMPY])
    compression: CompressionType = CompressionType.GZIP
    filename_prefix: str = "features"
    
    # 错误处理配置
    continue_on_error: bool = True
    max_error_rate: float = 0.5  # 最大错误率，超过则停止
    save_error_log: bool = True
    
    # 性能配置
    enable_progress_monitoring: bool = True
    save_intermediate_results: bool = False
    validate_outputs: bool = True


@dataclass
class StageResult:
    """阶段执行结果"""
    stage_name: str
    success: bool
    execution_time: float
    items_processed: int
    items_succeeded: int
    items_failed: int
    error_messages: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    stage_data: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def success_rate(self) -> float:
        """成功率"""
        if self.items_processed == 0:
            return 0.0
        return self.items_succeeded / self.items_processed
    
    @property
    def processing_rate(self) -> float:
        """处理速度（items/sec）"""
        if self.execution_time <= 0:
            return 0.0
        return self.items_processed / self.execution_time


@dataclass
class PipelineResult:
    """流水线执行结果"""
    success: bool
    total_execution_time: float
    stage_results: List[StageResult]
    input_files_found: int
    input_files_processed: int
    features_extracted: int
    output_files_created: List[str]
    error_summary: Dict[str, Any]
    warnings: List[str] = field(default_factory=list)
    
    @property
    def overall_success_rate(self) -> float:
        """整体成功率"""
        if self.input_files_processed == 0:
            return 0.0
        return self.features_extracted / self.input_files_processed
    
    def get_stage_result(self, stage_name: str) -> Optional[StageResult]:
        """获取指定阶段的结果"""
        for result in self.stage_results:
            if result.stage_name == stage_name:
                return result
        return None


class IPipelineStage(ABC):
    """流水线阶段接口"""
    
    @abstractmethod
    def execute(self, context: Dict[str, Any], config: PipelineConfig) -> StageResult:
        """执行阶段"""
        pass
    
    @abstractmethod
    def get_stage_info(self) -> PipelineStage:
        """获取阶段信息"""
        pass
    
    @abstractmethod
    def cleanup(self, context: Dict[str, Any]):
        """清理资源"""
        pass


class FileScanStage(IPipelineStage):
    """文件扫描阶段"""
    
    def __init__(self):
        self.logger = log_manager.get_logger(self.__class__.__name__)
    
    def get_stage_info(self) -> PipelineStage:
        return PipelineStage(
            name="file_scan",
            description="扫描和发现DICOM文件",
            is_critical=True,
            retry_count=2
        )
    
    def execute(self, context: Dict[str, Any], config: PipelineConfig) -> StageResult:
        """扫描输入目录中的DICOM文件"""
        start_time = time.time()
        
        try:
            with log_manager.create_operation_context("file_scan"):
                input_dir = Path(config.input_directory)
                
                if not input_dir.exists():
                    raise PipelineError("file_scan", f"Input directory does not exist: {input_dir}")
                
                if not input_dir.is_dir():
                    raise PipelineError("file_scan", f"Input path is not a directory: {input_dir}")
                
                # 扫描文件
                found_files = []
                
                for pattern in config.file_patterns:
                    if config.recursive_scan:
                        pattern_files = list(input_dir.rglob(pattern))
                    else:
                        pattern_files = list(input_dir.glob(pattern))
                    
                    found_files.extend(pattern_files)
                
                # 去重并转换为字符串路径
                unique_files = list(set(str(f) for f in found_files))
                unique_files.sort()  # 确保顺序一致
                
                context['input_files'] = unique_files
                
                execution_time = time.time() - start_time
                
                self.logger.info(f"File scan completed: {len(unique_files)} files found in {execution_time:.2f}s")
                
                return StageResult(
                    stage_name="file_scan",
                    success=True,
                    execution_time=execution_time,
                    items_processed=len(unique_files),
                    items_succeeded=len(unique_files),
                    items_failed=0,
                    stage_data={'found_files': unique_files}
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = f"File scan failed: {str(e)}"
            self.logger.error(error_msg)
            
            return StageResult(
                stage_name="file_scan",
                success=False,
                execution_time=execution_time,
                items_processed=0,
                items_succeeded=0,
                items_failed=1,
                error_messages=[error_msg]
            )
    
    def cleanup(self, context: Dict[str, Any]):
        """清理资源"""
        pass


class ComponentInitializationStage(IPipelineStage):
    """组件初始化阶段"""
    
    def __init__(self):
        self.logger = log_manager.get_logger(self.__class__.__name__)
    
    def get_stage_info(self) -> PipelineStage:
        return PipelineStage(
            name="component_init",
            description="初始化所有处理组件",
            is_critical=True,
            retry_count=1
        )
    
    def execute(self, context: Dict[str, Any], config: PipelineConfig) -> StageResult:
        """初始化所有处理组件"""
        start_time = time.time()
        errors = []
        warnings = []
        
        try:
            with log_manager.create_operation_context("component_init"):
                
                # 1. 初始化DICOM加载器
                try:
                    dicom_loader = DICOMLoaderFactory.create_standard_loader()
                    context['dicom_loader'] = dicom_loader
                    self.logger.info("DICOM loader initialized")
                except Exception as e:
                    error_msg = f"Failed to initialize DICOM loader: {str(e)}"
                    errors.append(error_msg)
                    self.logger.error(error_msg)
                
                # 2. 初始化图像预处理器
                try:
                    preprocessor = PreprocessorFactory.create_resnet_preprocessor(
                        target_size=config.image_size,
                        normalize_method=config.normalize_method
                    )
                    context['preprocessor'] = preprocessor
                    self.logger.info("Image preprocessor initialized")
                except Exception as e:
                    error_msg = f"Failed to initialize preprocessor: {str(e)}"
                    errors.append(error_msg)
                    self.logger.error(error_msg)
                
                # 3. 初始化特征提取器
                try:
                    feature_extractor = FeatureExtractorFactory.create_resnet50_extractor(
                        target_layer=config.target_layer,
                        device=config.device
                    )
                    context['feature_extractor'] = feature_extractor
                    self.logger.info(f"Feature extractor initialized (device: {feature_extractor.device})")
                except Exception as e:
                    error_msg = f"Failed to initialize feature extractor: {str(e)}"
                    errors.append(error_msg)
                    self.logger.error(error_msg)
                
                # 4. 初始化批处理管理器
                try:
                    batch_config = {
                        'initial_batch_size': config.batch_size or 8,
                        'auto_optimize': config.enable_batch_optimization,
                        'memory_threshold': config.memory_threshold
                    }
                    batch_manager = BatchProcessingFactory.create_batch_manager(batch_config)
                    context['batch_manager'] = batch_manager
                    self.logger.info("Batch manager initialized")
                except Exception as e:
                    error_msg = f"Failed to initialize batch manager: {str(e)}"
                    errors.append(error_msg)
                    self.logger.error(error_msg)
                
                # 5. 初始化输出管理器
                try:
                    output_manager = FeatureOutputManager()
                    context['output_manager'] = output_manager
                    self.logger.info("Output manager initialized")
                except Exception as e:
                    error_msg = f"Failed to initialize output manager: {str(e)}"
                    errors.append(error_msg)
                    self.logger.error(error_msg)
                
                # 6. 创建处理策略
                try:
                    if 'dicom_loader' in context and 'preprocessor' in context and 'feature_extractor' in context:
                        processing_strategy = BatchProcessingFactory.create_dicom_processing_strategy(
                            context['dicom_loader'],
                            context['preprocessor'],
                            context['feature_extractor']
                        )
                        context['processing_strategy'] = processing_strategy
                        self.logger.info("Processing strategy created")
                    else:
                        errors.append("Cannot create processing strategy: missing required components")
                except Exception as e:
                    error_msg = f"Failed to create processing strategy: {str(e)}"
                    errors.append(error_msg)
                    self.logger.error(error_msg)
                
                execution_time = time.time() - start_time
                success = len(errors) == 0
                
                return StageResult(
                    stage_name="component_init",
                    success=success,
                    execution_time=execution_time,
                    items_processed=6,  # 6个组件
                    items_succeeded=6 - len(errors),
                    items_failed=len(errors),
                    error_messages=errors,
                    warnings=warnings
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = f"Component initialization failed: {str(e)}"
            self.logger.error(error_msg)
            
            return StageResult(
                stage_name="component_init",
                success=False,
                execution_time=execution_time,
                items_processed=0,
                items_succeeded=0,
                items_failed=1,
                error_messages=[error_msg]
            )
    
    def cleanup(self, context: Dict[str, Any]):
        """清理资源"""
        # 清理GPU内存
        if 'feature_extractor' in context:
            try:
                context['feature_extractor'].clear_cache()
            except:
                pass


class FeatureExtractionStage(IPipelineStage):
    """特征提取阶段"""
    
    def __init__(self):
        self.logger = log_manager.get_logger(self.__class__.__name__)
    
    def get_stage_info(self) -> PipelineStage:
        return PipelineStage(
            name="feature_extraction",
            description="批量特征提取处理",
            is_critical=True,
            timeout_seconds=3600  # 1小时超时
        )
    
    def execute(self, context: Dict[str, Any], config: PipelineConfig) -> StageResult:
        """执行特征提取"""
        start_time = time.time()
        
        try:
            with log_manager.create_operation_context("feature_extraction"):
                
                # 获取必要组件
                input_files = context.get('input_files', [])
                batch_manager = context.get('batch_manager')
                processing_strategy = context.get('processing_strategy')
                
                if not input_files:
                    raise PipelineError("feature_extraction", "No input files available")
                
                if not batch_manager:
                    raise PipelineError("feature_extraction", "Batch manager not initialized")
                
                if not processing_strategy:
                    raise PipelineError("feature_extraction", "Processing strategy not initialized")
                
                # 开始批处理会话
                batch_manager.start_processing_session(len(input_files))
                
                try:
                    # 执行批处理
                    results = batch_manager.process_batch(input_files, processing_strategy)
                    
                    # 统计结果
                    successful_results = [r for r in results if r.get('features') is not None]
                    
                    # 创建特征数据集
                    feature_records = []
                    for result in successful_results:
                        record = FeatureRecord(
                            file_path=result['file_path'],
                            features=result['features'],
                            feature_dimensions=result['feature_shape'],
                            metadata=result.get('metadata', {}),
                            extraction_timestamp=datetime.now(),
                            processing_time=0.0,  # 批处理中无法单独计时
                            success=True
                        )
                        feature_records.append(record)
                    
                    # 添加失败记录
                    failed_files = set(input_files) - set(r['file_path'] for r in successful_results)
                    for failed_file in failed_files:
                        record = FeatureRecord(
                            file_path=failed_file,
                            features=np.array([]),
                            feature_dimensions=(0,),
                            metadata={},
                            extraction_timestamp=datetime.now(),
                            processing_time=0.0,
                            success=False,
                            error_message="Feature extraction failed"
                        )
                        feature_records.append(record)
                    
                    dataset = FeatureDataset(feature_records)
                    context['feature_dataset'] = dataset
                    
                    execution_time = time.time() - start_time
                    
                    # 检查错误率
                    error_rate = 1.0 - dataset.success_rate
                    if error_rate > config.max_error_rate:
                        self.logger.warning(f"Error rate ({error_rate:.1%}) exceeds threshold ({config.max_error_rate:.1%})")
                    
                    self.logger.info(f"Feature extraction completed: {len(successful_results)}/{len(input_files)} successful")
                    
                    return StageResult(
                        stage_name="feature_extraction",
                        success=True,
                        execution_time=execution_time,
                        items_processed=len(input_files),
                        items_succeeded=len(successful_results),
                        items_failed=len(input_files) - len(successful_results),
                        stage_data={'feature_dataset': dataset}
                    )
                    
                finally:
                    batch_manager.end_processing_session()
                
        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = f"Feature extraction failed: {str(e)}"
            self.logger.error(error_msg)
            
            return StageResult(
                stage_name="feature_extraction",
                success=False,
                execution_time=execution_time,
                items_processed=len(context.get('input_files', [])),
                items_succeeded=0,
                items_failed=len(context.get('input_files', [])),
                error_messages=[error_msg]
            )
    
    def cleanup(self, context: Dict[str, Any]):
        """清理资源"""
        if 'batch_manager' in context:
            try:
                context['batch_manager'].end_processing_session()
            except:
                pass


class OutputStage(IPipelineStage):
    """输出阶段"""
    
    def __init__(self):
        self.logger = log_manager.get_logger(self.__class__.__name__)
    
    def get_stage_info(self) -> PipelineStage:
        return PipelineStage(
            name="output",
            description="保存特征到多种格式",
            is_critical=False,  # 输出失败不算致命
            retry_count=2
        )
    
    def execute(self, context: Dict[str, Any], config: PipelineConfig) -> StageResult:
        """执行输出保存"""
        start_time = time.time()
        
        try:
            with log_manager.create_operation_context("output"):
                
                dataset = context.get('feature_dataset')
                output_manager = context.get('output_manager')
                
                if not dataset:
                    raise PipelineError("output", "No feature dataset available")
                
                if not output_manager:
                    raise PipelineError("output", "Output manager not initialized")
                
                # 创建输出配置
                output_configs = []
                for output_format in config.output_formats:
                    output_config = OutputConfig(
                        format=output_format,
                        output_path=config.output_directory,
                        filename_prefix=config.filename_prefix,
                        compression=config.compression,
                        validate_output=config.validate_outputs
                    )
                    output_configs.append(output_config)
                
                # 执行多格式输出
                output_results = output_manager.save_features_multi_format(dataset, output_configs)
                
                # 统计结果
                successful_formats = [name for name, result in output_results.items() if result.success]
                failed_formats = [name for name, result in output_results.items() if not result.success]
                
                all_output_files = []
                for result in output_results.values():
                    all_output_files.extend(result.output_files)
                    all_output_files.extend(result.metadata_files)
                
                context['output_files'] = all_output_files
                context['output_results'] = output_results
                
                execution_time = time.time() - start_time
                
                self.logger.info(f"Output completed: {len(successful_formats)}/{len(config.output_formats)} formats successful")
                
                return StageResult(
                    stage_name="output",
                    success=len(successful_formats) > 0,  # 至少一种格式成功
                    execution_time=execution_time,
                    items_processed=len(config.output_formats),
                    items_succeeded=len(successful_formats),
                    items_failed=len(failed_formats),
                    error_messages=[f"Failed format: {fmt}" for fmt in failed_formats],
                    stage_data={'output_files': all_output_files, 'output_results': output_results}
                )
                
        except Exception as e:
            execution_time = time.time() - start_time
            error_msg = f"Output stage failed: {str(e)}"
            self.logger.error(error_msg)
            
            return StageResult(
                stage_name="output",
                success=False,
                execution_time=execution_time,
                items_processed=len(config.output_formats),
                items_succeeded=0,
                items_failed=len(config.output_formats),
                error_messages=[error_msg]
            )
    
    def cleanup(self, context: Dict[str, Any]):
        """清理资源"""
        pass


class DICOMFeaturePipeline(IPipelineOrchestrator):
    """
    DICOM特征提取流水线编排器
    
    集成所有组件，实现完整的处理流程和错误处理。
    """
    
    def __init__(self, system_config: Optional[SystemConfig] = None):
        """
        初始化流水线
        
        Args:
            system_config: 系统配置
        """
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.system_config = system_config
        
        # 定义流水线阶段
        self.stages = [
            FileScanStage(),
            ComponentInitializationStage(),
            FeatureExtractionStage(),
            OutputStage()
        ]
        
        # 执行上下文
        self.context = {}
        
        self.logger.info("DICOM feature pipeline initialized")
    
    def execute_pipeline(self, input_path: str, output_path: str, 
                        config: Dict[str, Any]) -> ExtractionResult:
        """
        执行完整的特征提取流水线
        
        Args:
            input_path: 输入路径
            output_path: 输出路径
            config: 流水线配置
            
        Returns:
            提取结果
        """
        pipeline_start_time = time.time()
        
        with log_manager.create_operation_context("pipeline_execution"):
            
            try:
                # 创建流水线配置
                pipeline_config = self._create_pipeline_config(input_path, output_path, config)
                
                # 初始化上下文
                self.context = {'config': pipeline_config}
                
                # 执行各个阶段
                stage_results = []
                
                for stage in self.stages:
                    stage_info = stage.get_stage_info()
                    
                    self.logger.info(f"Starting stage: {stage_info.name}")
                    
                    try:
                        # 执行阶段
                        result = self._execute_stage_with_retry(stage, stage_info, pipeline_config)
                        stage_results.append(result)
                        
                        if result.success:
                            self.logger.info(f"Stage {stage_info.name} completed successfully: "
                                           f"{result.items_succeeded}/{result.items_processed} items")
                        else:
                            self.logger.error(f"Stage {stage_info.name} failed: {result.error_messages}")
                            
                            # 如果是关键阶段且失败，停止执行
                            if stage_info.is_critical:
                                self.logger.error(f"Critical stage {stage_info.name} failed, stopping pipeline")
                                break
                    
                    except Exception as e:
                        error_msg = f"Stage {stage_info.name} execution error: {str(e)}"
                        self.logger.error(error_msg)
                        
                        failed_result = StageResult(
                            stage_name=stage_info.name,
                            success=False,
                            execution_time=0.0,
                            items_processed=0,
                            items_succeeded=0,
                            items_failed=1,
                            error_messages=[error_msg]
                        )
                        stage_results.append(failed_result)
                        
                        if stage_info.is_critical:
                            break
                
                # 清理所有阶段
                self._cleanup_stages()
                
                # 创建流水线结果
                pipeline_result = self._create_pipeline_result(
                    stage_results, time.time() - pipeline_start_time
                )
                
                # 转换为ExtractionResult格式
                extraction_result = self._convert_to_extraction_result(pipeline_result)
                
                self.logger.info(f"Pipeline execution completed: "
                               f"success={extraction_result.successful_extractions > 0}, "
                               f"time={extraction_result.processing_time:.2f}s")
                
                return extraction_result
                
            except Exception as e:
                self.logger.error(f"Pipeline execution failed: {str(e)}")
                traceback.print_exc()
                
                # 清理资源
                self._cleanup_stages()
                
                # 返回失败结果
                return ExtractionResult(
                    total_images=0,
                    successful_extractions=0,
                    failed_extractions=0,
                    feature_dimensions=(0,),
                    processing_time=time.time() - pipeline_start_time,
                    output_files=[],
                    error_log=[f"Pipeline execution failed: {str(e)}"]
                )
    
    def validate_pipeline_components(self) -> bool:
        """验证流水线组件完整性"""
        try:
            # 检查各个工厂是否可用
            loaders_available = True
            try:
                DICOMLoaderFactory.create_standard_loader()
            except Exception:
                loaders_available = False
            
            preprocessors_available = True
            try:
                PreprocessorFactory.create_resnet_preprocessor()
            except Exception:
                preprocessors_available = False
            
            extractors_available = True
            try:
                FeatureExtractorFactory.create_resnet50_extractor(device='cpu')
            except Exception:
                extractors_available = False
            
            batch_available = True
            try:
                BatchProcessingFactory.create_batch_manager()
            except Exception:
                batch_available = False
            
            output_available = True
            try:
                FeatureOutputManager()
            except Exception:
                output_available = False
            
            all_available = all([
                loaders_available, preprocessors_available, extractors_available,
                batch_available, output_available
            ])
            
            self.logger.info(f"Pipeline component validation: "
                           f"loaders={loaders_available}, "
                           f"preprocessors={preprocessors_available}, "
                           f"extractors={extractors_available}, "
                           f"batch={batch_available}, "
                           f"output={output_available}")
            
            return all_available
            
        except Exception as e:
            self.logger.error(f"Pipeline validation failed: {e}")
            return False
    
    def _create_pipeline_config(self, input_path: str, output_path: str, 
                               config: Dict[str, Any]) -> PipelineConfig:
        """创建流水线配置"""
        return PipelineConfig(
            input_directory=input_path,
            output_directory=output_path,
            file_patterns=config.get('file_patterns', ['*.dcm', '*.DCM']),
            target_layer=config.get('target_layer', 'layer4.2.conv3'),
            image_size=tuple(config.get('image_size', [224, 224])),
            normalize_method=config.get('normalize_method', 'imagenet'),
            device=config.get('device', 'auto'),
            batch_size=config.get('batch_size'),
            enable_batch_optimization=config.get('enable_batch_optimization', True),
            output_formats=[OutputFormat(fmt) for fmt in config.get('output_formats', ['numpy'])],
            compression=CompressionType(config.get('compression', 'gzip')),
            filename_prefix=config.get('filename_prefix', 'features'),
            continue_on_error=config.get('continue_on_error', True),
            max_error_rate=config.get('max_error_rate', 0.5),
            validate_outputs=config.get('validate_outputs', True)
        )
    
    def _execute_stage_with_retry(self, stage: IPipelineStage, 
                                 stage_info: PipelineStage, 
                                 config: PipelineConfig) -> StageResult:
        """带重试的阶段执行"""
        last_exception = None
        
        for attempt in range(stage_info.retry_count + 1):
            try:
                if attempt > 0:
                    self.logger.info(f"Retrying stage {stage_info.name}, attempt {attempt + 1}")
                
                result = stage.execute(self.context, config)
                
                if result.success:
                    return result
                else:
                    last_exception = Exception(f"Stage failed: {result.error_messages}")
                    
            except Exception as e:
                last_exception = e
                self.logger.warning(f"Stage {stage_info.name} attempt {attempt + 1} failed: {str(e)}")
        
        # 所有重试都失败了
        if last_exception:
            raise last_exception
        else:
            raise Exception(f"Stage {stage_info.name} failed after {stage_info.retry_count + 1} attempts")
    
    def _cleanup_stages(self):
        """清理所有阶段的资源"""
        for stage in self.stages:
            try:
                stage.cleanup(self.context)
            except Exception as e:
                self.logger.warning(f"Failed to cleanup stage {stage.__class__.__name__}: {e}")
    
    def _create_pipeline_result(self, stage_results: List[StageResult], 
                               total_time: float) -> PipelineResult:
        """创建流水线结果"""
        # 统计整体结果
        overall_success = all(result.success for result in stage_results 
                            if self.stages[stage_results.index(result)].get_stage_info().is_critical)
        
        input_files = len(self.context.get('input_files', []))
        features_extracted = 0
        output_files = []
        
        # 从特征提取阶段获取信息
        for result in stage_results:
            if result.stage_name == 'feature_extraction':
                features_extracted = result.items_succeeded
            elif result.stage_name == 'output':
                output_files = result.stage_data.get('output_files', [])
        
        # 收集所有错误
        all_errors = []
        all_warnings = []
        for result in stage_results:
            all_errors.extend(result.error_messages)
            all_warnings.extend(result.warnings)
        
        error_summary = create_error_summary([Exception(msg) for msg in all_errors])
        
        return PipelineResult(
            success=overall_success,
            total_execution_time=total_time,
            stage_results=stage_results,
            input_files_found=input_files,
            input_files_processed=input_files,
            features_extracted=features_extracted,
            output_files_created=output_files,
            error_summary=error_summary,
            warnings=all_warnings
        )
    
    def _convert_to_extraction_result(self, pipeline_result: PipelineResult) -> ExtractionResult:
        """转换为标准的提取结果格式"""
        # 获取特征维度
        feature_dims = (2048,)  # 默认ResNet50维度
        if 'feature_dataset' in self.context:
            dataset = self.context['feature_dataset']
            if dataset.records:
                successful_record = next((r for r in dataset.records if r.success), None)
                if successful_record:
                    feature_dims = successful_record.feature_dimensions
        
        # 计算基于唯一文件的统计信息
        total_unique_files = pipeline_result.input_files_found
        successful_unique_files = 0
        failed_unique_files = 0
        
        if 'feature_dataset' in self.context:
            dataset = self.context['feature_dataset']
            # 统计唯一文件的成功和失败数量
            unique_files = set()
            unique_successful_files = set()
            
            for record in dataset.records:
                unique_files.add(record.file_path)
                if record.success:
                    unique_successful_files.add(record.file_path)
            
            successful_unique_files = len(unique_successful_files)
            failed_unique_files = len(unique_files) - successful_unique_files
            
            # 如果有未处理的文件，也算作失败
            if len(unique_files) < total_unique_files:
                failed_unique_files += total_unique_files - len(unique_files)

        return ExtractionResult(
            total_images=total_unique_files,
            successful_extractions=successful_unique_files,
            failed_extractions=failed_unique_files,
            feature_dimensions=feature_dims,
            processing_time=pipeline_result.total_execution_time,
            output_files=pipeline_result.output_files_created,
            error_log=[msg for result in pipeline_result.stage_results for msg in result.error_messages]
        )