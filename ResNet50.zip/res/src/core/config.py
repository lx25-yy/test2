"""
配置管理系统 - 遵循开闭原则和单一职责原则

支持配置加载、验证、覆盖和扩展，为系统提供灵活的配置机制。
"""

import json
import os
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional, Union
import torch
from dataclasses import dataclass, asdict
from .interfaces import IConfigValidator
from .exceptions import ConfigurationError


@dataclass
class ProcessingConfig:
    """处理相关配置"""
    batch_size: int = 32
    num_workers: int = 4
    device: str = "auto"  # "auto", "cuda", "cpu"
    memory_limit_gb: float = 8.0
    progress_update_interval: int = 10


@dataclass
class ModelConfig:
    """模型相关配置"""
    model_name: str = "resnet50"
    target_layer: str = "layer4.2.conv3"  # conv5_block3_out
    pretrained: bool = True
    model_cache_dir: Optional[str] = None


@dataclass
class ImageConfig:
    """图像处理配置"""
    target_size: Tuple[int, int] = (224, 224)
    normalize_method: str = "imagenet"  # "imagenet", "custom", "none"
    custom_mean: Optional[Tuple[float, float, float]] = None
    custom_std: Optional[Tuple[float, float, float]] = None
    interpolation_mode: str = "bilinear"


@dataclass
class OutputConfig:
    """输出相关配置"""
    output_formats: List[str] = None
    create_metadata: bool = True
    compress_output: bool = False
    backup_original_config: bool = True
    
    def __post_init__(self):
        if self.output_formats is None:
            self.output_formats = ["numpy", "hdf5"]


@dataclass
class LoggingConfig:
    """日志相关配置"""
    log_level: str = "INFO"
    log_file: Optional[str] = None
    log_format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    console_output: bool = True


@dataclass
class SystemConfig:
    """系统完整配置"""
    processing: ProcessingConfig = None
    model: ModelConfig = None
    image: ImageConfig = None
    output: OutputConfig = None
    logging: LoggingConfig = None
    
    def __post_init__(self):
        self.processing = self.processing or ProcessingConfig()
        self.model = self.model or ModelConfig()
        self.image = self.image or ImageConfig()
        self.output = self.output or OutputConfig()
        self.logging = self.logging or LoggingConfig()


class ConfigValidator(IConfigValidator):
    """配置验证器实现 - 遵循单一职责原则"""
    
    def __init__(self):
        self.validation_rules = {
            "processing.batch_size": self._validate_positive_int,
            "processing.num_workers": self._validate_non_negative_int,
            "processing.device": self._validate_device,
            "processing.memory_limit_gb": self._validate_positive_float,
            "model.model_name": self._validate_model_name,
            "model.target_layer": self._validate_layer_name,
            "image.target_size": self._validate_image_size,
            "image.normalize_method": self._validate_normalize_method,
            "output.output_formats": self._validate_output_formats,
        }
    
    def validate_config(self, config: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """验证配置的有效性"""
        errors = []
        
        try:
            # 验证基本结构
            structure_errors = self._validate_config_structure(config)
            errors.extend(structure_errors)
            
            # 验证具体字段
            field_errors = self._validate_config_fields(config)
            errors.extend(field_errors)
            
            # 验证依赖关系
            dependency_errors = self._validate_config_dependencies(config)
            errors.extend(dependency_errors)
            
        except Exception as e:
            errors.append(f"配置验证过程中发生错误: {str(e)}")
        
        return len(errors) == 0, errors
    
    def get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        return asdict(SystemConfig())
    
    def _validate_config_structure(self, config: Dict[str, Any]) -> List[str]:
        """验证配置结构"""
        errors = []
        required_sections = ["processing", "model", "image", "output", "logging"]
        
        for section in required_sections:
            if section not in config:
                errors.append(f"缺少必需的配置段落: {section}")
        
        return errors
    
    def _validate_config_fields(self, config: Dict[str, Any]) -> List[str]:
        """验证配置字段"""
        errors = []
        
        for field_path, validator in self.validation_rules.items():
            try:
                value = self._get_nested_value(config, field_path)
                if value is not None:
                    error = validator(value)
                    if error:
                        errors.append(f"{field_path}: {error}")
            except KeyError:
                # 字段不存在，使用默认值
                pass
            except Exception as e:
                errors.append(f"{field_path}: 验证时发生错误 - {str(e)}")
        
        return errors
    
    def _validate_config_dependencies(self, config: Dict[str, Any]) -> List[str]:
        """验证配置依赖关系"""
        errors = []
        
        # 检查设备相关依赖
        device = self._get_nested_value(config, "processing.device")
        if device == "cuda" and not torch.cuda.is_available():
            errors.append("指定了CUDA设备但CUDA不可用")
        
        # 检查自定义归一化参数
        normalize_method = self._get_nested_value(config, "image.normalize_method")
        if normalize_method == "custom":
            custom_mean = self._get_nested_value(config, "image.custom_mean")
            custom_std = self._get_nested_value(config, "image.custom_std")
            if not custom_mean or not custom_std:
                errors.append("使用自定义归一化时必须提供custom_mean和custom_std")
        
        return errors
    
    def _get_nested_value(self, config: Dict[str, Any], path: str) -> Any:
        """获取嵌套字典中的值"""
        keys = path.split(".")
        value = config
        for key in keys:
            value = value[key]
        return value
    
    # 验证函数
    def _validate_positive_int(self, value: int) -> Optional[str]:
        if not isinstance(value, int) or value <= 0:
            return "必须是正整数"
        return None
    
    def _validate_non_negative_int(self, value: int) -> Optional[str]:
        if not isinstance(value, int) or value < 0:
            return "必须是非负整数"
        return None
    
    def _validate_positive_float(self, value: float) -> Optional[str]:
        if not isinstance(value, (int, float)) or value <= 0:
            return "必须是正数"
        return None
    
    def _validate_device(self, value: str) -> Optional[str]:
        valid_devices = ["auto", "cuda", "cpu"]
        if value not in valid_devices:
            return f"设备必须是 {valid_devices} 之一"
        return None
    
    def _validate_model_name(self, value: str) -> Optional[str]:
        valid_models = ["resnet50", "resnet101", "resnet152"]
        if value not in valid_models:
            return f"模型名称必须是 {valid_models} 之一"
        return None
    
    def _validate_layer_name(self, value: str) -> Optional[str]:
        if not isinstance(value, str) or not value.strip():
            return "层名称不能为空"
        return None
    
    def _validate_image_size(self, value: Tuple[int, int]) -> Optional[str]:
        if not isinstance(value, (list, tuple)) or len(value) != 2:
            return "图像大小必须是包含两个整数的元组或列表"
        if not all(isinstance(x, int) and x > 0 for x in value):
            return "图像大小必须是正整数"
        return None
    
    def _validate_normalize_method(self, value: str) -> Optional[str]:
        valid_methods = ["imagenet", "custom", "none"]
        if value not in valid_methods:
            return f"归一化方法必须是 {valid_methods} 之一"
        return None
    
    def _validate_output_formats(self, value: List[str]) -> Optional[str]:
        if not isinstance(value, list):
            return "输出格式必须是字符串列表"
        valid_formats = ["numpy", "hdf5", "csv"]
        invalid_formats = [fmt for fmt in value if fmt not in valid_formats]
        if invalid_formats:
            return f"不支持的输出格式: {invalid_formats}"
        return None


class ConfigManager:
    """配置管理器 - 遵循单一职责原则和开闭原则"""
    
    def __init__(self, validator: IConfigValidator = None):
        self.validator = validator or ConfigValidator()
        self._config = None
        self._config_source = None
    
    def load_from_file(self, config_path: Union[str, Path]) -> SystemConfig:
        """从文件加载配置"""
        config_path = Path(config_path)
        
        if not config_path.exists():
            raise ConfigurationError("config_file", f"配置文件不存在: {config_path}")
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                if config_path.suffix.lower() == '.json':
                    config_dict = json.load(f)
                else:
                    raise ConfigurationError("config_file", f"不支持的配置文件格式: {config_path.suffix}")
            
            return self._create_config_from_dict(config_dict, str(config_path))
        
        except json.JSONDecodeError as e:
            raise ConfigurationError("config_file", f"JSON格式错误: {str(e)}")
        except Exception as e:
            raise ConfigurationError("config_file", f"加载配置文件失败: {str(e)}")
    
    def load_from_dict(self, config_dict: Dict[str, Any]) -> SystemConfig:
        """从字典加载配置"""
        return self._create_config_from_dict(config_dict, "dictionary")
    
    def get_default_config(self) -> SystemConfig:
        """获取默认配置"""
        default_dict = self.validator.get_default_config()
        return self._create_config_from_dict(default_dict, "default")
    
    def save_config(self, config: SystemConfig, output_path: Union[str, Path]) -> None:
        """保存配置到文件"""
        output_path = Path(output_path)
        config_dict = asdict(config)
        
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(config_dict, f, indent=2, ensure_ascii=False)
        except Exception as e:
            raise ConfigurationError("config_save", f"保存配置失败: {str(e)}")
    
    def merge_configs(self, base_config: SystemConfig, override_config: Dict[str, Any]) -> SystemConfig:
        """合并配置"""
        base_dict = asdict(base_config)
        merged_dict = self._deep_merge_dict(base_dict, override_config)
        return self._create_config_from_dict(merged_dict, "merged")
    
    def _create_config_from_dict(self, config_dict: Dict[str, Any], source: str) -> SystemConfig:
        """从字典创建配置对象"""
        # 验证配置
        is_valid, errors = self.validator.validate_config(config_dict)
        if not is_valid:
            error_msg = "配置验证失败:\n" + "\n".join(f"- {error}" for error in errors)
            raise ConfigurationError("config_validation", error_msg)
        
        # 自动设置设备
        if config_dict.get("processing", {}).get("device") == "auto":
            config_dict["processing"]["device"] = "cuda" if torch.cuda.is_available() else "cpu"
        
        try:
            config = SystemConfig(
                processing=ProcessingConfig(**config_dict.get("processing", {})),
                model=ModelConfig(**config_dict.get("model", {})),
                image=ImageConfig(**config_dict.get("image", {})),
                output=OutputConfig(**config_dict.get("output", {})),
                logging=LoggingConfig(**config_dict.get("logging", {}))
            )
            
            self._config = config
            self._config_source = source
            return config
        
        except TypeError as e:
            raise ConfigurationError("config_creation", f"创建配置对象失败: {str(e)}")
    
    def _deep_merge_dict(self, base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """深度合并字典"""
        result = base.copy()
        
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._deep_merge_dict(result[key], value)
            else:
                result[key] = value
        
        return result
    
    @property
    def current_config(self) -> Optional[SystemConfig]:
        """获取当前配置"""
        return self._config
    
    @property
    def config_source(self) -> Optional[str]:
        """获取配置来源"""
        return self._config_source