"""
核心接口定义 - 遵循依赖倒置原则 (DIP)

此模块定义了系统中所有组件的抽象接口，确保高层模块不依赖低层模块的具体实现。
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Tuple, Iterator, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import numpy as np
import torch


@dataclass
class DICOMImage:
    """DICOM图像数据结构"""
    file_path: str
    pixel_data: np.ndarray
    metadata: Dict[str, Any]
    original_shape: Tuple[int, int, int]
    modality: str
    patient_id: Optional[str] = None


@dataclass
class ExtractedFeature:
    """提取的特征数据结构"""
    source_file: str
    feature_vector: np.ndarray
    feature_shape: Tuple[int, ...]
    extraction_timestamp: datetime
    layer_name: str
    preprocessing_params: Dict[str, Any]


@dataclass
class ExtractionResult:
    """处理结果数据结构"""
    total_images: int
    successful_extractions: int
    failed_extractions: int
    feature_dimensions: Tuple[int, ...]
    processing_time: float
    output_files: List[str]
    error_log: List[str]


class IDICOMLoader(ABC):
    """DICOM加载器接口 - 遵循单一职责原则 (SRP)"""
    
    @abstractmethod
    def load_dicom_file(self, file_path: str) -> DICOMImage:
        """加载单个DICOM文件"""
        pass
    
    @abstractmethod
    def validate_dicom(self, file_path: str) -> bool:
        """验证DICOM文件是否有效"""
        pass
    
    @abstractmethod
    def scan_directory(self, directory_path: str) -> List[str]:
        """扫描目录中的DICOM文件"""
        pass


class IImagePreprocessor(ABC):
    """图像预处理器接口 - 遵循单一职责原则 (SRP)"""
    
    @abstractmethod
    def preprocess_image(self, dicom_image: DICOMImage) -> torch.Tensor:
        """预处理DICOM图像为模型输入格式"""
        pass
    
    @abstractmethod
    def resize_image(self, image: np.ndarray, target_size: Tuple[int, int]) -> np.ndarray:
        """调整图像大小"""
        pass
    
    @abstractmethod
    def normalize_pixels(self, image: np.ndarray) -> np.ndarray:
        """归一化像素值"""
        pass
    
    @abstractmethod
    def convert_to_rgb(self, image: np.ndarray) -> np.ndarray:
        """转换为RGB格式"""
        pass


class IFeatureExtractor(ABC):
    """特征提取器接口 - 遵循开闭原则 (OCP)"""
    
    @abstractmethod
    def extract_features(self, batch: torch.Tensor) -> torch.Tensor:
        """从图像批次中提取特征"""
        pass
    
    @abstractmethod
    def get_feature_dimensions(self) -> Tuple[int, ...]:
        """获取特征维度"""
        pass
    
    @abstractmethod
    def get_layer_name(self) -> str:
        """获取目标层名称"""
        pass


class IBatchManager(ABC):
    """批处理管理器接口 - 遵循单一职责原则 (SRP)"""
    
    @abstractmethod
    def start_processing_session(self, total_items: int) -> None:
        """开始处理会话"""
        pass
    
    @abstractmethod
    def end_processing_session(self) -> None:
        """结束处理会话"""
        pass
    
    @abstractmethod
    def process_batch(self, items: List[Any], processing_strategy: Any) -> List[Any]:
        """处理批次数据"""
        pass
    
    @abstractmethod
    def get_current_stats(self) -> Dict[str, Any]:
        """获取当前统计信息"""
        pass


class IOutputManager(ABC):
    """输出管理器接口 - 遵循开闭原则 (OCP)"""
    
    @abstractmethod
    def save_features(self, features: List[ExtractedFeature], output_path: str) -> List[str]:
        """保存特征到指定路径"""
        pass
    
    @abstractmethod
    def create_metadata_file(self, result: ExtractionResult, output_path: str) -> str:
        """创建元数据文件"""
        pass
    
    @abstractmethod
    def validate_output(self, output_files: List[str]) -> bool:
        """验证输出文件完整性"""
        pass


class IProgressMonitor(ABC):
    """进度监控器接口 - 遵循接口隔离原则 (ISP)"""
    
    @abstractmethod
    def start_task(self, total_items: int, task_name: str) -> None:
        """开始任务"""
        pass
    
    @abstractmethod
    def update_progress(self, completed_items: int, message: str = "") -> None:
        """更新进度"""
        pass
    
    @abstractmethod
    def finish_task(self, success: bool, final_message: str = "") -> None:
        """完成任务"""
        pass


class IConfigValidator(ABC):
    """配置验证器接口 - 遵循单一职责原则 (SRP)"""
    
    @abstractmethod
    def validate_config(self, config: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """验证配置有效性"""
        pass
    
    @abstractmethod
    def get_default_config(self) -> Dict[str, Any]:
        """获取默认配置"""
        pass


class IPipelineOrchestrator(ABC):
    """流水线编排器接口 - 遵循开闭原则 (OCP)"""
    
    @abstractmethod
    def execute_pipeline(self, input_path: str, output_path: str, config: Dict[str, Any]) -> ExtractionResult:
        """执行完整的特征提取流水线"""
        pass
    
    @abstractmethod
    def validate_pipeline_components(self) -> bool:
        """验证流水线组件完整性"""
        pass