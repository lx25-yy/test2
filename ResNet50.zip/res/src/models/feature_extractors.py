# -*- coding: utf-8 -*-
"""
Feature extractors implementation using deep learning models

Implements ResNet50-based feature extraction following SOLID principles.
"""

from abc import ABC
from typing import Dict, Tuple, List, Optional, Union, Any
import torch
import torch.nn as nn
import torchvision.models as models
from torchvision.models.feature_extraction import create_feature_extractor, get_graph_node_names
import numpy as np
from pathlib import Path

from ..core.interfaces import IFeatureExtractor
from ..core.exceptions import FeatureExtractionError, ModelError, ResourceError
from ..core.logger import log_manager


class BaseFeatureExtractor(IFeatureExtractor):
    """
    Base feature extractor implementing common functionality
    
    Follows Single Responsibility Principle by focusing on feature extraction tasks.
    """
    
    def __init__(self, device: str = 'auto'):
        """
        Initialize base feature extractor
        
        Args:
            device: Computing device ('auto', 'cuda', 'cpu')
        """
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.device = self._setup_device(device)
        self.model = None
        self.feature_extractor = None
        self.target_layer = None
        
        # Statistics tracking
        self.stats = {
            'total_extractions': 0,
            'successful_extractions': 0,
            'failed_extractions': 0,
            'total_processing_time': 0.0
        }
    
    def _setup_device(self, device: str) -> torch.device:
        """Setup computing device"""
        if device == 'auto':
            if torch.cuda.is_available():
                device_str = 'cuda'
                self.logger.info(f"CUDA available, using GPU: {torch.cuda.get_device_name(0)}")
            else:
                device_str = 'cpu'
                self.logger.info("CUDA not available, using CPU")
        else:
            device_str = device
        
        torch_device = torch.device(device_str)
        
        # Log device information
        if torch_device.type == 'cuda':
            self.logger.info(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
        
        return torch_device
    
    def get_device_info(self) -> Dict[str, Any]:
        """Get device information"""
        info = {
            'device_type': self.device.type,
            'device_name': str(self.device)
        }
        
        if self.device.type == 'cuda':
            info.update({
                'gpu_name': torch.cuda.get_device_name(0),
                'gpu_memory_total': torch.cuda.get_device_properties(0).total_memory,
                'gpu_memory_allocated': torch.cuda.memory_allocated(self.device),
                'gpu_memory_cached': torch.cuda.memory_reserved(self.device)
            })
        
        return info
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get extraction statistics"""
        stats = self.stats.copy()
        if stats['total_extractions'] > 0:
            stats['success_rate'] = stats['successful_extractions'] / stats['total_extractions']
            stats['average_time_per_extraction'] = stats['total_processing_time'] / stats['total_extractions']
        else:
            stats['success_rate'] = 0.0
            stats['average_time_per_extraction'] = 0.0
        
        return stats
    
    def reset_statistics(self):
        """Reset extraction statistics"""
        self.stats = {
            'total_extractions': 0,
            'successful_extractions': 0,
            'failed_extractions': 0,
            'total_processing_time': 0.0
        }


class ResNet50FeatureExtractor(BaseFeatureExtractor):
    """
    ResNet50-based feature extractor
    
    Extracts features from the conv5_block3_out layer (layer4.2.conv3) of ResNet50.
    """
    
    def __init__(self, 
                 target_layer: str = 'layer4.2.conv3',
                 pretrained: bool = True,
                 device: str = 'auto',
                 weights_path: Optional[str] = None):
        """
        Initialize ResNet50 feature extractor
        
        Args:
            target_layer: Target layer name for feature extraction
            pretrained: Whether to use pretrained weights
            device: Computing device
            weights_path: Path to custom weights file
        """
        super().__init__(device)
        
        self.target_layer = target_layer
        self.pretrained = pretrained
        self.weights_path = weights_path
        
        # Layer mappings for common names
        self.layer_mappings = {
            'conv5_block3_out': 'layer4.2.conv3',
            'conv5_x': 'layer4',
            'conv4_x': 'layer3', 
            'conv3_x': 'layer2',
            'conv2_x': 'layer1',
            'conv1': 'conv1'
        }
        
        # Initialize model
        self._load_model()
        self._create_feature_extractor()
        
        self.logger.info(f"ResNet50 feature extractor initialized")
        self.logger.info(f"Target layer: {self.target_layer}")
        self.logger.info(f"Feature dimensions: {self.get_feature_dimensions()}")
    
    def _load_model(self):
        """Load ResNet50 model"""
        try:
            with log_manager.create_operation_context("load_model"):
                if self.weights_path and Path(self.weights_path).exists():
                    # Load custom weights
                    self.logger.info(f"Loading custom weights from: {self.weights_path}")
                    self.model = models.resnet50(weights=None)
                    checkpoint = torch.load(self.weights_path, map_location=self.device)
                    self.model.load_state_dict(checkpoint)
                else:
                    # Load pretrained model
                    if self.pretrained:
                        self.logger.info("Loading pretrained ResNet50 model")
                        self.model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
                    else:
                        self.logger.info("Loading ResNet50 model without pretrained weights")
                        self.model = models.resnet50(weights=None)
                
                # Move model to device
                self.model = self.model.to(self.device)
                self.model.eval()  # Set to evaluation mode
                
                # Disable gradient computation for inference
                for param in self.model.parameters():
                    param.requires_grad = False
                
                self.logger.info(f"Model loaded successfully on {self.device}")
                
        except Exception as e:
            raise ModelError("ResNet50", "load_model", f"Failed to load model: {str(e)}")
    
    def _create_feature_extractor(self):
        """Create feature extractor from ResNet50 model"""
        try:
            # Map common layer names to actual layer names
            actual_layer = self.layer_mappings.get(self.target_layer, self.target_layer)
            
            # Verify layer exists
            available_nodes = get_graph_node_names(self.model)
            if actual_layer not in available_nodes[0]:  # available_nodes[0] is eval mode nodes
                raise FeatureExtractionError(
                    "ResNet50",
                    actual_layer,
                    f"Layer '{actual_layer}' not found. Available layers: {available_nodes[0][:10]}..."
                )
            
            # Create feature extractor
            self.feature_extractor = create_feature_extractor(
                self.model, 
                return_nodes={actual_layer: 'features'}
            )
            
            self.feature_extractor = self.feature_extractor.to(self.device)
            self.feature_extractor.eval()
            
            self.logger.info(f"Feature extractor created for layer: {actual_layer}")
            
        except FeatureExtractionError:
            raise
        except Exception as e:
            raise FeatureExtractionError(
                "ResNet50", 
                self.target_layer,
                f"Failed to create feature extractor: {str(e)}"
            )
    
    def extract_features(self, batch) -> torch.Tensor:
        """
        Extract features from a batch of images
        
        Args:
            batch: Input tensor/array of shape (N, C, H, W)
                  Can be torch.Tensor or numpy.ndarray
            
        Returns:
            Feature tensor of shape (N, feature_dim)
        """
        import time
        start_time = time.time()
        
        try:
            # Convert numpy array to tensor if needed
            if isinstance(batch, np.ndarray):
                batch = torch.from_numpy(batch)
            elif not isinstance(batch, torch.Tensor):
                raise FeatureExtractionError(
                    "ResNet50",
                    self.target_layer,
                    f"Input must be torch.Tensor or numpy.ndarray, got {type(batch)}"
                )
            
            with log_manager.create_operation_context("extract_features", 
                                                    batch_size=batch.shape[0]):
                
                self.stats['total_extractions'] += batch.shape[0]
                
                # Validate input
                if len(batch.shape) != 4:
                    raise FeatureExtractionError(
                        "ResNet50",
                        self.target_layer, 
                        f"Expected 4D tensor (N,C,H,W), got {batch.shape}"
                    )
                
                if batch.shape[1] != 3:
                    raise FeatureExtractionError(
                        "ResNet50",
                        self.target_layer,
                        f"Expected 3 channels (RGB), got {batch.shape[1]}"
                    )
                
                # Ensure tensor is float32 and move to device
                batch = batch.float().to(self.device)
                
                # Extract features
                with torch.no_grad():
                    features_dict = self.feature_extractor(batch)
                    features = features_dict['features']
                
                # Apply Global Average Pooling if features are 4D
                if len(features.shape) == 4:
                    # features shape: (N, C, H, W) -> (N, C)
                    features = torch.nn.functional.adaptive_avg_pool2d(features, (1, 1))
                    features = features.view(features.size(0), -1)
                
                # Move to CPU for output
                features = features.cpu()
                
                self.stats['successful_extractions'] += batch.shape[0]
                
                processing_time = time.time() - start_time
                self.stats['total_processing_time'] += processing_time
                
                self.logger.debug(f"Extracted features: {features.shape}, time: {processing_time:.3f}s")
                
                return features
                
        except FeatureExtractionError:
            self.stats['failed_extractions'] += batch.shape[0]
            raise
        except Exception as e:
            self.stats['failed_extractions'] += batch.shape[0]
            raise FeatureExtractionError(
                "ResNet50",
                self.target_layer,
                f"Feature extraction failed: {str(e)}"
            )
    
    def extract_features_from_single_image(self, image_tensor: torch.Tensor) -> torch.Tensor:
        """
        Extract features from a single image
        
        Args:
            image_tensor: Input tensor of shape (C, H, W)
            
        Returns:
            Feature tensor of shape (feature_dim,)
        """
        # Add batch dimension
        batch_tensor = image_tensor.unsqueeze(0)
        
        # Extract features
        features = self.extract_features(batch_tensor)
        
        # Remove batch dimension
        return features.squeeze(0)
    
    def get_feature_dimensions(self) -> Tuple[int, ...]:
        """
        Get feature dimensions by running a dummy forward pass
        
        Returns:
            Feature dimensions tuple
        """
        try:
            # Create dummy input
            dummy_input = torch.randn(1, 3, 224, 224, device=self.device)
            
            with torch.no_grad():
                features = self.extract_features(dummy_input)
            
            return tuple(features.shape[1:])  # Exclude batch dimension
            
        except Exception as e:
            self.logger.warning(f"Could not determine feature dimensions: {e}")
            # Return default dimensions for ResNet50 conv5_block3_out
            return (2048,)
    
    def get_layer_name(self) -> str:
        """Get target layer name"""
        return self.target_layer
    
    def get_available_layers(self) -> List[str]:
        """Get list of available layers for feature extraction"""
        try:
            available_nodes = get_graph_node_names(self.model)
            return available_nodes[0]  # Eval mode nodes
        except Exception as e:
            self.logger.error(f"Failed to get available layers: {e}")
            return []
    
    def optimize_for_inference(self):
        """Optimize model for inference"""
        try:
            # Enable inference optimizations
            if hasattr(torch.backends, 'cudnn'):
                torch.backends.cudnn.benchmark = True
            
            # Try to use TorchScript if possible
            if hasattr(torch.jit, 'script'):
                try:
                    self.feature_extractor = torch.jit.script(self.feature_extractor)
                    self.logger.info("Model optimized with TorchScript")
                except Exception as e:
                    self.logger.warning(f"TorchScript optimization failed: {e}")
            
            self.logger.info("Model optimized for inference")
            
        except Exception as e:
            self.logger.warning(f"Inference optimization failed: {e}")
    
    def get_memory_usage(self) -> Dict[str, float]:
        """Get memory usage information"""
        memory_info = {}
        
        if self.device.type == 'cuda':
            memory_info.update({
                'gpu_memory_allocated_mb': torch.cuda.memory_allocated(self.device) / 1e6,
                'gpu_memory_cached_mb': torch.cuda.memory_reserved(self.device) / 1e6,
                'gpu_memory_total_mb': torch.cuda.get_device_properties(self.device).total_memory / 1e6
            })
        
        # Estimate model parameters memory
        param_memory = sum(p.numel() * p.element_size() for p in self.model.parameters())
        memory_info['model_parameters_mb'] = param_memory / 1e6
        
        return memory_info
    
    def clear_cache(self):
        """Clear GPU memory cache"""
        if self.device.type == 'cuda':
            torch.cuda.empty_cache()
            self.logger.info("GPU memory cache cleared")


class MultiLayerFeatureExtractor(BaseFeatureExtractor):
    """
    Multi-layer feature extractor for extracting features from multiple layers
    
    Extends functionality for research and comparison purposes.
    """
    
    def __init__(self, 
                 target_layers: List[str],
                 pretrained: bool = True,
                 device: str = 'auto'):
        """
        Initialize multi-layer feature extractor
        
        Args:
            target_layers: List of target layer names
            pretrained: Whether to use pretrained weights
            device: Computing device
        """
        super().__init__(device)
        
        self.target_layers = target_layers
        self.pretrained = pretrained
        
        self._load_model()
        self._create_feature_extractor()
        
        self.logger.info(f"Multi-layer feature extractor initialized for layers: {target_layers}")
    
    def _load_model(self):
        """Load ResNet50 model"""
        try:
            if self.pretrained:
                self.model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
            else:
                self.model = models.resnet50(weights=None)
            
            self.model = self.model.to(self.device)
            self.model.eval()
            
            for param in self.model.parameters():
                param.requires_grad = False
                
        except Exception as e:
            raise ModelError("ResNet50", "load_model", f"Failed to load model: {str(e)}")
    
    def _create_feature_extractor(self):
        """Create multi-layer feature extractor"""
        try:
            # Create return nodes dictionary
            return_nodes = {layer: f'features_{i}' for i, layer in enumerate(self.target_layers)}
            
            self.feature_extractor = create_feature_extractor(
                self.model,
                return_nodes=return_nodes
            )
            
            self.feature_extractor = self.feature_extractor.to(self.device)
            self.feature_extractor.eval()
            
        except Exception as e:
            raise FeatureExtractionError(
                "ResNet50",
                str(self.target_layers),
                f"Failed to create multi-layer feature extractor: {str(e)}"
            )
    
    def extract_features(self, batch: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Extract features from multiple layers
        
        Args:
            batch: Input tensor of shape (N, C, H, W)
            
        Returns:
            Dictionary of feature tensors {layer_name: features}
        """
        try:
            batch = batch.to(self.device)
            
            with torch.no_grad():
                features_dict = self.feature_extractor(batch)
            
            # Apply Global Average Pooling to 4D features
            processed_features = {}
            for key, features in features_dict.items():
                if len(features.shape) == 4:
                    features = torch.nn.functional.adaptive_avg_pool2d(features, (1, 1))
                    features = features.view(features.size(0), -1)
                
                processed_features[key] = features.cpu()
            
            return processed_features
            
        except Exception as e:
            raise FeatureExtractionError(
                "ResNet50",
                str(self.target_layers),
                f"Multi-layer feature extraction failed: {str(e)}"
            )
    
    def get_feature_dimensions(self) -> Dict[str, Tuple[int, ...]]:
        """Get feature dimensions for all layers"""
        try:
            dummy_input = torch.randn(1, 3, 224, 224, device=self.device)
            features_dict = self.extract_features(dummy_input)
            
            return {key: tuple(features.shape[1:]) for key, features in features_dict.items()}
            
        except Exception as e:
            self.logger.warning(f"Could not determine feature dimensions: {e}")
            return {}
    
    def get_layer_name(self) -> str:
        """Get target layer names as string"""
        return ", ".join(self.target_layers)


class FeatureExtractorFactory:
    """
    Factory for creating different types of feature extractors
    
    Follows Open/Closed Principle - open for extension, closed for modification.
    """
    
    @staticmethod
    def create_resnet50_extractor(target_layer: str = 'layer4.2.conv3',
                                pretrained: bool = True,
                                device: str = 'auto') -> ResNet50FeatureExtractor:
        """Create ResNet50 feature extractor"""
        return ResNet50FeatureExtractor(
            target_layer=target_layer,
            pretrained=pretrained,
            device=device
        )
    
    @staticmethod
    def create_multilayer_extractor(target_layers: List[str],
                                  pretrained: bool = True,
                                  device: str = 'auto') -> MultiLayerFeatureExtractor:
        """Create multi-layer feature extractor"""
        return MultiLayerFeatureExtractor(
            target_layers=target_layers,
            pretrained=pretrained,
            device=device
        )
    
    @staticmethod
    def create_from_config(config: Dict[str, Any]) -> IFeatureExtractor:
        """
        Create feature extractor from configuration
        
        Args:
            config: Configuration dictionary
            
        Returns:
            Configured feature extractor instance
        """
        extractor_type = config.get('type', 'resnet50')
        
        if extractor_type == 'resnet50':
            return FeatureExtractorFactory.create_resnet50_extractor(
                target_layer=config.get('target_layer', 'layer4.2.conv3'),
                pretrained=config.get('pretrained', True),
                device=config.get('device', 'auto')
            )
        elif extractor_type == 'multilayer':
            return FeatureExtractorFactory.create_multilayer_extractor(
                target_layers=config.get('target_layers', ['layer4.2.conv3']),
                pretrained=config.get('pretrained', True),
                device=config.get('device', 'auto')
            )
        else:
            raise FeatureExtractionError(
                "Factory",
                extractor_type,
                f"Unknown feature extractor type: {extractor_type}"
            )