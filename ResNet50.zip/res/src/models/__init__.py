# -*- coding: utf-8 -*-
"""
Models module

Contains deep learning models and feature extractors.
"""

from .feature_extractors import ResNet50FeatureExtractor, FeatureExtractorFactory

__all__ = [
    'ResNet50FeatureExtractor',
    'FeatureExtractorFactory'
]