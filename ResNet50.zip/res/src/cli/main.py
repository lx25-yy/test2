# -*- coding: utf-8 -*-
"""
Main CLI entry point

Provides the main command-line interface for DICOM feature extraction.
"""

import sys
import argparse
import time
from pathlib import Path
from typing import List, Optional, Dict, Any

from ..core.config import ConfigManager
from ..core.logger import log_manager
from ..core.pipeline import DICOMFeaturePipeline
from ..output.data_structures import OutputFormat, CompressionType
from .commands import (
    ExtractCommand, ValidateCommand, ConfigCommand,
    ListFormatsCommand, BenchmarkCommand
)
from .interactive import InteractiveCLI
from .progress import ProgressReporter


def create_cli_parser() -> argparse.ArgumentParser:
    """创建命令行参数解析器"""
    parser = argparse.ArgumentParser(
        prog="dicom_feature_extractor",
        description="DICOM Feature Extraction Tool - Extract ResNet50 features from DICOM images",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Extract features from DICOM directory
  python -m src.cli.main extract /path/to/dicom /path/to/output
  
  # Extract with specific settings
  python -m src.cli.main extract /path/to/dicom /path/to/output --format numpy json --batch-size 16
  
  # Interactive mode
  python -m src.cli.main interactive
  
  # Validate DICOM files
  python -m src.cli.main validate /path/to/dicom
  
  # List supported formats
  python -m src.cli.main list-formats
  
  # Benchmark system performance
  python -m src.cli.main benchmark
        """
    )
    
    # Global options
    parser.add_argument(
        '--config', '-c',
        type=str,
        help='Path to configuration file'
    )
    parser.add_argument(
        '--verbose', '-v',
        action='count',
        default=0,
        help='Increase verbosity (use -v, -vv, or -vvv)'
    )
    parser.add_argument(
        '--quiet', '-q',
        action='store_true',
        help='Suppress all output except errors'
    )
    parser.add_argument(
        '--log-file',
        type=str,
        help='Path to log file'
    )
    parser.add_argument(
        '--no-color',
        action='store_true',
        help='Disable colored output'
    )
    parser.add_argument(
        '--version',
        action='version',
        version='DICOM Feature Extractor v1.0.0'
    )
    
    # Create subparsers for commands
    subparsers = parser.add_subparsers(
        dest='command',
        help='Available commands',
        metavar='COMMAND'
    )
    
    # Extract command
    extract_parser = subparsers.add_parser(
        'extract',
        help='Extract features from DICOM files',
        description='Extract ResNet50 features from DICOM images'
    )
    ExtractCommand.add_arguments(extract_parser)
    
    # Validate command
    validate_parser = subparsers.add_parser(
        'validate',
        help='Validate DICOM files',
        description='Validate DICOM files and check compatibility'
    )
    ValidateCommand.add_arguments(validate_parser)
    
    # Config command
    config_parser = subparsers.add_parser(
        'config',
        help='Manage configuration',
        description='Create and manage configuration files'
    )
    ConfigCommand.add_arguments(config_parser)
    
    # List formats command
    list_formats_parser = subparsers.add_parser(
        'list-formats',
        help='List supported output formats',
        description='List all supported output formats and their status'
    )
    ListFormatsCommand.add_arguments(list_formats_parser)
    
    # Benchmark command
    benchmark_parser = subparsers.add_parser(
        'benchmark',
        help='Run system benchmark',
        description='Test system performance and capabilities'
    )
    BenchmarkCommand.add_arguments(benchmark_parser)
    
    # Interactive command
    interactive_parser = subparsers.add_parser(
        'interactive',
        help='Start interactive mode',
        description='Start interactive command-line interface'
    )
    interactive_parser.add_argument(
        '--no-banner',
        action='store_true',
        help='Don\'t show startup banner'
    )
    
    return parser


def setup_logging(args: argparse.Namespace, config_manager: ConfigManager):
    """配置日志系统"""
    config = config_manager.get_default_config()
    
    # 根据参数调整日志级别
    if args.quiet:
        config.logging.log_level = "ERROR"
        config.logging.console_output = False
    elif args.verbose >= 3:
        config.logging.log_level = "DEBUG"
    elif args.verbose >= 2:
        config.logging.log_level = "INFO"
    elif args.verbose >= 1:
        config.logging.log_level = "WARNING"
    
    # 设置日志文件
    if args.log_file:
        config.logging.file_output = True
        config.logging.log_file = args.log_file
    
    # 禁用颜色输出
    if args.no_color:
        config.logging.use_colors = False
    
    log_manager.configure_logging(config.logging)


def handle_extract_command(args: argparse.Namespace) -> int:
    """处理extract命令"""
    try:
        command = ExtractCommand()
        result = command.execute(args)
        return 0 if result else 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_validate_command(args: argparse.Namespace) -> int:
    """处理validate命令"""
    try:
        command = ValidateCommand()
        result = command.execute(args)
        return 0 if result else 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_config_command(args: argparse.Namespace) -> int:
    """处理config命令"""
    try:
        command = ConfigCommand()
        result = command.execute(args)
        return 0 if result else 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_list_formats_command(args: argparse.Namespace) -> int:
    """处理list-formats命令"""
    try:
        command = ListFormatsCommand()
        result = command.execute(args)
        return 0 if result else 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_benchmark_command(args: argparse.Namespace) -> int:
    """处理benchmark命令"""
    try:
        command = BenchmarkCommand()
        result = command.execute(args)
        return 0 if result else 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def handle_interactive_command(args: argparse.Namespace) -> int:
    """处理interactive命令"""
    try:
        cli = InteractiveCLI()
        return cli.run(show_banner=not args.no_banner)
    except KeyboardInterrupt:
        print("\nInteractive session terminated by user.")
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


def main(argv: Optional[List[str]] = None) -> int:
    """主入口函数"""
    if argv is None:
        argv = sys.argv[1:]
    
    # 创建参数解析器
    parser = create_cli_parser()
    
    # 解析参数
    if not argv:
        parser.print_help()
        return 1
    
    args = parser.parse_args(argv)
    
    try:
        # 初始化配置管理器
        config_manager = ConfigManager()
        if args.config:
            config_manager.load_config(args.config)
        
        # 设置日志
        setup_logging(args, config_manager)
        
        # 根据命令分发处理
        if args.command == 'extract':
            return handle_extract_command(args)
        elif args.command == 'validate':
            return handle_validate_command(args)
        elif args.command == 'config':
            return handle_config_command(args)
        elif args.command == 'list-formats':
            return handle_list_formats_command(args)
        elif args.command == 'benchmark':
            return handle_benchmark_command(args)
        elif args.command == 'interactive':
            return handle_interactive_command(args)
        else:
            parser.print_help()
            return 1
            
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        if args.verbose >= 3:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())