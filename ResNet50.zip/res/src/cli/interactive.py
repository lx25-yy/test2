# -*- coding: utf-8 -*-
"""
Interactive CLI mode

Provides an interactive command-line interface for DICOM feature extraction.
"""

import sys
import os
import json
import cmd
import shlex
import time
from pathlib import Path
from typing import Dict, List, Any, Optional

from ..core.config import ConfigManager
from ..core.logger import log_manager
from ..core.pipeline import DICOMFeaturePipeline
from ..output.data_structures import OutputFormat, CompressionType
from ..output.output_manager import FeatureOutputManager
from .progress import ProgressReporter


class InteractiveCLI(cmd.Cmd):
    """交互式命令行界面"""
    
    intro = """
╔══════════════════════════════════════════════════════════════════════════════════╗
║                        DICOM Feature Extractor - Interactive Mode                ║
║                                                                                  ║
║  Extract ResNet50 features from DICOM images with an interactive interface      ║
║                                                                                  ║
║  Type 'help' or '?' for available commands                                      ║
║  Type 'help <command>' for detailed help on a specific command                  ║
║  Type 'quit' or 'exit' to leave the interactive mode                           ║
╚══════════════════════════════════════════════════════════════════════════════════╝
    """
    
    prompt = '(dicom-extractor) '
    
    def __init__(self):
        """初始化交互式CLI"""
        super().__init__()
        
        # 系统状态
        self.config_manager = ConfigManager()
        self.pipeline = None
        self.current_config = {}
        self.last_result = None
        
        # 设置默认配置
        self._reset_config()
        
        # 初始化日志
        config = self.config_manager.get_default_config()
        log_manager.configure_logging(config.logging)
    
    def _reset_config(self):
        """重置配置到默认值"""
        self.current_config = {
            'input_directory': '',
            'output_directory': './extracted_features',
            'target_layer': 'layer4.2.conv3',
            'image_size': [224, 224],
            'device': 'auto',
            'batch_size': None,
            'enable_batch_optimization': True,
            'memory_threshold': 0.85,
            'file_patterns': ['*.dcm', '*.DCM'],
            'recursive_scan': True,
            'output_formats': ['numpy'],
            'compression': 'gzip',
            'filename_prefix': 'features',
            'chunk_size': None,
            'continue_on_error': True,
            'max_error_rate': 0.5,
            'validate_outputs': True,
            'include_metadata': True
        }
    
    def run(self, show_banner: bool = True) -> int:
        """运行交互式界面"""
        try:
            if show_banner:
                print(self.intro)
            
            # 验证系统组件
            print("Initializing system components...")
            self.pipeline = DICOMFeaturePipeline()
            
            if self.pipeline.validate_pipeline_components():
                print("✓ All components available and ready")
            else:
                print("⚠ Some components missing - limited functionality")
            
            print(f"Current working directory: {os.getcwd()}")
            print("Ready for commands. Type 'help' for available commands.\n")
            
            # 启动命令循环
            self.cmdloop()
            return 0
            
        except Exception as e:
            print(f"Error initializing interactive mode: {e}")
            return 1
    
    def emptyline(self):
        """处理空行"""
        pass
    
    def do_quit(self, arg):
        """Quit the interactive session"""
        print("Goodbye!")
        return True
    
    def do_exit(self, arg):
        """Exit the interactive session"""
        return self.do_quit(arg)
    
    def do_EOF(self, arg):
        """Handle Ctrl+D"""
        print()
        return self.do_quit(arg)
    
    # Configuration commands
    def do_config(self, arg):
        """
        Manage configuration settings.
        
        Usage:
            config show [key]          - Show current configuration
            config set <key> <value>   - Set configuration value
            config reset               - Reset to default configuration
            config load <file>         - Load configuration from file
            config save <file>         - Save configuration to file
        """
        args = shlex.split(arg) if arg else []
        
        if not args or args[0] == 'show':
            self._show_config(args[1:])
        elif args[0] == 'set':
            self._set_config(args[1:])
        elif args[0] == 'reset':
            self._reset_config()
            print("Configuration reset to defaults")
        elif args[0] == 'load':
            self._load_config(args[1:])
        elif args[0] == 'save':
            self._save_config(args[1:])
        else:
            print("Invalid config command. Type 'help config' for usage.")
    
    def _show_config(self, args):
        """显示配置"""
        if args:
            # 显示特定配置项
            key = args[0]
            if key in self.current_config:
                value = self.current_config[key]
                print(f"{key}: {value}")
            else:
                print(f"Configuration key '{key}' not found")
                print(f"Available keys: {', '.join(self.current_config.keys())}")
        else:
            # 显示所有配置
            print("Current Configuration:")
            print("=" * 50)
            for key, value in self.current_config.items():
                print(f"{key:<25}: {value}")
    
    def _set_config(self, args):
        """设置配置"""
        if len(args) < 2:
            print("Usage: config set <key> <value>")
            return
        
        key = args[0]
        value_str = ' '.join(args[1:])
        
        if key not in self.current_config:
            print(f"Unknown configuration key: {key}")
            print(f"Available keys: {', '.join(self.current_config.keys())}")
            return
        
        try:
            # 类型转换
            current_value = self.current_config[key]
            if isinstance(current_value, bool):
                value = value_str.lower() in ('true', '1', 'yes', 'on')
            elif isinstance(current_value, int):
                value = int(value_str)
            elif isinstance(current_value, float):
                value = float(value_str)
            elif isinstance(current_value, list):
                # 处理列表类型
                if value_str.startswith('[') and value_str.endswith(']'):
                    value = json.loads(value_str)
                else:
                    value = value_str.split(',')
            else:
                value = value_str
            
            self.current_config[key] = value
            print(f"Set {key} = {value}")
            
        except ValueError as e:
            print(f"Error setting configuration: {e}")
    
    def _load_config(self, args):
        """加载配置文件"""
        if not args:
            print("Usage: config load <file>")
            return
        
        config_file = args[0]
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                loaded_config = json.load(f)
            
            # 更新配置
            for key, value in loaded_config.items():
                if key in self.current_config:
                    self.current_config[key] = value
                else:
                    print(f"Warning: Unknown configuration key '{key}' ignored")
            
            print(f"Configuration loaded from: {config_file}")
            
        except FileNotFoundError:
            print(f"Configuration file not found: {config_file}")
        except json.JSONDecodeError as e:
            print(f"Error parsing configuration file: {e}")
        except Exception as e:
            print(f"Error loading configuration: {e}")
    
    def _save_config(self, args):
        """保存配置文件"""
        if not args:
            print("Usage: config save <file>")
            return
        
        config_file = args[0]
        try:
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(self.current_config, f, indent=2, ensure_ascii=False)
            
            print(f"Configuration saved to: {config_file}")
            
        except Exception as e:
            print(f"Error saving configuration: {e}")
    
    # Directory and file operations
    def do_ls(self, arg):
        """List files in current or specified directory"""
        path = arg.strip() if arg.strip() else '.'
        try:
            path_obj = Path(path)
            if path_obj.is_dir():
                files = list(path_obj.iterdir())
                if files:
                    for file_path in sorted(files):
                        size = ""
                        if file_path.is_file():
                            size = f" ({file_path.stat().st_size} bytes)"
                        
                        prefix = "📁" if file_path.is_dir() else "📄"
                        print(f"{prefix} {file_path.name}{size}")
                else:
                    print("Directory is empty")
            else:
                print(f"Not a directory: {path}")
        except Exception as e:
            print(f"Error listing directory: {e}")
    
    def do_cd(self, arg):
        """Change current directory"""
        path = arg.strip() if arg.strip() else os.path.expanduser('~')
        try:
            os.chdir(path)
            print(f"Changed directory to: {os.getcwd()}")
        except Exception as e:
            print(f"Error changing directory: {e}")
    
    def do_pwd(self, arg):
        """Print current working directory"""
        print(os.getcwd())
    
    # DICOM operations
    def do_scan(self, arg):
        """
        Scan directory for DICOM files.
        
        Usage:
            scan [directory]    - Scan directory (default: input_directory from config)
        """
        directory = arg.strip() if arg.strip() else self.current_config.get('input_directory', '.')
        
        if not directory:
            print("No directory specified. Use 'scan <directory>' or set input_directory in config.")
            return
        
        try:
            path = Path(directory)
            if not path.exists():
                print(f"Directory does not exist: {directory}")
                return
            
            print(f"Scanning for DICOM files in: {directory}")
            print(f"Patterns: {self.current_config['file_patterns']}")
            print(f"Recursive: {self.current_config['recursive_scan']}")
            
            # 扫描文件
            files = []
            for pattern in self.current_config['file_patterns']:
                if self.current_config['recursive_scan']:
                    pattern_files = list(path.rglob(pattern))
                else:
                    pattern_files = list(path.glob(pattern))
                files.extend(pattern_files)
            
            files = list(set(files))  # 去重
            
            print(f"\nFound {len(files)} DICOM files:")
            for i, file_path in enumerate(sorted(files)[:10], 1):
                size = file_path.stat().st_size / 1024  # KB
                print(f"  {i:3d}. {file_path.name} ({size:.1f} KB)")
            
            if len(files) > 10:
                print(f"  ... and {len(files) - 10} more files")
            
        except Exception as e:
            print(f"Error scanning directory: {e}")
    
    def do_validate(self, arg):
        """
        Validate DICOM files.
        
        Usage:
            validate [directory]    - Validate DICOM files (default: input_directory from config)
        """
        directory = arg.strip() if arg.strip() else self.current_config.get('input_directory', '.')
        
        if not directory:
            print("No directory specified. Use 'validate <directory>' or set input_directory in config.")
            return
        
        try:
            from ..data.loaders import DICOMLoaderFactory
            
            path = Path(directory)
            if not path.exists():
                print(f"Directory does not exist: {directory}")
                return
            
            print(f"Validating DICOM files in: {directory}")
            
            # 扫描文件
            files = []
            for pattern in self.current_config['file_patterns']:
                if self.current_config['recursive_scan']:
                    pattern_files = list(path.rglob(pattern))
                else:
                    pattern_files = list(path.glob(pattern))
                files.extend(pattern_files)
            
            files = list(set(files))
            
            if not files:
                print("No DICOM files found")
                return
            
            print(f"Validating {len(files)} files...")
            
            # 创建加载器
            loader = DICOMLoaderFactory.create_standard_loader()
            
            valid_count = 0
            for i, file_path in enumerate(files, 1):
                print(f"\r  [{i:4d}/{len(files)}] {file_path.name}", end='')
                
                try:
                    dicom_data = loader.load_dicom_file(str(file_path))
                    valid_count += 1
                    print(" ✓")
                except Exception:
                    print(" ✗")
            
            print(f"\nValidation complete:")
            print(f"  Valid files:   {valid_count}")
            print(f"  Invalid files: {len(files) - valid_count}")
            print(f"  Success rate:  {valid_count/len(files):.1%}")
            
        except Exception as e:
            print(f"Error validating files: {e}")
    
    def do_extract(self, arg):
        """
        Extract features from DICOM files.
        
        Usage:
            extract [input_dir] [output_dir]    - Extract features with current configuration
        """
        args = shlex.split(arg) if arg else []
        
        # 确定输入和输出目录
        if len(args) >= 1:
            input_dir = args[0]
        else:
            input_dir = self.current_config.get('input_directory', '')
        
        if len(args) >= 2:
            output_dir = args[1]
        else:
            output_dir = self.current_config.get('output_directory', './extracted_features')
        
        if not input_dir:
            print("No input directory specified. Use 'extract <input_dir>' or set input_directory in config.")
            return
        
        # 验证输入目录
        input_path = Path(input_dir)
        if not input_path.exists():
            print(f"Input directory does not exist: {input_dir}")
            return
        
        # 创建输出目录
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        print(f"Feature Extraction")
        print(f"==================")
        print(f"Input:  {input_dir}")
        print(f"Output: {output_dir}")
        print(f"Layer:  {self.current_config['target_layer']}")
        print(f"Device: {self.current_config['device']}")
        print(f"Formats: {', '.join(self.current_config['output_formats'])}")
        print()
        
        try:
            # 更新配置
            config = self.current_config.copy()
            
            # 创建进度报告器
            progress_reporter = ProgressReporter()
            
            # 执行特征提取
            if not self.pipeline:
                self.pipeline = DICOMFeaturePipeline()
            
            print("Starting feature extraction...")
            start_time = time.time()
            
            result = self.pipeline.execute_pipeline(input_dir, output_dir, config)
            
            execution_time = time.time() - start_time
            self.last_result = result
            
            # 显示结果
            print(f"\nExtraction Complete")
            print(f"===================")
            print(f"Execution time:     {execution_time:.2f} seconds")
            print(f"Total images:       {result.total_images}")
            print(f"Successful:         {result.successful_extractions}")
            print(f"Failed:             {result.failed_extractions}")
            print(f"Success rate:       {result.successful_extractions/result.total_images:.1%}" if result.total_images > 0 else "Success rate: N/A")
            print(f"Feature dimensions: {result.feature_dimensions}")
            print(f"Output files:       {len(result.output_files)}")
            
            if result.output_files:
                print(f"\nOutput files created:")
                for output_file in result.output_files:
                    file_size = Path(output_file).stat().st_size / (1024 * 1024)  # MB
                    print(f"  - {Path(output_file).name} ({file_size:.2f} MB)")
            
            if result.error_log:
                print(f"\nErrors ({len(result.error_log)}):")
                for error in result.error_log[:3]:
                    print(f"  - {error}")
                if len(result.error_log) > 3:
                    print(f"  ... and {len(result.error_log) - 3} more errors")
            
        except Exception as e:
            print(f"Error during extraction: {e}")
    
    # Information commands
    def do_status(self, arg):
        """Show system and configuration status"""
        print("System Status")
        print("=============")
        
        # 系统信息
        import platform
        print(f"Platform:       {platform.platform()}")
        print(f"Python version: {platform.python_version()}")
        print(f"Working dir:    {os.getcwd()}")
        
        # 组件状态
        if self.pipeline:
            components_valid = self.pipeline.validate_pipeline_components()
            print(f"Components:     {'✓ All available' if components_valid else '⚠ Some missing'}")
        
        # GPU信息
        try:
            import torch
            if torch.cuda.is_available():
                print(f"GPU:            ✓ Available ({torch.cuda.device_count()} device(s))")
            else:
                print(f"GPU:            ✗ Not available")
        except ImportError:
            print(f"GPU:            ✗ PyTorch not installed")
        
        # 配置摘要
        print(f"\nConfiguration Summary")
        print(f"====================")
        print(f"Input directory:    {self.current_config.get('input_directory', 'Not set')}")
        print(f"Output directory:   {self.current_config['output_directory']}")
        print(f"Target layer:       {self.current_config['target_layer']}")
        print(f"Device:             {self.current_config['device']}")
        print(f"Output formats:     {', '.join(self.current_config['output_formats'])}")
        print(f"Batch optimization: {self.current_config['enable_batch_optimization']}")
        
        # 最后结果
        if self.last_result:
            print(f"\nLast Extraction Result")
            print(f"=====================")
            print(f"Images processed:   {self.last_result.total_images}")
            print(f"Success rate:       {self.last_result.successful_extractions/self.last_result.total_images:.1%}" if self.last_result.total_images > 0 else "Success rate: N/A")
            print(f"Processing time:    {self.last_result.processing_time:.2f} seconds")
    
    def do_formats(self, arg):
        """List supported output formats"""
        try:
            output_manager = FeatureOutputManager()
            supported_formats = output_manager.get_supported_formats()
            
            print("Supported Output Formats")
            print("========================")
            
            for fmt in supported_formats:
                available = output_manager.is_format_available(fmt)
                status = "✓ Available" if available else "✗ Unavailable"
                print(f"{fmt.value:<10} {status}")
            
            print(f"\nTotal: {len(supported_formats)} formats")
            available_count = sum(1 for fmt in supported_formats if output_manager.is_format_available(fmt))
            print(f"Available: {available_count}")
            
        except Exception as e:
            print(f"Error listing formats: {e}")
    
    def do_benchmark(self, arg):
        """Run a quick system benchmark"""
        print("Running system benchmark...")
        
        try:
            # 系统信息
            import platform
            import psutil
            
            print(f"Platform: {platform.platform()}")
            print(f"CPU cores: {psutil.cpu_count()}")
            print(f"Memory: {psutil.virtual_memory().total / (1024**3):.1f} GB")
            
            # GPU测试
            try:
                import torch
                if torch.cuda.is_available():
                    print(f"GPU: {torch.cuda.get_device_name()}")
                else:
                    print("GPU: Not available")
            except ImportError:
                print("GPU: PyTorch not installed")
            
            # 组件测试
            if not self.pipeline:
                self.pipeline = DICOMFeaturePipeline()
            
            components_valid = self.pipeline.validate_pipeline_components()
            print(f"Pipeline components: {'All available' if components_valid else 'Some missing'}")
            
            print("Benchmark complete")
            
        except Exception as e:
            print(f"Error running benchmark: {e}")
    
    def do_help(self, arg):
        """Enhanced help command"""
        if arg:
            # 调用父类的help方法显示特定命令的帮助
            super().do_help(arg)
        else:
            # 显示自定义的帮助菜单
            print("Available Commands:")
            print("==================")
            print()
            print("Configuration:")
            print("  config          - Manage configuration settings")
            print("  status          - Show system and configuration status")
            print()
            print("File Operations:")
            print("  ls [dir]        - List files in directory")
            print("  cd <dir>        - Change current directory")
            print("  pwd             - Print current directory")
            print()
            print("DICOM Operations:")
            print("  scan [dir]      - Scan directory for DICOM files")
            print("  validate [dir]  - Validate DICOM files")
            print("  extract [in] [out] - Extract features from DICOM files")
            print()
            print("Information:")
            print("  formats         - List supported output formats")
            print("  benchmark       - Run system benchmark")
            print("  help [cmd]      - Show help for specific command")
            print()
            print("System:")
            print("  quit/exit       - Exit interactive mode")
            print()
            print("Use 'help <command>' for detailed information about a specific command.")
    
    # Tab completion
    def complete_config(self, text, line, begidx, endidx):
        """Tab completion for config command"""
        args = line.split()
        
        if len(args) <= 2:
            # Complete config subcommands
            options = ['show', 'set', 'reset', 'load', 'save']
            return [opt for opt in options if opt.startswith(text)]
        elif len(args) == 3 and args[1] in ['show', 'set']:
            # Complete config keys
            return [key for key in self.current_config.keys() if key.startswith(text)]
        
        return []
    
    def complete_cd(self, text, line, begidx, endidx):
        """Tab completion for cd command"""
        return self._complete_path(text, directories_only=True)
    
    def complete_ls(self, text, line, begidx, endidx):
        """Tab completion for ls command"""
        return self._complete_path(text, directories_only=True)
    
    def complete_scan(self, text, line, begidx, endidx):
        """Tab completion for scan command"""
        return self._complete_path(text, directories_only=True)
    
    def complete_validate(self, text, line, begidx, endidx):
        """Tab completion for validate command"""
        return self._complete_path(text, directories_only=True)
    
    def complete_extract(self, text, line, begidx, endidx):
        """Tab completion for extract command"""
        return self._complete_path(text, directories_only=True)
    
    def _complete_path(self, text, directories_only=False):
        """路径自动补全辅助方法"""
        try:
            if text:
                path = Path(text)
                if path.is_absolute():
                    base_dir = path.parent
                    prefix = path.name
                else:
                    base_dir = Path('.')
                    prefix = text
            else:
                base_dir = Path('.')
                prefix = ''
            
            if not base_dir.exists():
                return []
            
            completions = []
            for item in base_dir.iterdir():
                if item.name.startswith(prefix):
                    if directories_only and not item.is_dir():
                        continue
                    
                    if item.is_dir():
                        completions.append(str(item) + '/')
                    else:
                        completions.append(str(item))
            
            return completions
            
        except Exception:
            return []