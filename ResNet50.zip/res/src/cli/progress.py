# -*- coding: utf-8 -*-
"""
Progress reporting for CLI

Provides progress bars and status reporting for CLI operations.
"""

import sys
import time
import threading
from typing import Optional, Callable, Any
from dataclasses import dataclass


@dataclass
class ProgressInfo:
    """进度信息"""
    current: int
    total: int
    description: str = ""
    elapsed_time: float = 0.0
    estimated_remaining: float = 0.0
    
    @property
    def percentage(self) -> float:
        """完成百分比"""
        if self.total <= 0:
            return 0.0
        return min(100.0, (self.current / self.total) * 100.0)
    
    @property
    def rate(self) -> float:
        """处理速率（items/sec）"""
        if self.elapsed_time <= 0:
            return 0.0
        return self.current / self.elapsed_time


class ConsoleProgressBar:
    """控制台进度条"""
    
    def __init__(self, 
                 total: int,
                 description: str = "",
                 bar_length: int = 50,
                 show_percentage: bool = True,
                 show_rate: bool = True,
                 show_eta: bool = True):
        """
        初始化进度条
        
        Args:
            total: 总项目数
            description: 描述文本
            bar_length: 进度条长度
            show_percentage: 显示百分比
            show_rate: 显示处理速率
            show_eta: 显示预估剩余时间
        """
        self.total = total
        self.description = description
        self.bar_length = bar_length
        self.show_percentage = show_percentage
        self.show_rate = show_rate
        self.show_eta = show_eta
        
        self.current = 0
        self.start_time = time.time()
        self.last_update_time = self.start_time
        self.update_interval = 0.1  # 更新间隔（秒）
        
        self._lock = threading.Lock()
    
    def update(self, n: int = 1, description: Optional[str] = None):
        """更新进度"""
        with self._lock:
            self.current = min(self.current + n, self.total)
            
            if description:
                self.description = description
            
            current_time = time.time()
            if current_time - self.last_update_time >= self.update_interval or self.current >= self.total:
                self._render()
                self.last_update_time = current_time
    
    def set_progress(self, current: int, description: Optional[str] = None):
        """设置当前进度"""
        with self._lock:
            self.current = min(max(current, 0), self.total)
            
            if description:
                self.description = description
            
            current_time = time.time()
            if current_time - self.last_update_time >= self.update_interval or self.current >= self.total:
                self._render()
                self.last_update_time = current_time
    
    def _render(self):
        """渲染进度条"""
        if self.total <= 0:
            return
        
        # 计算进度
        percentage = (self.current / self.total) * 100
        elapsed_time = time.time() - self.start_time
        
        # 构建进度条
        filled_length = int(self.bar_length * self.current // self.total)
        bar = '█' * filled_length + '░' * (self.bar_length - filled_length)
        
        # 构建显示文本
        parts = []
        
        if self.description:
            parts.append(self.description)
        
        parts.append(f'[{bar}]')
        parts.append(f'{self.current}/{self.total}')
        
        if self.show_percentage:
            parts.append(f'{percentage:.1f}%')
        
        if self.show_rate and elapsed_time > 0:
            rate = self.current / elapsed_time
            parts.append(f'{rate:.1f}it/s')
        
        if self.show_eta and self.current > 0 and self.current < self.total:
            avg_time_per_item = elapsed_time / self.current
            remaining_items = self.total - self.current
            eta = remaining_items * avg_time_per_item
            
            if eta < 60:
                eta_str = f'{eta:.0f}s'
            elif eta < 3600:
                eta_str = f'{eta/60:.0f}m{eta%60:.0f}s'
            else:
                eta_str = f'{eta/3600:.0f}h{(eta%3600)/60:.0f}m'
            
            parts.append(f'ETA: {eta_str}')
        
        # 输出进度条
        line = ' '.join(parts)
        print(f'\r{line}', end='', flush=True)
        
        # 完成时换行
        if self.current >= self.total:
            print()
    
    def close(self):
        """关闭进度条"""
        if self.current < self.total:
            self.current = self.total
            self._render()


class ProgressReporter:
    """进度报告器"""
    
    def __init__(self,
                 enable_progress_bar: bool = True,
                 update_callback: Optional[Callable[[ProgressInfo], None]] = None):
        """
        初始化进度报告器
        
        Args:
            enable_progress_bar: 启用进度条
            update_callback: 更新回调函数
        """
        self.enable_progress_bar = enable_progress_bar
        self.update_callback = update_callback
        
        self.progress_bar: Optional[ConsoleProgressBar] = None
        self.start_time = time.time()
        
        self._current_operation = ""
        self._total_operations = 0
        self._completed_operations = 0
    
    def start_operation(self, 
                       operation_name: str,
                       total_items: int,
                       description: str = ""):
        """开始操作"""
        self._current_operation = operation_name
        self._total_operations = total_items
        self._completed_operations = 0
        
        if self.enable_progress_bar and total_items > 0:
            self.progress_bar = ConsoleProgressBar(
                total=total_items,
                description=description or operation_name
            )
    
    def update_progress(self, 
                       increment: int = 1,
                       description: Optional[str] = None):
        """更新进度"""
        self._completed_operations = min(
            self._completed_operations + increment,
            self._total_operations
        )
        
        if self.progress_bar:
            self.progress_bar.update(increment, description)
        
        # 调用回调
        if self.update_callback:
            elapsed_time = time.time() - self.start_time
            progress_info = ProgressInfo(
                current=self._completed_operations,
                total=self._total_operations,
                description=description or self._current_operation,
                elapsed_time=elapsed_time
            )
            self.update_callback(progress_info)
    
    def set_progress(self,
                    current: int,
                    description: Optional[str] = None):
        """设置当前进度"""
        self._completed_operations = min(max(current, 0), self._total_operations)
        
        if self.progress_bar:
            self.progress_bar.set_progress(current, description)
        
        # 调用回调
        if self.update_callback:
            elapsed_time = time.time() - self.start_time
            progress_info = ProgressInfo(
                current=self._completed_operations,
                total=self._total_operations,
                description=description or self._current_operation,
                elapsed_time=elapsed_time
            )
            self.update_callback(progress_info)
    
    def finish_operation(self, description: str = ""):
        """完成操作"""
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
        
        if description:
            print(description)
    
    def log_message(self, message: str, level: str = "INFO"):
        """记录消息"""
        # 如果正在显示进度条，先换行
        if self.progress_bar:
            print()
        
        timestamp = time.strftime("%H:%M:%S")
        print(f"[{timestamp}] {level}: {message}")
        
        # 如果有进度条，重新渲染
        if self.progress_bar:
            self.progress_bar._render()


class MultiStageProgress:
    """多阶段进度跟踪器"""
    
    def __init__(self, stages: list, reporter: Optional[ProgressReporter] = None):
        """
        初始化多阶段进度跟踪器
        
        Args:
            stages: 阶段列表，每个阶段为 (name, weight) 元组
            reporter: 进度报告器
        """
        self.stages = stages
        self.reporter = reporter or ProgressReporter()
        
        self.total_weight = sum(weight for _, weight in stages)
        self.current_stage_index = 0
        self.current_stage_progress = 0.0
        self.completed_weight = 0.0
    
    def start_stage(self, stage_name: str, total_items: int = 100):
        """开始新阶段"""
        # 找到阶段索引
        for i, (name, _) in enumerate(self.stages):
            if name == stage_name:
                self.current_stage_index = i
                break
        else:
            # 阶段未找到，添加新阶段
            self.stages.append((stage_name, 1.0))
            self.current_stage_index = len(self.stages) - 1
            self.total_weight += 1.0
        
        self.current_stage_progress = 0.0
        
        # 计算已完成的权重
        self.completed_weight = sum(
            weight for i, (_, weight) in enumerate(self.stages) 
            if i < self.current_stage_index
        )
        
        # 开始报告器操作
        if self.reporter:
            overall_progress = int((self.completed_weight / self.total_weight) * 100)
            self.reporter.start_operation(
                stage_name,
                total_items,
                f"Stage {self.current_stage_index + 1}/{len(self.stages)}: {stage_name} ({overall_progress}%)"
            )
    
    def update_stage_progress(self, increment: int = 1, description: Optional[str] = None):
        """更新当前阶段进度"""
        if self.current_stage_index < len(self.stages):
            if self.reporter:
                stage_name, _ = self.stages[self.current_stage_index]
                overall_progress = int(self._calculate_overall_progress() * 100)
                
                stage_desc = description or stage_name
                full_desc = f"Stage {self.current_stage_index + 1}/{len(self.stages)}: {stage_desc} ({overall_progress}%)"
                
                self.reporter.update_progress(increment, full_desc)
    
    def finish_stage(self):
        """完成当前阶段"""
        if self.reporter:
            self.reporter.finish_operation()
        
        self.current_stage_index += 1
        self.current_stage_progress = 0.0
    
    def _calculate_overall_progress(self) -> float:
        """计算总体进度"""
        if self.total_weight <= 0:
            return 0.0
        
        # 已完成阶段的权重
        completed_weight = sum(
            weight for i, (_, weight) in enumerate(self.stages)
            if i < self.current_stage_index
        )
        
        # 当前阶段的部分权重
        if self.current_stage_index < len(self.stages):
            _, current_stage_weight = self.stages[self.current_stage_index]
            if self.reporter and self.reporter._total_operations > 0:
                stage_completion = self.reporter._completed_operations / self.reporter._total_operations
                completed_weight += current_stage_weight * stage_completion
        
        return completed_weight / self.total_weight


class SpinnerProgress:
    """旋转器进度指示器"""
    
    def __init__(self, message: str = "Processing..."):
        """初始化旋转器"""
        self.message = message
        self.spinning = False
        self.spinner_chars = ['|', '/', '-', '\\']
        self.current_char = 0
        self.thread: Optional[threading.Thread] = None
    
    def start(self):
        """开始旋转器"""
        self.spinning = True
        self.thread = threading.Thread(target=self._spin, daemon=True)
        self.thread.start()
    
    def stop(self):
        """停止旋转器"""
        self.spinning = False
        if self.thread:
            self.thread.join()
        print(f'\r{" " * (len(self.message) + 10)}\r', end='', flush=True)
    
    def _spin(self):
        """旋转动画"""
        while self.spinning:
            char = self.spinner_chars[self.current_char]
            print(f'\r{char} {self.message}', end='', flush=True)
            self.current_char = (self.current_char + 1) % len(self.spinner_chars)
            time.sleep(0.1)