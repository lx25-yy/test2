# -*- coding: utf-8 -*-
"""
CLI Commands implementation

Implements individual command handlers for the CLI interface.
"""

import sys
import json
import time
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
import argparse

from ..core.config import ConfigManager
from ..core.logger import log_manager
from ..core.pipeline import DICOMFeaturePipeline
from ..output.data_structures import OutputFormat, CompressionType
from ..output.output_manager import FeatureOutputManager
from ..data.loaders import DICOMLoaderFactory
from .progress import ProgressReporter, ConsoleProgressBar


class BaseCommand(ABC):
    """命令基类"""
    
    @staticmethod
    @abstractmethod
    def add_arguments(parser: argparse.ArgumentParser):
        """添加命令参数"""
        pass
    
    @abstractmethod
    def execute(self, args: argparse.Namespace) -> bool:
        """执行命令"""
        pass


class ExtractCommand(BaseCommand):
    """特征提取命令"""
    
    @staticmethod
    def add_arguments(parser: argparse.ArgumentParser):
        """添加extract命令参数"""
        parser.add_argument(
            'input_dir',
            type=str,
            help='Input directory containing DICOM files'
        )
        parser.add_argument(
            'output_dir',
            type=str,
            help='Output directory for extracted features'
        )
        
        # Feature extraction options
        parser.add_argument(
            '--target-layer',
            type=str,
            default='layer4.2.conv3',
            help='Target ResNet50 layer for feature extraction (default: layer4.2.conv3)'
        )
        parser.add_argument(
            '--image-size',
            type=int,
            nargs=2,
            default=[224, 224],
            metavar=('WIDTH', 'HEIGHT'),
            help='Input image size (default: 224 224)'
        )
        parser.add_argument(
            '--device',
            type=str,
            choices=['auto', 'cpu', 'cuda'],
            default='auto',
            help='Processing device (default: auto)'
        )
        
        # Batch processing options
        parser.add_argument(
            '--batch-size',
            type=int,
            help='Batch size for processing (default: auto-optimize)'
        )
        parser.add_argument(
            '--no-batch-optimization',
            action='store_true',
            help='Disable automatic batch size optimization'
        )
        parser.add_argument(
            '--memory-threshold',
            type=float,
            default=0.85,
            help='Memory usage threshold for batch optimization (default: 0.85)'
        )
        
        # Output options
        parser.add_argument(
            '--format', '--formats',
            type=str,
            nargs='+',
            choices=[fmt.value for fmt in OutputFormat],
            default=['numpy'],
            help='Output format(s) (default: numpy)'
        )
        parser.add_argument(
            '--compression',
            type=str,
            choices=[comp.value for comp in CompressionType],
            default='gzip',
            help='Compression type (default: gzip)'
        )
        parser.add_argument(
            '--filename-prefix',
            type=str,
            default='features',
            help='Output filename prefix (default: features)'
        )
        parser.add_argument(
            '--chunk-size',
            type=int,
            help='Chunk size for large datasets'
        )
        
        # Processing options
        parser.add_argument(
            '--recursive',
            action='store_true',
            help='Recursively scan subdirectories'
        )
        parser.add_argument(
            '--file-patterns',
            type=str,
            nargs='+',
            default=['*.dcm', '*.DCM'],
            help='File patterns to match (default: *.dcm *.DCM)'
        )
        parser.add_argument(
            '--continue-on-error',
            action='store_true',
            default=True,
            help='Continue processing on individual file errors'
        )
        parser.add_argument(
            '--max-error-rate',
            type=float,
            default=0.5,
            help='Maximum allowed error rate (default: 0.5)'
        )
        
        # Validation options
        parser.add_argument(
            '--no-validate',
            action='store_true',
            help='Skip output validation'
        )
        parser.add_argument(
            '--no-metadata',
            action='store_true',
            help='Skip metadata inclusion in output'
        )
        
        # Display options
        parser.add_argument(
            '--no-progress',
            action='store_true',
            help='Hide progress bar'
        )
        parser.add_argument(
            '--save-config',
            type=str,
            help='Save configuration to file'
        )
    
    def execute(self, args: argparse.Namespace) -> bool:
        """执行特征提取"""
        try:
            # 验证输入目录
            input_dir = Path(args.input_dir)
            if not input_dir.exists():
                print(f"Error: Input directory does not exist: {input_dir}")
                return False
            
            if not input_dir.is_dir():
                print(f"Error: Input path is not a directory: {input_dir}")
                return False
            
            # 创建输出目录
            output_dir = Path(args.output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            
            print(f"DICOM Feature Extraction")
            print(f"========================")
            print(f"Input directory:  {input_dir}")
            print(f"Output directory: {output_dir}")
            print(f"Target layer:     {args.target_layer}")
            print(f"Image size:       {args.image_size[0]}x{args.image_size[1]}")
            print(f"Device:           {args.device}")
            print(f"Output formats:   {', '.join(args.format)}")
            print(f"Compression:      {args.compression}")
            print()
            
            # 创建流水线配置
            config = {
                'target_layer': args.target_layer,
                'image_size': args.image_size,
                'normalize_method': 'imagenet',
                'device': args.device,
                'batch_size': args.batch_size,
                'enable_batch_optimization': not args.no_batch_optimization,
                'memory_threshold': args.memory_threshold,
                'file_patterns': args.file_patterns,
                'recursive_scan': args.recursive,
                'output_formats': args.format,
                'compression': args.compression,
                'filename_prefix': args.filename_prefix,
                'chunk_size': args.chunk_size,
                'continue_on_error': args.continue_on_error,
                'max_error_rate': args.max_error_rate,
                'validate_outputs': not args.no_validate,
                'include_metadata': not args.no_metadata,
                'enable_progress_monitoring': not args.no_progress
            }
            
            # 保存配置（如果requested）
            if args.save_config:
                config_path = Path(args.save_config)
                with open(config_path, 'w', encoding='utf-8') as f:
                    json.dump(config, f, indent=2, ensure_ascii=False)
                print(f"Configuration saved to: {config_path}")
            
            # 创建进度报告器
            progress_reporter = None
            if not args.no_progress:
                progress_reporter = ProgressReporter()
            
            # 创建并执行流水线
            pipeline = DICOMFeaturePipeline()
            
            # 验证组件
            print("Validating pipeline components...")
            if not pipeline.validate_pipeline_components():
                print("Warning: Some pipeline components may not be available")
                print("This may affect functionality or performance")
            
            print("Starting feature extraction...")
            start_time = time.time()
            
            result = pipeline.execute_pipeline(
                str(input_dir), 
                str(output_dir), 
                config
            )
            
            execution_time = time.time() - start_time
            
            # 输出结果
            print(f"\nFeature Extraction Complete")
            print(f"===========================")
            print(f"Execution time:        {execution_time:.2f} seconds")
            print(f"Total images:          {result.total_images}")
            print(f"Successful extractions: {result.successful_extractions}")
            print(f"Failed extractions:    {result.failed_extractions}")
            print(f"Success rate:          {result.successful_extractions/result.total_images:.1%}" if result.total_images > 0 else "Success rate: N/A")
            print(f"Feature dimensions:    {result.feature_dimensions}")
            print(f"Processing time:       {result.processing_time:.2f} seconds")
            print(f"Output files created:  {len(result.output_files)}")
            
            if result.output_files:
                print(f"\nOutput files:")
                for output_file in result.output_files:
                    file_size = Path(output_file).stat().st_size / (1024 * 1024)  # MB
                    print(f"  - {Path(output_file).name} ({file_size:.2f} MB)")
            
            if result.error_log:
                print(f"\nErrors encountered:")
                for error in result.error_log[:5]:  # 显示前5个错误
                    print(f"  - {error}")
                if len(result.error_log) > 5:
                    print(f"  ... and {len(result.error_log) - 5} more errors")
            
            # 计算处理速度
            if result.processing_time > 0:
                images_per_second = result.total_images / result.processing_time
                print(f"\nPerformance: {images_per_second:.2f} images/second")
            
            success = result.successful_extractions > 0
            if success:
                print(f"\n[SUCCESS] Feature extraction completed successfully!")
            else:
                print(f"\n[FAILED] Feature extraction failed - no features extracted")
            
            return success
            
        except Exception as e:
            print(f"Error during feature extraction: {e}")
            return False


class ValidateCommand(BaseCommand):
    """DICOM文件验证命令"""
    
    @staticmethod
    def add_arguments(parser: argparse.ArgumentParser):
        """添加validate命令参数"""
        parser.add_argument(
            'input_dir',
            type=str,
            help='Directory containing DICOM files to validate'
        )
        parser.add_argument(
            '--recursive',
            action='store_true',
            help='Recursively scan subdirectories'
        )
        parser.add_argument(
            '--file-patterns',
            type=str,
            nargs='+',
            default=['*.dcm', '*.DCM'],
            help='File patterns to match (default: *.dcm *.DCM)'
        )
        parser.add_argument(
            '--detailed',
            action='store_true',
            help='Show detailed validation results'
        )
        parser.add_argument(
            '--report',
            type=str,
            help='Save validation report to file'
        )
    
    def execute(self, args: argparse.Namespace) -> bool:
        """执行DICOM文件验证"""
        try:
            input_dir = Path(args.input_dir)
            if not input_dir.exists():
                print(f"Error: Input directory does not exist: {input_dir}")
                return False
            
            print(f"DICOM File Validation")
            print(f"====================")
            print(f"Input directory: {input_dir}")
            print(f"Recursive scan:  {args.recursive}")
            print(f"File patterns:   {', '.join(args.file_patterns)}")
            print()
            
            # 扫描文件
            print("Scanning for DICOM files...")
            files = []
            for pattern in args.file_patterns:
                if args.recursive:
                    pattern_files = list(input_dir.rglob(pattern))
                else:
                    pattern_files = list(input_dir.glob(pattern))
                files.extend(pattern_files)
            
            files = list(set(files))  # 去重
            print(f"Found {len(files)} files to validate")
            
            if not files:
                print("No DICOM files found")
                return True
            
            # 创建DICOM加载器
            loader = DICOMLoaderFactory.create_standard_loader()
            
            # 验证文件
            valid_files = []
            invalid_files = []
            validation_results = {}
            
            print("\nValidating files...")
            
            for i, file_path in enumerate(files, 1):
                print(f"  [{i:4d}/{len(files)}] {file_path.name}", end='')
                
                try:
                    dicom_data = loader.load_dicom_file(str(file_path))
                    valid_files.append(file_path)
                    validation_results[str(file_path)] = {
                        'valid': True,
                        'patient_id': dicom_data.metadata.get('PatientID', 'Unknown'),
                        'modality': dicom_data.metadata.get('Modality', 'Unknown'),
                        'image_shape': dicom_data.pixel_array.shape,
                        'pixel_spacing': dicom_data.metadata.get('PixelSpacing', 'Unknown')
                    }
                    print(" [OK]")
                except Exception as e:
                    invalid_files.append(file_path)
                    validation_results[str(file_path)] = {
                        'valid': False,
                        'error': str(e)
                    }
                    print(" [FAIL]")
                    if args.detailed:
                        print(f"    Error: {e}")
            
            # 输出结果
            print(f"\nValidation Results")
            print(f"==================")
            print(f"Total files:   {len(files)}")
            print(f"Valid files:   {len(valid_files)}")
            print(f"Invalid files: {len(invalid_files)}")
            print(f"Success rate:  {len(valid_files)/len(files):.1%}")
            
            if args.detailed and valid_files:
                print(f"\nValid Files Details:")
                for file_path in valid_files[:10]:  # 显示前10个
                    result = validation_results[str(file_path)]
                    print(f"  {file_path.name}")
                    print(f"    Patient ID:    {result['patient_id']}")
                    print(f"    Modality:      {result['modality']}")
                    print(f"    Image shape:   {result['image_shape']}")
                    print(f"    Pixel spacing: {result['pixel_spacing']}")
                if len(valid_files) > 10:
                    print(f"  ... and {len(valid_files) - 10} more valid files")
            
            if invalid_files:
                print(f"\nInvalid Files:")
                for file_path in invalid_files[:10]:  # 显示前10个
                    print(f"  {file_path.name}")
                    if args.detailed:
                        error = validation_results[str(file_path)]['error']
                        print(f"    Error: {error}")
                if len(invalid_files) > 10:
                    print(f"  ... and {len(invalid_files) - 10} more invalid files")
            
            # 保存报告
            if args.report:
                report_path = Path(args.report)
                report_data = {
                    'validation_summary': {
                        'total_files': len(files),
                        'valid_files': len(valid_files),
                        'invalid_files': len(invalid_files),
                        'success_rate': len(valid_files)/len(files) if files else 0
                    },
                    'validation_results': validation_results
                }
                
                with open(report_path, 'w', encoding='utf-8') as f:
                    json.dump(report_data, f, indent=2, ensure_ascii=False, default=str)
                
                print(f"\nValidation report saved to: {report_path}")
            
            return len(invalid_files) == 0
            
        except Exception as e:
            print(f"Error during validation: {e}")
            return False


class ConfigCommand(BaseCommand):
    """配置管理命令"""
    
    @staticmethod
    def add_arguments(parser: argparse.ArgumentParser):
        """添加config命令参数"""
        subparsers = parser.add_subparsers(
            dest='config_action',
            help='Configuration actions'
        )
        
        # Create config
        create_parser = subparsers.add_parser(
            'create',
            help='Create configuration file'
        )
        create_parser.add_argument(
            'output_file',
            type=str,
            help='Output configuration file path'
        )
        create_parser.add_argument(
            '--template',
            type=str,
            choices=['basic', 'advanced', 'performance'],
            default='basic',
            help='Configuration template (default: basic)'
        )
        
        # Show config
        show_parser = subparsers.add_parser(
            'show',
            help='Show current configuration'
        )
        show_parser.add_argument(
            'config_file',
            type=str,
            nargs='?',
            help='Configuration file to show (default: system default)'
        )
        
        # Validate config
        validate_parser = subparsers.add_parser(
            'validate',
            help='Validate configuration file'
        )
        validate_parser.add_argument(
            'config_file',
            type=str,
            help='Configuration file to validate'
        )
    
    def execute(self, args: argparse.Namespace) -> bool:
        """执行配置管理"""
        try:
            if args.config_action == 'create':
                return self._create_config(args)
            elif args.config_action == 'show':
                return self._show_config(args)
            elif args.config_action == 'validate':
                return self._validate_config(args)
            else:
                print("Error: No config action specified")
                return False
        except Exception as e:
            print(f"Error: {e}")
            return False
    
    def _create_config(self, args: argparse.Namespace) -> bool:
        """创建配置文件"""
        templates = {
            'basic': {
                'target_layer': 'layer4.2.conv3',
                'image_size': [224, 224],
                'device': 'auto',
                'output_formats': ['numpy'],
                'compression': 'gzip'
            },
            'advanced': {
                'target_layer': 'layer4.2.conv3',
                'image_size': [224, 224],
                'device': 'auto',
                'batch_size': 16,
                'enable_batch_optimization': True,
                'memory_threshold': 0.85,
                'output_formats': ['numpy', 'json'],
                'compression': 'gzip',
                'chunk_size': 1000,
                'validate_outputs': True,
                'include_metadata': True
            },
            'performance': {
                'target_layer': 'layer4.2.conv3',
                'image_size': [224, 224],
                'device': 'cuda',
                'batch_size': 32,
                'enable_batch_optimization': True,
                'memory_threshold': 0.90,
                'output_formats': ['numpy'],
                'compression': 'none',
                'chunk_size': 2000,
                'validate_outputs': False,
                'include_metadata': False
            }
        }
        
        config_data = templates[args.template]
        
        output_path = Path(args.output_file)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(config_data, f, indent=2, ensure_ascii=False)
        
        print(f"Configuration file created: {output_path}")
        print(f"Template: {args.template}")
        return True
    
    def _show_config(self, args: argparse.Namespace) -> bool:
        """显示配置"""
        if args.config_file:
            config_path = Path(args.config_file)
            if not config_path.exists():
                print(f"Error: Configuration file not found: {config_path}")
                return False
            
            with open(config_path, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
            
            print(f"Configuration from: {config_path}")
        else:
            config_manager = ConfigManager()
            config = config_manager.get_default_config()
            config_data = config.to_dict()
            print("Default system configuration:")
        
        print(json.dumps(config_data, indent=2, ensure_ascii=False))
        return True
    
    def _validate_config(self, args: argparse.Namespace) -> bool:
        """验证配置文件"""
        config_path = Path(args.config_file)
        if not config_path.exists():
            print(f"Error: Configuration file not found: {config_path}")
            return False
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config_data = json.load(f)
            
            print(f"Configuration file: {config_path}")
            print("Status: Valid")
            print(f"Configuration entries: {len(config_data)}")
            
            # 验证关键字段
            required_fields = ['target_layer', 'image_size', 'device']
            missing_fields = [field for field in required_fields if field not in config_data]
            
            if missing_fields:
                print(f"Warning: Missing recommended fields: {', '.join(missing_fields)}")
            
            return True
            
        except json.JSONDecodeError as e:
            print(f"Error: Invalid JSON format: {e}")
            return False
        except Exception as e:
            print(f"Error: {e}")
            return False


class ListFormatsCommand(BaseCommand):
    """列出支持的输出格式命令"""
    
    @staticmethod
    def add_arguments(parser: argparse.ArgumentParser):
        """添加list-formats命令参数"""
        parser.add_argument(
            '--detailed',
            action='store_true',
            help='Show detailed format information'
        )
    
    def execute(self, args: argparse.Namespace) -> bool:
        """列出支持的输出格式"""
        try:
            output_manager = FeatureOutputManager()
            supported_formats = output_manager.get_supported_formats()
            
            print("Supported Output Formats")
            print("========================")
            
            format_info = {
                OutputFormat.NUMPY: {
                    'description': 'NumPy binary format (.npy/.npz)',
                    'features': ['Fast loading', 'Efficient storage', 'Python native'],
                    'use_case': 'Python-based machine learning workflows'
                },
                OutputFormat.CSV: {
                    'description': 'Comma-separated values (.csv)',
                    'features': ['Human readable', 'Excel compatible', 'Universal format'],
                    'use_case': 'Data analysis and visualization'
                },
                OutputFormat.JSON: {
                    'description': 'JavaScript Object Notation (.json)',
                    'features': ['Human readable', 'Metadata rich', 'Web compatible'],
                    'use_case': 'Web applications and APIs'
                },
                OutputFormat.HDF5: {
                    'description': 'Hierarchical Data Format 5 (.h5)',
                    'features': ['High performance', 'Scalable', 'Metadata support'],
                    'use_case': 'Large-scale scientific computing'
                },
                OutputFormat.PARQUET: {
                    'description': 'Apache Parquet columnar format (.parquet)',
                    'features': ['Columnar storage', 'High compression', 'Analytics optimized'],
                    'use_case': 'Big data analytics'
                },
                OutputFormat.PICKLE: {
                    'description': 'Python pickle format (.pkl)',
                    'features': ['Python objects', 'Complete serialization', 'Fast access'],
                    'use_case': 'Python model persistence'
                },
                OutputFormat.MATLAB: {
                    'description': 'MATLAB data format (.mat)',
                    'features': ['MATLAB compatible', 'Scientific format', 'Multi-dimensional'],
                    'use_case': 'MATLAB-based analysis'
                }
            }
            
            for fmt in supported_formats:
                available = output_manager.is_format_available(fmt)
                status = "[Available]" if available else "[Unavailable]"
                
                print(f"\n{fmt.value.upper():<10} {status}")
                
                if args.detailed and fmt in format_info:
                    info = format_info[fmt]
                    print(f"  Description: {info['description']}")
                    print(f"  Features:    {', '.join(info['features'])}")
                    print(f"  Use case:    {info['use_case']}")
                    
                    if not available:
                        print(f"  Note:        Requires additional dependencies")
            
            print(f"\nTotal formats: {len(supported_formats)}")
            available_count = sum(1 for fmt in supported_formats if output_manager.is_format_available(fmt))
            print(f"Available:     {available_count}")
            print(f"Unavailable:   {len(supported_formats) - available_count}")
            
            if not args.detailed:
                print(f"\nUse --detailed for more information about each format")
            
            return True
            
        except Exception as e:
            print(f"Error listing formats: {e}")
            return False


class BenchmarkCommand(BaseCommand):
    """系统性能基准测试命令"""
    
    @staticmethod
    def add_arguments(parser: argparse.ArgumentParser):
        """添加benchmark命令参数"""
        parser.add_argument(
            '--quick',
            action='store_true',
            help='Run quick benchmark (reduced test size)'
        )
        parser.add_argument(
            '--detailed',
            action='store_true',
            help='Show detailed benchmark results'
        )
        parser.add_argument(
            '--report',
            type=str,
            help='Save benchmark report to file'
        )
    
    def execute(self, args: argparse.Namespace) -> bool:
        """执行系统性能基准测试"""
        try:
            print("System Performance Benchmark")
            print("============================")
            
            # 系统信息
            import platform
            import psutil
            
            print(f"Platform:       {platform.platform()}")
            print(f"Python version: {platform.python_version()}")
            print(f"CPU cores:      {psutil.cpu_count(logical=False)} physical, {psutil.cpu_count(logical=True)} logical")
            print(f"Memory:         {psutil.virtual_memory().total / (1024**3):.1f} GB")
            
            # GPU信息
            try:
                import torch
                if torch.cuda.is_available():
                    gpu_count = torch.cuda.device_count()
                    print(f"GPU:            {gpu_count} device(s) available")
                    for i in range(gpu_count):
                        gpu_name = torch.cuda.get_device_name(i)
                        gpu_memory = torch.cuda.get_device_properties(i).total_memory / (1024**3)
                        print(f"  GPU {i}:        {gpu_name} ({gpu_memory:.1f} GB)")
                else:
                    print(f"GPU:            Not available")
            except ImportError:
                print(f"GPU:            PyTorch not available")
            
            print()
            
            # 组件验证
            print("Component Validation")
            print("-------------------")
            
            pipeline = DICOMFeaturePipeline()
            components_valid = pipeline.validate_pipeline_components()
            
            print(f"Pipeline components: {'[All available]' if components_valid else '[Some missing]'}")
            
            # 测试特征提取器性能
            print("\nFeature Extractor Benchmark")
            print("---------------------------")
            
            try:
                from ..models.feature_extractors import FeatureExtractorFactory
                import numpy as np
                
                # 创建特征提取器
                device = 'cuda' if torch.cuda.is_available() else 'cpu'
                extractor = FeatureExtractorFactory.create_resnet50_extractor(device=device)
                
                print(f"Device:         {device}")
                print(f"Model:          ResNet50")
                print(f"Target layer:   layer4.2.conv3")
                
                # 性能测试
                test_sizes = [1, 4, 8, 16] if not args.quick else [1, 4]
                image_size = (224, 224)
                
                for batch_size in test_sizes:
                    # 创建随机图像
                    dummy_images = np.random.rand(batch_size, 3, *image_size).astype(np.float32)
                    
                    # 预热
                    _ = extractor.extract_features(dummy_images[:1])
                    
                    # 基准测试
                    start_time = time.time()
                    features = extractor.extract_features(dummy_images)
                    end_time = time.time()
                    
                    processing_time = end_time - start_time
                    images_per_second = batch_size / processing_time
                    
                    print(f"Batch size {batch_size:2d}: {processing_time:.3f}s ({images_per_second:.1f} img/s)")
                
            except Exception as e:
                print(f"Feature extractor benchmark failed: {e}")
            
            # 输出格式性能测试
            print("\nOutput Format Benchmark")
            print("----------------------")
            
            try:
                from ..output.data_structures import FeatureDataset, FeatureRecord, OutputConfig
                
                # 创建测试数据集
                test_size = 100 if not args.quick else 10
                records = []
                
                for i in range(test_size):
                    record = FeatureRecord(
                        file_path=f"test_{i}.dcm",
                        features=np.random.randn(2048).astype(np.float32),
                        feature_dimensions=(2048,),
                        metadata={'test': 'data'},
                        extraction_timestamp=datetime.now(),
                        processing_time=1.0,
                        success=True
                    )
                    records.append(record)
                
                dataset = FeatureDataset(records)
                
                # 测试不同格式
                output_manager = FeatureOutputManager()
                test_formats = [OutputFormat.NUMPY, OutputFormat.JSON, OutputFormat.CSV]
                
                import tempfile
                with tempfile.TemporaryDirectory() as temp_dir:
                    for fmt in test_formats:
                        if not output_manager.is_format_available(fmt):
                            print(f"{fmt.value:<8}: Unavailable")
                            continue
                        
                        config = OutputConfig(
                            format=fmt,
                            output_path=temp_dir,
                            filename_prefix=f"benchmark_{fmt.value}",
                            compression=CompressionType.NONE
                        )
                        
                        start_time = time.time()
                        result = output_manager.save_features(dataset, config)
                        end_time = time.time()
                        
                        if result.success:
                            processing_time = end_time - start_time
                            records_per_second = test_size / processing_time
                            size_mb = result.output_size_mb
                            
                            print(f"{fmt.value:<8}: {processing_time:.3f}s ({records_per_second:.0f} rec/s, {size_mb:.2f} MB)")
                        else:
                            print(f"{fmt.value:<8}: Failed")
                
            except Exception as e:
                print(f"Output format benchmark failed: {e}")
            
            # 总结
            print(f"\nBenchmark Complete")
            print(f"==================")
            print(f"System appears {'ready' if components_valid else 'partially ready'} for DICOM feature extraction")
            
            if not components_valid:
                print(f"Recommendation: Install missing dependencies for full functionality")
            
            return True
            
        except Exception as e:
            print(f"Error during benchmark: {e}")
            return False