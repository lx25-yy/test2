"""
DICOM特征提取系统主入口文件

使用示例:
    python -m src.main --input ./dicom_files --output ./extracted_features --config ./config/default_config.json
"""

import argparse
import sys
from pathlib import Path
from typing import Optional

# 添加src目录到Python路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core.config import ConfigManager
from src.core.logger import log_manager
from src.core.exceptions import DICOMFeatureExtractionError, handle_exception_with_logging


def parse_arguments() -> argparse.Namespace:
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description="DICOM图像ResNet50特征提取系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例用法:
  python -m src.main --input ./dicom_files --output ./extracted_features
  python -m src.main --input ./dicom_files --output ./extracted_features --config ./config/custom_config.json
  python -m src.main --input ./dicom_files --output ./extracted_features --batch-size 16 --device cuda
        """
    )
    
    # 基本参数
    parser.add_argument(
        "--input", "-i",
        type=str,
        required=True,
        help="DICOM文件目录路径"
    )
    
    parser.add_argument(
        "--output", "-o", 
        type=str,
        required=True,
        help="特征输出目录路径"
    )
    
    parser.add_argument(
        "--config", "-c",
        type=str,
        default=None,
        help="配置文件路径 (默认使用内置配置)"
    )
    
    # 处理参数覆盖
    parser.add_argument(
        "--batch-size",
        type=int,
        help="批处理大小"
    )
    
    parser.add_argument(
        "--device",
        choices=["auto", "cuda", "cpu"],
        help="计算设备"
    )
    
    parser.add_argument(
        "--target-layer",
        type=str,
        help="ResNet50目标层名称"
    )
    
    parser.add_argument(
        "--output-formats",
        nargs="+",
        choices=["numpy", "hdf5", "csv"],
        help="输出格式"
    )
    
    parser.add_argument(
        "--log-level",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="日志级别"
    )
    
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="试运行模式，仅验证配置和输入"
    )
    
    parser.add_argument(
        "--version",
        action="version", 
        version="DICOM特征提取系统 v1.0.0"
    )
    
    return parser.parse_args()


def create_override_config(args: argparse.Namespace) -> dict:
    """根据命令行参数创建配置覆盖"""
    overrides = {}
    
    if args.batch_size is not None:
        overrides.setdefault("processing", {})["batch_size"] = args.batch_size
    
    if args.device is not None:
        overrides.setdefault("processing", {})["device"] = args.device
    
    if args.target_layer is not None:
        overrides.setdefault("model", {})["target_layer"] = args.target_layer
    
    if args.output_formats is not None:
        overrides.setdefault("output", {})["output_formats"] = args.output_formats
    
    if args.log_level is not None:
        overrides.setdefault("logging", {})["log_level"] = args.log_level
    
    return overrides


def validate_paths(input_path: str, output_path: str) -> tuple[Path, Path]:
    """验证输入和输出路径"""
    input_dir = Path(input_path)
    output_dir = Path(output_path)
    
    if not input_dir.exists():
        raise FileNotFoundError(f"输入目录不存在: {input_dir}")
    
    if not input_dir.is_dir():
        raise NotADirectoryError(f"输入路径不是目录: {input_dir}")
    
    # 创建输出目录
    output_dir.mkdir(parents=True, exist_ok=True)
    
    return input_dir, output_dir


def main():
    """主入口函数"""
    try:
        # 解析命令行参数
        args = parse_arguments()
        
        # 加载配置
        config_manager = ConfigManager()
        
        if args.config:
            config = config_manager.load_from_file(args.config)
        else:
            config = config_manager.get_default_config()
        
        # 应用命令行参数覆盖
        overrides = create_override_config(args)
        if overrides:
            config = config_manager.merge_configs(config, overrides)
        
        # 配置日志系统
        log_manager.configure_logging(config.logging)
        logger = log_manager.get_logger("Main")
        
        # 记录启动信息
        logger.info("DICOM特征提取系统启动", extra={
            "input_path": args.input,
            "output_path": args.output,
            "config_source": args.config or "default",
            "dry_run": args.dry_run
        })
        
        # 记录系统信息
        log_manager.log_system_info()
        
        # 验证路径
        input_dir, output_dir = validate_paths(args.input, args.output)
        
        # 保存实际使用的配置
        if config.output.backup_original_config:
            config_backup_path = output_dir / "used_config.json"
            config_manager.save_config(config, config_backup_path)
            logger.info(f"配置已备份到: {config_backup_path}")
        
        if args.dry_run:
            logger.info("试运行模式完成，配置和路径验证通过")
            return 0
        
        # TODO: 在后续任务中实现完整的流水线
        logger.info("注意: 完整的特征提取流水线将在后续任务中实现")
        logger.info("当前已完成: 项目结构、配置管理、日志系统")
        
        return 0
        
    except DICOMFeatureExtractionError as e:
        if 'logger' in locals():
            handle_exception_with_logging(logger, e)
        else:
            print(f"配置错误: {e}", file=sys.stderr)
        return 1
        
    except Exception as e:
        if 'logger' in locals():
            handle_exception_with_logging(logger, e)
        else:
            print(f"未预期错误: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())