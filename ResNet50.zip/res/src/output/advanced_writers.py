# -*- coding: utf-8 -*-
"""
Advanced feature output writers

Implements Parquet, Pickle, and MATLAB format writers.
"""

import os
import pickle
from typing import List, Tuple
import numpy as np
import pandas as pd
from datetime import datetime

from .writers import BaseFeatureWriter
from .data_structures import FeatureDataset, OutputConfig, ChunkInfo, CompressionType
from ..core.logger import log_manager


class ParquetFeatureWriter(BaseFeatureWriter):
    """Parquet格式特征写入器"""
    
    def __init__(self):
        super().__init__()
        try:
            import pyarrow.parquet as pq
            import pyarrow as pa
            self.pq = pq
            self.pa = pa
        except ImportError:
            raise ImportError("pyarrow is required for Parquet output format")
    
    def get_file_extension(self) -> str:
        return ".parquet"
    
    def estimate_output_size(self, dataset: FeatureDataset, config: OutputConfig) -> int:
        """估算Parquet输出文件大小"""
        feature_matrix = dataset.feature_matrix
        if feature_matrix is None:
            return 0
        
        # Parquet是列式存储，压缩效果很好
        base_size = feature_matrix.nbytes
        
        # Parquet通常比原始数据小20-50%
        estimated_size = int(base_size * 0.6)
        
        # 考虑额外压缩
        if config.compression != CompressionType.NONE:
            compression_ratios = {
                CompressionType.GZIP: 0.7,  # Parquet已经压缩，额外压缩效果有限
                CompressionType.LZMA: 0.6,
                CompressionType.SNAPPY: 0.8,
                CompressionType.LZ4: 0.8,
            }
            ratio = compression_ratios.get(config.compression, 0.7)
            estimated_size = int(estimated_size * ratio)
        
        return estimated_size
    
    def _write_chunk(self, dataset: FeatureDataset, config: OutputConfig,
                    chunk: ChunkInfo) -> Tuple[List[str], List[str]]:
        """写入Parquet数据分块"""
        successful_records = [r for r in dataset.records if r.success]
        chunk_records = successful_records[chunk.start_index:chunk.end_index]
        
        if not chunk_records:
            return [], []
        
        # 构建DataFrame
        features = np.stack([r.features for r in chunk_records])
        file_paths = [r.file_path for r in chunk_records]
        
        # 创建列名
        feature_columns = [f"feature_{i:04d}" for i in range(features.shape[1])]
        
        # 构建DataFrame
        data = {'file_path': file_paths}
        for i, col in enumerate(feature_columns):
            data[col] = features[:, i]
        
        df = pd.DataFrame(data)
        
        # 添加元数据列
        if config.include_metadata:
            timestamps = [r.extraction_timestamp.isoformat() for r in chunk_records]
            processing_times = [r.processing_time for r in chunk_records]
            
            df['extraction_timestamp'] = timestamps
            df['processing_time'] = processing_times
        
        output_file = chunk.chunk_file_path
        
        # 设置Parquet压缩选项
        compression_map = {
            CompressionType.NONE: None,
            CompressionType.GZIP: 'gzip',
            CompressionType.SNAPPY: 'snappy',
            CompressionType.LZ4: 'lz4',
            CompressionType.BZIP2: 'gzip',  # Parquet不直接支持bzip2，使用gzip
            CompressionType.LZMA: 'gzip',   # Parquet不直接支持lzma，使用gzip
        }
        
        compression = compression_map.get(config.compression, None)
        
        # 写入Parquet文件
        df.to_parquet(
            output_file,
            compression=compression,
            index=False,
            engine='pyarrow'
        )
        
        return [output_file], []
    
    def validate_output(self, output_files: List[str], original_dataset: FeatureDataset) -> bool:
        """验证Parquet输出文件"""
        try:
            total_loaded_records = 0
            
            for file_path in output_files:
                df = pd.read_parquet(file_path, engine='pyarrow')
                
                if df.empty:
                    return False
                
                # 检查必需的列
                if 'file_path' not in df.columns:
                    return False
                
                # 检查特征列
                feature_columns = [col for col in df.columns if col.startswith('feature_')]
                if not feature_columns:
                    return False
                
                total_loaded_records += len(df)
            
            # 验证记录数量
            expected_records = len([r for r in original_dataset.records if r.success])
            return total_loaded_records == expected_records
            
        except Exception as e:
            self.logger.error(f"Parquet validation failed: {e}")
            return False


class PickleFeatureWriter(BaseFeatureWriter):
    """Pickle格式特征写入器"""
    
    def get_file_extension(self) -> str:
        return ".pkl"
    
    def estimate_output_size(self, dataset: FeatureDataset, config: OutputConfig) -> int:
        """估算Pickle输出文件大小"""
        feature_matrix = dataset.feature_matrix
        if feature_matrix is None:
            return 0
        
        # Pickle通常比原始数据大10-20%
        base_size = feature_matrix.nbytes
        estimated_size = int(base_size * 1.15)
        
        # 考虑压缩
        if config.compression != CompressionType.NONE:
            compression_ratios = {
                CompressionType.GZIP: 0.3,
                CompressionType.LZMA: 0.25,
                CompressionType.BZIP2: 0.3,
                CompressionType.LZ4: 0.5,
            }
            ratio = compression_ratios.get(config.compression, 0.4)
            estimated_size = int(estimated_size * ratio)
        
        return estimated_size
    
    def _write_chunk(self, dataset: FeatureDataset, config: OutputConfig,
                    chunk: ChunkInfo) -> Tuple[List[str], List[str]]:
        """写入Pickle数据分块"""
        successful_records = [r for r in dataset.records if r.success]
        chunk_records = successful_records[chunk.start_index:chunk.end_index]
        
        if not chunk_records:
            return [], []
        
        # 构建pickle数据结构
        pickle_data = {
            'metadata': {
                'chunk_index': chunk.chunk_index,
                'chunk_size': chunk.chunk_size,
                'feature_dimensions': chunk_records[0].feature_dimensions,
                'creation_timestamp': datetime.now(),
                'dataset_metadata': dataset.dataset_metadata if config.include_metadata else None
            },
            'features': np.stack([r.features for r in chunk_records]),
            'file_paths': [r.file_path for r in chunk_records],
            'extraction_timestamps': [r.extraction_timestamp for r in chunk_records],
            'processing_times': [r.processing_time for r in chunk_records]
        }
        
        if config.include_metadata:
            pickle_data['record_metadata'] = [r.metadata for r in chunk_records]
        
        output_file = chunk.chunk_file_path
        
        # 写入Pickle文件
        if config.compression == CompressionType.NONE:
            with open(output_file, 'wb') as f:
                pickle.dump(pickle_data, f, protocol=pickle.HIGHEST_PROTOCOL)
        else:
            # 压缩写入
            import gzip, lzma, bz2
            
            compression_modules = {
                CompressionType.GZIP: gzip,
                CompressionType.LZMA: lzma,
                CompressionType.BZIP2: bz2,
            }
            
            if config.compression in compression_modules:
                module = compression_modules[config.compression]
                compressed_file = output_file.replace('.pkl', f'.pkl.{config.compression.value}')
                
                with module.open(compressed_file, 'wb') as f:
                    pickle.dump(pickle_data, f, protocol=pickle.HIGHEST_PROTOCOL)
                
                output_file = compressed_file
            else:
                # 回退到无压缩
                with open(output_file, 'wb') as f:
                    pickle.dump(pickle_data, f, protocol=pickle.HIGHEST_PROTOCOL)
        
        return [output_file], []
    
    def validate_output(self, output_files: List[str], original_dataset: FeatureDataset) -> bool:
        """验证Pickle输出文件"""
        try:
            total_loaded_records = 0
            
            for file_path in output_files:
                # 根据文件扩展名确定如何读取
                if file_path.endswith('.gz'):
                    import gzip
                    with gzip.open(file_path, 'rb') as f:
                        data = pickle.load(f)
                elif file_path.endswith('.bz2'):
                    import bz2
                    with bz2.open(file_path, 'rb') as f:
                        data = pickle.load(f)
                elif file_path.endswith('.lzma'):
                    import lzma
                    with lzma.open(file_path, 'rb') as f:
                        data = pickle.load(f)
                else:
                    with open(file_path, 'rb') as f:
                        data = pickle.load(f)
                
                if not isinstance(data, dict):
                    return False
                
                # 检查必需的键
                required_keys = ['features', 'file_paths']
                for key in required_keys:
                    if key not in data:
                        return False
                
                features = data['features']
                file_paths = data['file_paths']
                
                if features is None or features.size == 0:
                    return False
                
                if len(file_paths) != features.shape[0]:
                    return False
                
                total_loaded_records += features.shape[0]
            
            # 验证记录数量
            expected_records = len([r for r in original_dataset.records if r.success])
            return total_loaded_records == expected_records
            
        except Exception as e:
            self.logger.error(f"Pickle validation failed: {e}")
            return False


class MatlabFeatureWriter(BaseFeatureWriter):
    """MATLAB格式特征写入器"""
    
    def __init__(self):
        super().__init__()
        try:
            import scipy.io as sio
            self.sio = sio
        except ImportError:
            raise ImportError("scipy is required for MATLAB output format")
    
    def get_file_extension(self) -> str:
        return ".mat"
    
    def estimate_output_size(self, dataset: FeatureDataset, config: OutputConfig) -> int:
        """估算MATLAB输出文件大小"""
        feature_matrix = dataset.feature_matrix
        if feature_matrix is None:
            return 0
        
        # MATLAB格式通常比原始数据大5-15%
        base_size = feature_matrix.nbytes
        estimated_size = int(base_size * 1.1)
        
        # MATLAB格式不直接支持压缩，但可以外部压缩
        if config.compression != CompressionType.NONE:
            compression_ratios = {
                CompressionType.GZIP: 0.35,
                CompressionType.LZMA: 0.3,
                CompressionType.BZIP2: 0.35,
            }
            ratio = compression_ratios.get(config.compression, 0.4)
            estimated_size = int(estimated_size * ratio)
        
        return estimated_size
    
    def _write_chunk(self, dataset: FeatureDataset, config: OutputConfig,
                    chunk: ChunkInfo) -> Tuple[List[str], List[str]]:
        """写入MATLAB数据分块"""
        successful_records = [r for r in dataset.records if r.success]
        chunk_records = successful_records[chunk.start_index:chunk.end_index]
        
        if not chunk_records:
            return [], []
        
        # 构建MATLAB数据结构
        features = np.stack([r.features for r in chunk_records])
        
        # MATLAB变量名必须是有效的标识符
        matlab_data = {
            'features': features,
            'file_paths': np.array([r.file_path for r in chunk_records], dtype=object),
            'feature_dimensions': np.array(chunk_records[0].feature_dimensions),
            'chunk_info': {
                'chunk_index': chunk.chunk_index,
                'chunk_size': chunk.chunk_size,
                'start_index': chunk.start_index,
                'end_index': chunk.end_index
            }
        }
        
        if config.include_metadata:
            matlab_data['extraction_timestamps'] = np.array([
                r.extraction_timestamp.isoformat() for r in chunk_records
            ], dtype=object)
            matlab_data['processing_times'] = np.array([
                r.processing_time for r in chunk_records
            ])
            
            # 添加数据集元数据
            matlab_data['dataset_metadata'] = dataset.dataset_metadata
        
        output_file = chunk.chunk_file_path
        
        # 写入MATLAB文件
        try:
            self.sio.savemat(
                output_file,
                matlab_data,
                format='5',  # MATLAB v5格式，兼容性最好
                long_field_names=True,
                do_compression=False,  # 使用外部压缩
                oned_as='row'
            )
        except Exception as e:
            # 如果失败，尝试更简单的格式
            self.logger.warning(f"Failed to save with metadata, saving simplified version: {e}")
            
            simplified_data = {
                'features': features,
                'file_paths': np.array([r.file_path for r in chunk_records], dtype=object)
            }
            
            self.sio.savemat(output_file, simplified_data, format='5')
        
        # 如果需要压缩，创建压缩版本
        if config.compression != CompressionType.NONE:
            import gzip, lzma, bz2
            
            compression_modules = {
                CompressionType.GZIP: gzip,
                CompressionType.LZMA: lzma,
                CompressionType.BZIP2: bz2,
            }
            
            if config.compression in compression_modules:
                module = compression_modules[config.compression]
                compressed_file = output_file.replace('.mat', f'.mat.{config.compression.value}')
                
                with open(output_file, 'rb') as f_in:
                    with module.open(compressed_file, 'wb') as f_out:
                        f_out.write(f_in.read())
                
                # 删除原始文件，保留压缩文件
                os.remove(output_file)
                output_file = compressed_file
        
        return [output_file], []
    
    def validate_output(self, output_files: List[str], original_dataset: FeatureDataset) -> bool:
        """验证MATLAB输出文件"""
        try:
            total_loaded_records = 0
            
            for file_path in output_files:
                # 处理压缩文件
                if file_path.endswith(('.gz', '.bz2', '.lzma')):
                    import tempfile
                    import gzip, bz2, lzma
                    
                    # 创建临时文件来解压
                    with tempfile.NamedTemporaryFile(delete=False, suffix='.mat') as temp_file:
                        temp_path = temp_file.name
                    
                    try:
                        if file_path.endswith('.gz'):
                            with gzip.open(file_path, 'rb') as f_in:
                                with open(temp_path, 'wb') as f_out:
                                    f_out.write(f_in.read())
                        elif file_path.endswith('.bz2'):
                            with bz2.open(file_path, 'rb') as f_in:
                                with open(temp_path, 'wb') as f_out:
                                    f_out.write(f_in.read())
                        elif file_path.endswith('.lzma'):
                            with lzma.open(file_path, 'rb') as f_in:
                                with open(temp_path, 'wb') as f_out:
                                    f_out.write(f_in.read())
                        
                        # 读取解压后的文件
                        data = self.sio.loadmat(temp_path)
                    finally:
                        # 清理临时文件
                        if os.path.exists(temp_path):
                            os.remove(temp_path)
                else:
                    # 直接读取未压缩文件
                    data = self.sio.loadmat(file_path)
                
                # 检查必需的变量
                if 'features' not in data:
                    return False
                
                features = data['features']
                if features is None or features.size == 0:
                    return False
                
                # 检查文件路径
                if 'file_paths' in data:
                    file_paths = data['file_paths']
                    if len(file_paths) != features.shape[0]:
                        return False
                
                total_loaded_records += features.shape[0]
            
            # 验证记录数量
            expected_records = len([r for r in original_dataset.records if r.success])
            return total_loaded_records == expected_records
            
        except Exception as e:
            self.logger.error(f"MATLAB validation failed: {e}")
            return False