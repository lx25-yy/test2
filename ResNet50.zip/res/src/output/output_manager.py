# -*- coding: utf-8 -*-
"""
Core output management system

Provides unified interface for feature output operations.
"""

import os
import shutil
from typing import Dict, List, Any, Optional, Callable
from pathlib import Path
import time
from datetime import datetime

from .data_structures import (
    FeatureDataset, OutputConfig, OutputResult, OutputFormat, 
    CompressionType, SaveProgress, OutputValidationError,
    UnsupportedFormatError, estimate_memory_usage
)
from .writers import IFeatureWriter, NumpyFeatureWriter, HDF5FeatureWriter, CSVFeatureWriter, JSONFeatureWriter
from .advanced_writers import ParquetFeatureWriter, PickleFeatureWriter, MatlabFeatureWriter
from ..core.interfaces import IOutputManager
from ..core.exceptions import OutputError, ConfigurationError
from ..core.logger import log_manager


class OutputWriterFactory:
    """
    输出写入器工厂
    
    遵循Factory模式，根据配置创建适当的写入器。
    """
    
    _writers = {
        OutputFormat.NUMPY: NumpyFeatureWriter,
        OutputFormat.NUMPY_COMPRESSED: NumpyFeatureWriter,  # 使用压缩配置
        OutputFormat.HDF5: HDF5FeatureWriter,
        OutputFormat.CSV: CSVFeatureWriter,
        OutputFormat.JSON: JSONFeatureWriter,
        OutputFormat.PARQUET: ParquetFeatureWriter,
        OutputFormat.PICKLE: PickleFeatureWriter,
        OutputFormat.MATLAB: MatlabFeatureWriter,
    }
    
    @classmethod
    def create_writer(cls, output_format: OutputFormat) -> IFeatureWriter:
        """
        创建指定格式的写入器
        
        Args:
            output_format: 输出格式
            
        Returns:
            写入器实例
            
        Raises:
            UnsupportedFormatError: 不支持的格式
        """
        if output_format not in cls._writers:
            supported_formats = list(cls._writers.keys())
            raise UnsupportedFormatError(
                output_format.value, 
                [f.value for f in supported_formats]
            )
        
        writer_class = cls._writers[output_format]
        
        try:
            return writer_class()
        except ImportError as e:
            raise OutputError(
                "WriterFactory",
                output_format.value,
                f"Required dependencies not available: {str(e)}"
            )
        except Exception as e:
            raise OutputError(
                "WriterFactory",
                output_format.value,
                f"Failed to create writer: {str(e)}"
            )
    
    @classmethod
    def get_supported_formats(cls) -> List[OutputFormat]:
        """获取支持的输出格式列表"""
        return list(cls._writers.keys())
    
    @classmethod
    def is_format_supported(cls, output_format: OutputFormat) -> bool:
        """检查格式是否支持"""
        try:
            cls.create_writer(output_format)
            return True
        except (UnsupportedFormatError, OutputError):
            return False


class FeatureOutputManager(IOutputManager):
    """
    特征输出管理器
    
    提供统一的特征输出接口，支持多种格式和高级功能。
    """
    
    def __init__(self):
        """初始化输出管理器"""
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self._writer_factory = OutputWriterFactory()
        
        # 输出历史记录
        self._output_history = []
        
        self.logger.info("Feature output manager initialized")
    
    def save_features(self, dataset: FeatureDataset, config: OutputConfig,
                     progress_callback: Optional[Callable[[SaveProgress], None]] = None) -> OutputResult:
        """
        保存特征数据
        
        Args:
            dataset: 特征数据集
            config: 输出配置
            progress_callback: 进度回调函数
            
        Returns:
            输出结果
        """
        start_time = time.time()
        
        with log_manager.create_operation_context("save_features", 
                                                format=config.format.value,
                                                output_path=config.output_path):
            
            try:
                # 1. 验证配置
                self._validate_config(config)
                
                # 2. 验证数据集
                self._validate_dataset(dataset)
                
                # 3. 检查输出路径
                self._prepare_output_directory(config)
                
                # 4. 创建备份（如果需要）
                backup_info = None
                if config.create_backup:
                    backup_info = self._create_backup(config)
                
                # 5. 估算内存使用和优化配置
                optimized_config = self._optimize_config(dataset, config)
                
                # 6. 创建写入器并执行写入
                writer = self._writer_factory.create_writer(config.format)
                
                self.logger.info(f"Starting feature output: {config.format.value} format, "
                               f"{len(dataset.records)} records")
                
                result = writer.write(dataset, optimized_config, progress_callback)
                
                # 7. 后处理
                if result.success:
                    # 记录成功输出
                    self._record_output_history(dataset, optimized_config, result)
                    
                    self.logger.info(f"Feature output completed successfully: "
                                   f"{len(result.output_files)} files, "
                                   f"{result.output_size_mb:.2f} MB")
                else:
                    # 如果失败且有备份，考虑恢复
                    if backup_info and config.create_backup:
                        self._restore_from_backup(backup_info, config)
                    
                    self.logger.error(f"Feature output failed: {result.error_messages}")
                
                return result
                
            except Exception as e:
                error_msg = f"Feature output operation failed: {str(e)}"
                self.logger.error(error_msg)
                
                # 创建失败结果
                result = OutputResult(
                    success=False,
                    output_files=[],
                    metadata_files=[],
                    total_records=len(dataset.records),
                    successful_records=0,
                    failed_records=len(dataset.records),
                    output_size_bytes=0,
                    processing_time=time.time() - start_time,
                    error_messages=[error_msg]
                )
                
                return result
    
    def save_features_multi_format(self, dataset: FeatureDataset, 
                                  configs: List[OutputConfig],
                                  progress_callback: Optional[Callable[[str, SaveProgress], None]] = None) -> Dict[str, OutputResult]:
        """
        以多种格式保存特征数据
        
        Args:
            dataset: 特征数据集
            configs: 输出配置列表
            progress_callback: 进度回调函数，接收(format_name, progress)参数
            
        Returns:
            每种格式的输出结果字典
        """
        results = {}
        
        self.logger.info(f"Starting multi-format output: {len(configs)} formats")
        
        for i, config in enumerate(configs):
            format_name = config.format.value
            
            try:
                self.logger.info(f"Processing format {i+1}/{len(configs)}: {format_name}")
                
                # 创建格式特定的进度回调
                format_progress_callback = None
                if progress_callback:
                    format_progress_callback = lambda p: progress_callback(format_name, p)
                
                result = self.save_features(dataset, config, format_progress_callback)
                results[format_name] = result
                
                if result.success:
                    self.logger.info(f"Format {format_name} completed successfully")
                else:
                    self.logger.error(f"Format {format_name} failed: {result.error_messages}")
                    
            except Exception as e:
                error_msg = f"Failed to process format {format_name}: {str(e)}"
                self.logger.error(error_msg)
                
                results[format_name] = OutputResult(
                    success=False,
                    output_files=[],
                    metadata_files=[],
                    total_records=len(dataset.records),
                    successful_records=0,
                    failed_records=len(dataset.records),
                    output_size_bytes=0,
                    processing_time=0.0,
                    error_messages=[error_msg]
                )
        
        # 输出总结
        successful_formats = [k for k, v in results.items() if v.success]
        failed_formats = [k for k, v in results.items() if not v.success]
        
        self.logger.info(f"Multi-format output completed: "
                        f"{len(successful_formats)} successful, "
                        f"{len(failed_formats)} failed")
        
        if failed_formats:
            self.logger.warning(f"Failed formats: {', '.join(failed_formats)}")
        
        return results
    
    def validate_output(self, output_files: List[str], original_dataset: FeatureDataset,
                       output_format: OutputFormat) -> bool:
        """
        验证输出文件
        
        Args:
            output_files: 输出文件列表
            original_dataset: 原始数据集
            output_format: 输出格式
            
        Returns:
            验证是否成功
        """
        try:
            writer = self._writer_factory.create_writer(output_format)
            return writer.validate_output(output_files, original_dataset)
        except Exception as e:
            self.logger.error(f"Output validation failed: {e}")
            return False
    
    def estimate_output_size(self, dataset: FeatureDataset, 
                           config: OutputConfig) -> int:
        """
        估算输出文件大小
        
        Args:
            dataset: 特征数据集
            config: 输出配置
            
        Returns:
            估算的文件大小（字节）
        """
        try:
            writer = self._writer_factory.create_writer(config.format)
            return writer.estimate_output_size(dataset, config)
        except Exception as e:
            self.logger.warning(f"Failed to estimate output size: {e}")
            return 0
    
    def get_output_history(self) -> List[Dict[str, Any]]:
        """获取输出历史记录"""
        return self._output_history.copy()
    
    def get_supported_formats(self) -> List[OutputFormat]:
        """获取支持的输出格式"""
        return self._writer_factory.get_supported_formats()
    
    def is_format_available(self, output_format: OutputFormat) -> bool:
        """检查格式是否可用（依赖已安装）"""
        return self._writer_factory.is_format_supported(output_format)
    
    def create_metadata_file(self, dataset: FeatureDataset, output_path: str,
                           include_statistics: bool = True) -> str:
        """
        创建独立的元数据文件
        
        Args:
            dataset: 特征数据集
            output_path: 输出路径
            include_statistics: 是否包含统计信息
            
        Returns:
            元数据文件路径
        """
        metadata = {
            'dataset_info': dataset.dataset_metadata,
            'creation_timestamp': datetime.now().isoformat(),
            'total_records': len(dataset.records),
            'successful_records': len([r for r in dataset.records if r.success]),
            'failed_records': len([r for r in dataset.records if not r.success]),
            'success_rate': dataset.success_rate
        }
        
        if include_statistics and dataset.feature_matrix is not None:
            features = dataset.feature_matrix
            metadata['feature_statistics'] = {
                'shape': features.shape,
                'dtype': str(features.dtype),
                'mean': float(features.mean()),
                'std': float(features.std()),
                'min': float(features.min()),
                'max': float(features.max())
            }
        
        # 写入元数据文件
        metadata_file = str(Path(output_path) / "dataset_metadata.json")
        
        import json
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
        
        return metadata_file
    
    def _validate_config(self, config: OutputConfig):
        """验证输出配置"""
        if not config.output_path:
            raise ConfigurationError("output_path", "Output path is required")
        
        if not config.filename_prefix:
            raise ConfigurationError("filename_prefix", "Filename prefix is required")
        
        # 检查格式是否支持
        if not self._writer_factory.is_format_supported(config.format):
            raise UnsupportedFormatError(
                config.format.value,
                [f.value for f in self._writer_factory.get_supported_formats()]
            )
    
    def _validate_dataset(self, dataset: FeatureDataset):
        """验证数据集"""
        if not dataset.records:
            raise OutputValidationError("Dataset is empty")
        
        successful_records = [r for r in dataset.records if r.success]
        if not successful_records:
            raise OutputValidationError("No successful records in dataset")
        
        # 验证特征维度一致性
        feature_dims = None
        for record in successful_records:
            if feature_dims is None:
                feature_dims = record.feature_dimensions
            elif record.feature_dimensions != feature_dims:
                raise OutputValidationError(
                    f"Inconsistent feature dimensions: {record.feature_dimensions} vs {feature_dims}"
                )
    
    def _prepare_output_directory(self, config: OutputConfig):
        """准备输出目录"""
        output_dir = Path(config.output_path)
        
        # 创建目录
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # 检查是否可写
        if not os.access(output_dir, os.W_OK):
            raise OutputError(
                "OutputManager",
                "prepare_directory",
                f"Output directory is not writable: {output_dir}"
            )
    
    def _create_backup(self, config: OutputConfig) -> Optional[Dict[str, Any]]:
        """创建备份"""
        output_dir = Path(config.output_path)
        
        if not output_dir.exists():
            return None
        
        # 查找现有输出文件
        pattern = f"{config.filename_prefix}*"
        existing_files = list(output_dir.glob(pattern))
        
        if not existing_files:
            return None
        
        # 创建备份目录
        backup_dir = output_dir / f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        backup_dir.mkdir(exist_ok=True)
        
        # 备份文件
        backed_up_files = []
        for file_path in existing_files:
            if file_path.is_file():
                backup_file = backup_dir / file_path.name
                shutil.copy2(file_path, backup_file)
                backed_up_files.append(str(backup_file))
        
        backup_info = {
            'backup_dir': str(backup_dir),
            'backed_up_files': backed_up_files,
            'original_files': [str(f) for f in existing_files],
            'timestamp': datetime.now()
        }
        
        self.logger.info(f"Created backup: {len(backed_up_files)} files in {backup_dir}")
        
        return backup_info
    
    def _restore_from_backup(self, backup_info: Dict[str, Any], config: OutputConfig):
        """从备份恢复"""
        if not backup_info:
            return
        
        try:
            backup_dir = Path(backup_info['backup_dir'])
            if not backup_dir.exists():
                return
            
            # 恢复备份文件
            restored_count = 0
            for backup_file in backup_info['backed_up_files']:
                backup_path = Path(backup_file)
                if backup_path.exists():
                    original_name = backup_path.name
                    restore_path = Path(config.output_path) / original_name
                    
                    shutil.copy2(backup_path, restore_path)
                    restored_count += 1
            
            self.logger.info(f"Restored {restored_count} files from backup")
            
        except Exception as e:
            self.logger.error(f"Failed to restore from backup: {e}")
    
    def _optimize_config(self, dataset: FeatureDataset, config: OutputConfig) -> OutputConfig:
        """优化配置以提高性能"""
        optimized_config = OutputConfig(
            format=config.format,
            output_path=config.output_path,
            filename_prefix=config.filename_prefix,
            compression=config.compression,
            compression_level=config.compression_level,
            include_metadata=config.include_metadata,
            include_failed_records=config.include_failed_records,
            chunk_size=config.chunk_size,
            overwrite=config.overwrite,
            create_backup=config.create_backup,
            validate_output=config.validate_output,
            csv_delimiter=config.csv_delimiter,
            csv_include_header=config.csv_include_header,
            json_indent=config.json_indent,
            hdf5_dataset_name=config.hdf5_dataset_name,
            hdf5_metadata_group=config.hdf5_metadata_group
        )
        
        # 优化分块大小
        if config.chunk_size is None:
            # 估算可用内存（假设有4GB可用）
            available_memory_mb = 4000
            estimated_memory = estimate_memory_usage(dataset, config.format, config.compression)
            
            if estimated_memory > available_memory_mb * 0.8:
                # 需要分块
                from .data_structures import calculate_optimal_chunk_size
                optimal_chunk_size = calculate_optimal_chunk_size(
                    dataset, available_memory_mb, config.format
                )
                optimized_config.chunk_size = optimal_chunk_size
                
                self.logger.info(f"Optimized chunk size: {optimal_chunk_size}")
        
        return optimized_config
    
    def _record_output_history(self, dataset: FeatureDataset, 
                              config: OutputConfig, result: OutputResult):
        """记录输出历史"""
        history_entry = {
            'timestamp': datetime.now(),
            'format': config.format.value,
            'output_path': config.output_path,
            'total_records': result.total_records,
            'successful_records': result.successful_records,
            'output_size_mb': result.output_size_mb,
            'processing_time': result.processing_time,
            'success': result.success,
            'output_files': result.output_files,
            'compression': config.compression.value
        }
        
        self._output_history.append(history_entry)
        
        # 保持历史记录在合理范围内
        if len(self._output_history) > 100:
            self._output_history = self._output_history[-100:]