# -*- coding: utf-8 -*-
"""
Feature output writers implementation

Implements various output format writers following Strategy pattern.
"""

import os
import json
import pickle
import hashlib
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Callable, Iterator, Tuple
from pathlib import Path
import numpy as np
import pandas as pd
from datetime import datetime
import time

from .data_structures import (
    FeatureDataset, OutputConfig, OutputResult, OutputFormat, 
    CompressionType, ChunkInfo, SaveProgress, OutputValidationError,
    UnsupportedFormatError, calculate_optimal_chunk_size
)
from ..core.interfaces import IOutputManager
from ..core.exceptions import OutputError
from ..core.logger import log_manager


class IFeatureWriter(ABC):
    """特征写入器接口"""
    
    @abstractmethod
    def write(self, dataset: FeatureDataset, config: OutputConfig, 
             progress_callback: Optional[Callable[[SaveProgress], None]] = None) -> OutputResult:
        """写入特征数据"""
        pass
    
    @abstractmethod
    def validate_output(self, output_files: List[str], 
                       original_dataset: FeatureDataset) -> bool:
        """验证输出文件"""
        pass
    
    @abstractmethod
    def get_file_extension(self) -> str:
        """获取文件扩展名"""
        pass
    
    @abstractmethod
    def estimate_output_size(self, dataset: FeatureDataset, 
                           config: OutputConfig) -> int:
        """估算输出文件大小（字节）"""
        pass


class BaseFeatureWriter(IFeatureWriter):
    """
    特征写入器基类
    
    提供通用功能和模板方法实现。
    """
    
    def __init__(self):
        """初始化基础写入器"""
        self.logger = log_manager.get_logger(self.__class__.__name__)
    
    def write(self, dataset: FeatureDataset, config: OutputConfig,
             progress_callback: Optional[Callable[[SaveProgress], None]] = None) -> OutputResult:
        """
        写入特征数据（模板方法）
        
        Args:
            dataset: 特征数据集
            config: 输出配置
            progress_callback: 进度回调函数
            
        Returns:
            输出结果
        """
        start_time = time.time()
        
        try:
            with log_manager.create_operation_context("feature_output_write"):
                
                # 1. 验证输入
                self._validate_inputs(dataset, config)
                
                # 2. 准备输出目录
                output_dir = Path(config.output_path)
                output_dir.mkdir(parents=True, exist_ok=True)
                
                # 3. 计算分块策略
                chunks = self._calculate_chunks(dataset, config)
                
                # 4. 初始化进度
                total_records = len([r for r in dataset.records if r.success])
                progress = SaveProgress(
                    total_chunks=len(chunks),
                    completed_chunks=0,
                    current_chunk=0,
                    total_records=total_records,
                    processed_records=0,
                    estimated_time_remaining=0.0,
                    current_operation="Preparing"
                )
                
                if progress_callback:
                    progress_callback(progress)
                
                # 5. 写入数据
                output_files = []
                metadata_files = []
                errors = []
                warnings = []
                
                for chunk_idx, chunk in enumerate(chunks):
                    try:
                        progress.current_chunk = chunk_idx
                        progress.current_operation = f"Writing chunk {chunk_idx + 1}/{len(chunks)}"
                        
                        if progress_callback:
                            progress_callback(progress)
                        
                        # 写入分块数据
                        chunk_files, chunk_metadata_files = self._write_chunk(
                            dataset, config, chunk
                        )
                        
                        output_files.extend(chunk_files)
                        metadata_files.extend(chunk_metadata_files)
                        
                        progress.completed_chunks += 1
                        progress.processed_records += chunk.chunk_size
                        
                        # 更新预估剩余时间
                        elapsed = time.time() - start_time
                        if progress.completed_chunks > 0:
                            avg_time_per_chunk = elapsed / progress.completed_chunks
                            remaining_chunks = progress.total_chunks - progress.completed_chunks
                            progress.estimated_time_remaining = avg_time_per_chunk * remaining_chunks
                        
                        if progress_callback:
                            progress_callback(progress)
                            
                    except Exception as e:
                        error_msg = f"Failed to write chunk {chunk_idx}: {str(e)}"
                        errors.append(error_msg)
                        self.logger.error(error_msg)
                        continue
                
                # 6. 写入全局元数据
                if config.include_metadata and output_files:
                    try:
                        metadata_file = self._write_metadata(dataset, config, output_files)
                        if metadata_file:
                            metadata_files.append(metadata_file)
                    except Exception as e:
                        warnings.append(f"Failed to write metadata: {str(e)}")
                
                # 7. 验证输出
                if config.validate_output and output_files:
                    try:
                        self._validate_all_outputs(output_files, dataset)
                    except Exception as e:
                        warnings.append(f"Output validation failed: {str(e)}")
                
                # 8. 计算总文件大小
                total_size = sum(
                    os.path.getsize(f) for f in output_files + metadata_files 
                    if os.path.exists(f)
                )
                
                processing_time = time.time() - start_time
                
                # 9. 创建输出结果
                result = OutputResult(
                    success=len(output_files) > 0,
                    output_files=output_files,
                    metadata_files=metadata_files,
                    total_records=len(dataset.records),
                    successful_records=total_records,
                    failed_records=len(dataset.records) - total_records,
                    output_size_bytes=total_size,
                    processing_time=processing_time,
                    error_messages=errors,
                    warnings=warnings
                )
                
                self.logger.info(f"Output completed: {len(output_files)} files, "
                               f"{result.output_size_mb:.2f} MB, "
                               f"{processing_time:.2f}s")
                
                return result
                
        except Exception as e:
            error_msg = f"Feature output failed: {str(e)}"
            self.logger.error(error_msg)
            
            return OutputResult(
                success=False,
                output_files=[],
                metadata_files=[],
                total_records=len(dataset.records),
                successful_records=0,
                failed_records=len(dataset.records),
                output_size_bytes=0,
                processing_time=time.time() - start_time,
                error_messages=[error_msg]
            )
    
    def _validate_inputs(self, dataset: FeatureDataset, config: OutputConfig):
        """验证输入参数"""
        if not dataset.records:
            raise OutputValidationError("Dataset is empty")
        
        successful_records = [r for r in dataset.records if r.success]
        if not successful_records:
            raise OutputValidationError("No successful records in dataset")
        
        if not config.output_path:
            raise OutputValidationError("Output path not specified")
    
    def _calculate_chunks(self, dataset: FeatureDataset, config: OutputConfig) -> List[ChunkInfo]:
        """计算分块策略"""
        successful_records = [r for r in dataset.records if r.success]
        total_records = len(successful_records)
        
        if not total_records:
            return []
        
        # 如果没有指定分块大小或者数据量小，使用单个分块
        if config.chunk_size is None or total_records <= config.chunk_size:
            chunk_size = total_records
            chunks = [ChunkInfo(
                chunk_index=0,
                chunk_size=chunk_size,
                start_index=0,
                end_index=chunk_size,
                chunk_file_path=self._generate_chunk_filename(config, 0, total_records == chunk_size),
                estimated_memory_mb=0.0  # 将在具体实现中计算
            )]
        else:
            # 多分块策略
            chunks = []
            chunk_size = config.chunk_size
            
            for i in range(0, total_records, chunk_size):
                end_idx = min(i + chunk_size, total_records)
                actual_chunk_size = end_idx - i
                
                chunk = ChunkInfo(
                    chunk_index=len(chunks),
                    chunk_size=actual_chunk_size,
                    start_index=i,
                    end_index=end_idx,
                    chunk_file_path=self._generate_chunk_filename(config, len(chunks), False),
                    estimated_memory_mb=0.0
                )
                chunks.append(chunk)
        
        return chunks
    
    def _generate_chunk_filename(self, config: OutputConfig, chunk_index: int, is_single: bool) -> str:
        """生成分块文件名"""
        base_name = config.filename_prefix
        extension = self.get_file_extension()
        
        if is_single:
            filename = f"{base_name}{extension}"
        else:
            filename = f"{base_name}_chunk_{chunk_index:04d}{extension}"
        
        return str(Path(config.output_path) / filename)
    
    def _write_metadata(self, dataset: FeatureDataset, config: OutputConfig, 
                       output_files: List[str]) -> Optional[str]:
        """写入元数据文件"""
        metadata = {
            'dataset_info': dataset.dataset_metadata,
            'output_config': {
                'format': config.format.value,
                'compression': config.compression.value,
                'compression_level': config.compression_level,
                'chunk_size': config.chunk_size,
                'creation_timestamp': datetime.now().isoformat()
            },
            'output_files': [Path(f).name for f in output_files],
            'file_checksums': self._calculate_checksums(output_files)
        }
        
        metadata_file = str(Path(config.output_path) / f"{config.filename_prefix}_metadata.json")
        
        try:
            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=config.json_indent, ensure_ascii=False)
            
            return metadata_file
        except Exception as e:
            self.logger.error(f"Failed to write metadata file: {e}")
            return None
    
    def _calculate_checksums(self, file_paths: List[str]) -> Dict[str, str]:
        """计算文件校验和"""
        checksums = {}
        
        for file_path in file_paths:
            try:
                if os.path.exists(file_path):
                    with open(file_path, 'rb') as f:
                        content = f.read()
                        checksum = hashlib.sha256(content).hexdigest()
                        checksums[Path(file_path).name] = checksum
            except Exception as e:
                self.logger.warning(f"Failed to calculate checksum for {file_path}: {e}")
        
        return checksums
    
    def _validate_all_outputs(self, output_files: List[str], dataset: FeatureDataset):
        """验证所有输出文件"""
        for file_path in output_files:
            if not os.path.exists(file_path):
                raise OutputValidationError(f"Output file not found: {file_path}")
            
            if os.path.getsize(file_path) == 0:
                raise OutputValidationError(f"Output file is empty: {file_path}")
        
        # 调用格式特定的验证
        if not self.validate_output(output_files, dataset):
            raise OutputValidationError("Format-specific validation failed")
    
    @abstractmethod
    def _write_chunk(self, dataset: FeatureDataset, config: OutputConfig, 
                    chunk: ChunkInfo) -> Tuple[List[str], List[str]]:
        """写入数据分块（子类实现）"""
        pass


class NumpyFeatureWriter(BaseFeatureWriter):
    """NumPy格式特征写入器"""
    
    def get_file_extension(self) -> str:
        """获取文件扩展名"""
        return ".npy"
    
    def estimate_output_size(self, dataset: FeatureDataset, config: OutputConfig) -> int:
        """估算输出文件大小"""
        feature_matrix = dataset.feature_matrix
        if feature_matrix is None:
            return 0
        
        base_size = feature_matrix.nbytes
        
        # 考虑NumPy格式开销（约10%）
        size_with_overhead = int(base_size * 1.1)
        
        # 考虑压缩（如果启用）
        if config.compression != CompressionType.NONE:
            # 粗略估算压缩比（取决于数据特性）
            compression_ratios = {
                CompressionType.GZIP: 0.3,
                CompressionType.LZMA: 0.25,
                CompressionType.BZIP2: 0.3,
                CompressionType.LZ4: 0.5,
            }
            ratio = compression_ratios.get(config.compression, 0.4)
            size_with_overhead = int(size_with_overhead * ratio)
        
        return size_with_overhead
    
    def _write_chunk(self, dataset: FeatureDataset, config: OutputConfig,
                    chunk: ChunkInfo) -> Tuple[List[str], List[str]]:
        """写入NumPy数据分块"""
        successful_records = [r for r in dataset.records if r.success]
        chunk_records = successful_records[chunk.start_index:chunk.end_index]
        
        if not chunk_records:
            return [], []
        
        # 构建特征矩阵
        features = np.stack([r.features for r in chunk_records])
        
        # 保存特征矩阵
        output_file = chunk.chunk_file_path
        
        if config.compression == CompressionType.NONE:
            np.save(output_file, features)
        else:
            # 使用压缩保存
            if config.compression == CompressionType.GZIP:
                np.savez_compressed(output_file.replace('.npy', '.npz'), features=features)
                output_file = output_file.replace('.npy', '.npz')
            else:
                # 对于其他压缩格式，使用pickle
                import lzma, bz2
                
                compression_modules = {
                    CompressionType.LZMA: lzma,
                    CompressionType.BZIP2: bz2,
                }
                
                if config.compression in compression_modules:
                    module = compression_modules[config.compression]
                    compressed_file = output_file.replace('.npy', f'.{config.compression.value}')
                    
                    with module.open(compressed_file, 'wb') as f:
                        np.save(f, features)
                    
                    output_file = compressed_file
                else:
                    # 回退到无压缩
                    np.save(output_file, features)
        
        return [output_file], []
    
    def validate_output(self, output_files: List[str], original_dataset: FeatureDataset) -> bool:
        """验证NumPy输出文件"""
        try:
            total_loaded_records = 0
            
            for file_path in output_files:
                if file_path.endswith('.npz'):
                    # 压缩的NumPy文件
                    with np.load(file_path) as data:
                        features = data['features']
                elif file_path.endswith(('.lzma', '.bz2')):
                    # 其他压缩格式
                    import lzma, bz2
                    modules = {'.lzma': lzma, '.bz2': bz2}
                    ext = next(e for e in modules.keys() if file_path.endswith(e))
                    
                    with modules[ext].open(file_path, 'rb') as f:
                        features = np.load(f)
                else:
                    # 普通NumPy文件
                    features = np.load(file_path)
                
                if features is None or features.size == 0:
                    return False
                
                total_loaded_records += features.shape[0]
            
            # 验证记录数量
            expected_records = len([r for r in original_dataset.records if r.success])
            return total_loaded_records == expected_records
            
        except Exception as e:
            self.logger.error(f"NumPy validation failed: {e}")
            return False


class HDF5FeatureWriter(BaseFeatureWriter):
    """HDF5格式特征写入器"""
    
    def __init__(self):
        super().__init__()
        try:
            import h5py
            self.h5py = h5py
        except ImportError:
            raise ImportError("h5py is required for HDF5 output format")
    
    def get_file_extension(self) -> str:
        return ".h5"
    
    def estimate_output_size(self, dataset: FeatureDataset, config: OutputConfig) -> int:
        """估算HDF5输出文件大小"""
        feature_matrix = dataset.feature_matrix
        if feature_matrix is None:
            return 0
        
        base_size = feature_matrix.nbytes
        
        # HDF5格式开销（约15-20%）
        size_with_overhead = int(base_size * 1.2)
        
        # 考虑压缩
        if config.compression != CompressionType.NONE:
            compression_ratios = {
                CompressionType.GZIP: 0.3,
                CompressionType.LZMA: 0.25,
                CompressionType.LZ4: 0.5,
            }
            ratio = compression_ratios.get(config.compression, 0.4)
            size_with_overhead = int(size_with_overhead * ratio)
        
        return size_with_overhead
    
    def _write_chunk(self, dataset: FeatureDataset, config: OutputConfig,
                    chunk: ChunkInfo) -> Tuple[List[str], List[str]]:
        """写入HDF5数据分块"""
        successful_records = [r for r in dataset.records if r.success]
        chunk_records = successful_records[chunk.start_index:chunk.end_index]
        
        if not chunk_records:
            return [], []
        
        output_file = chunk.chunk_file_path
        
        # 准备压缩选项
        compression_opts = None
        compression_filter = None
        
        if config.compression == CompressionType.GZIP:
            compression_filter = 'gzip'
            compression_opts = config.compression_level
        elif config.compression == CompressionType.LZ4:
            compression_filter = 'lz4'
        elif config.compression == CompressionType.LZMA:
            compression_filter = 'lzf'  # HDF5不直接支持LZMA，使用LZF替代
        
        with self.h5py.File(output_file, 'w') as f:
            # 写入特征数据
            features = np.stack([r.features for r in chunk_records])
            
            if compression_filter:
                f.create_dataset(
                    config.hdf5_dataset_name, 
                    data=features,
                    compression=compression_filter,
                    compression_opts=compression_opts,
                    shuffle=True  # 提高压缩效果
                )
            else:
                f.create_dataset(config.hdf5_dataset_name, data=features)
            
            # 写入文件路径
            file_paths = [r.file_path.encode('utf-8') for r in chunk_records]
            f.create_dataset('file_paths', data=file_paths)
            
            # 写入元数据
            if config.include_metadata:
                metadata_group = f.create_group(config.hdf5_metadata_group)
                
                # 数据集元数据
                for key, value in dataset.dataset_metadata.items():
                    if isinstance(value, (str, int, float, bool)):
                        metadata_group.attrs[key] = value
                    elif isinstance(value, list) and value:
                        # 处理列表类型
                        if isinstance(value[0], str):
                            metadata_group.attrs[key] = [s.encode('utf-8') for s in value]
                        else:
                            metadata_group.attrs[key] = value
                
                # 分块信息
                chunk_group = metadata_group.create_group('chunk_info')
                chunk_group.attrs['chunk_index'] = chunk.chunk_index
                chunk_group.attrs['chunk_size'] = chunk.chunk_size
                chunk_group.attrs['start_index'] = chunk.start_index
                chunk_group.attrs['end_index'] = chunk.end_index
        
        return [output_file], []
    
    def validate_output(self, output_files: List[str], original_dataset: FeatureDataset) -> bool:
        """验证HDF5输出文件"""
        try:
            total_loaded_records = 0
            
            for file_path in output_files:
                with self.h5py.File(file_path, 'r') as f:
                    # 检查必需的数据集
                    if 'features' not in f:
                        return False
                    
                    features = f['features'][()]
                    if features is None or features.size == 0:
                        return False
                    
                    total_loaded_records += features.shape[0]
                    
                    # 检查文件路径数据集
                    if 'file_paths' in f:
                        file_paths = f['file_paths'][()]
                        if len(file_paths) != features.shape[0]:
                            return False
            
            # 验证记录数量
            expected_records = len([r for r in original_dataset.records if r.success])
            return total_loaded_records == expected_records
            
        except Exception as e:
            self.logger.error(f"HDF5 validation failed: {e}")
            return False


class CSVFeatureWriter(BaseFeatureWriter):
    """CSV格式特征写入器"""
    
    def get_file_extension(self) -> str:
        return ".csv"
    
    def estimate_output_size(self, dataset: FeatureDataset, config: OutputConfig) -> int:
        """估算CSV输出文件大小"""
        feature_matrix = dataset.feature_matrix
        if feature_matrix is None:
            return 0
        
        # CSV是文本格式，通常比二进制格式大2-4倍
        # 假设每个数字平均10个字符（包括分隔符）
        num_features = feature_matrix.size
        estimated_size = num_features * 10
        
        # 添加文件路径列的估算大小
        avg_path_length = 50  # 平均文件路径长度
        estimated_size += feature_matrix.shape[0] * avg_path_length
        
        # 考虑压缩
        if config.compression != CompressionType.NONE:
            compression_ratios = {
                CompressionType.GZIP: 0.2,  # CSV压缩效果很好
                CompressionType.LZMA: 0.15,
                CompressionType.BZIP2: 0.2,
            }
            ratio = compression_ratios.get(config.compression, 0.3)
            estimated_size = int(estimated_size * ratio)
        
        return estimated_size
    
    def _write_chunk(self, dataset: FeatureDataset, config: OutputConfig,
                    chunk: ChunkInfo) -> Tuple[List[str], List[str]]:
        """写入CSV数据分块"""
        successful_records = [r for r in dataset.records if r.success]
        chunk_records = successful_records[chunk.start_index:chunk.end_index]
        
        if not chunk_records:
            return [], []
        
        # 构建DataFrame
        features = np.stack([r.features for r in chunk_records])
        file_paths = [r.file_path for r in chunk_records]
        
        # 创建列名
        feature_columns = [f"feature_{i:04d}" for i in range(features.shape[1])]
        columns = ['file_path'] + feature_columns
        
        # 构建数据
        data = np.column_stack([file_paths, features])
        df = pd.DataFrame(data, columns=columns)
        
        # 转换特征列为数值类型
        for col in feature_columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
        output_file = chunk.chunk_file_path
        
        # 写入CSV文件
        if config.compression == CompressionType.NONE:
            df.to_csv(
                output_file,
                sep=config.csv_delimiter,
                index=False,
                header=config.csv_include_header,
                float_format='%.6f'
            )
        else:
            # 压缩写入
            compression_map = {
                CompressionType.GZIP: 'gzip',
                CompressionType.BZIP2: 'bz2',
                CompressionType.LZMA: 'xz',
            }
            
            pandas_compression = compression_map.get(config.compression, None)
            if pandas_compression:
                compressed_file = output_file.replace('.csv', f'.csv.{pandas_compression}')
                df.to_csv(
                    compressed_file,
                    sep=config.csv_delimiter,
                    index=False,
                    header=config.csv_include_header,
                    float_format='%.6f',
                    compression=pandas_compression
                )
                output_file = compressed_file
            else:
                # 回退到无压缩
                df.to_csv(
                    output_file,
                    sep=config.csv_delimiter,
                    index=False,
                    header=config.csv_include_header,
                    float_format='%.6f'
                )
        
        return [output_file], []
    
    def validate_output(self, output_files: List[str], original_dataset: FeatureDataset) -> bool:
        """验证CSV输出文件"""
        try:
            total_loaded_records = 0
            
            for file_path in output_files:
                # 确定压缩类型
                compression = None
                if file_path.endswith('.gz') or file_path.endswith('.gzip'):
                    compression = 'gzip'
                elif file_path.endswith('.bz2'):
                    compression = 'bz2'
                elif file_path.endswith('.xz'):
                    compression = 'xz'
                
                df = pd.read_csv(file_path, compression=compression)
                
                if df.empty:
                    return False
                
                # 检查是否有file_path列
                if 'file_path' not in df.columns:
                    return False
                
                # 检查特征列数量
                feature_columns = [col for col in df.columns if col.startswith('feature_')]
                if not feature_columns:
                    return False
                
                total_loaded_records += len(df)
            
            # 验证记录数量
            expected_records = len([r for r in original_dataset.records if r.success])
            return total_loaded_records == expected_records
            
        except Exception as e:
            self.logger.error(f"CSV validation failed: {e}")
            return False


class JSONFeatureWriter(BaseFeatureWriter):
    """JSON格式特征写入器"""
    
    def get_file_extension(self) -> str:
        return ".json"
    
    def estimate_output_size(self, dataset: FeatureDataset, config: OutputConfig) -> int:
        """估算JSON输出文件大小"""
        feature_matrix = dataset.feature_matrix
        if feature_matrix is None:
            return 0
        
        # JSON是文本格式，通常比二进制格式大3-5倍
        # 考虑JSON结构开销
        num_features = feature_matrix.size
        estimated_size = num_features * 15  # 每个数字约15个字符（包括JSON结构）
        
        # 添加元数据和结构开销
        estimated_size = int(estimated_size * 1.3)
        
        # 考虑压缩
        if config.compression != CompressionType.NONE:
            compression_ratios = {
                CompressionType.GZIP: 0.25,
                CompressionType.LZMA: 0.2,
                CompressionType.BZIP2: 0.25,
            }
            ratio = compression_ratios.get(config.compression, 0.3)
            estimated_size = int(estimated_size * ratio)
        
        return estimated_size
    
    def _write_chunk(self, dataset: FeatureDataset, config: OutputConfig,
                    chunk: ChunkInfo) -> Tuple[List[str], List[str]]:
        """写入JSON数据分块"""
        successful_records = [r for r in dataset.records if r.success]
        chunk_records = successful_records[chunk.start_index:chunk.end_index]
        
        if not chunk_records:
            return [], []
        
        # 构建JSON数据结构
        json_data = {
            'metadata': {
                'chunk_index': chunk.chunk_index,
                'chunk_size': chunk.chunk_size,
                'feature_dimensions': chunk_records[0].feature_dimensions,
                'creation_timestamp': datetime.now().isoformat()
            },
            'records': []
        }
        
        for record in chunk_records:
            record_data = {
                'file_path': record.file_path,
                'features': record.features.tolist(),
                'extraction_timestamp': record.extraction_timestamp.isoformat(),
                'processing_time': record.processing_time
            }
            
            if config.include_metadata and record.metadata:
                record_data['metadata'] = record.metadata
            
            json_data['records'].append(record_data)
        
        output_file = chunk.chunk_file_path
        
        # 写入JSON文件
        if config.compression == CompressionType.NONE:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(json_data, f, indent=config.json_indent, ensure_ascii=False)
        else:
            # 压缩写入
            import gzip, lzma, bz2
            
            compression_modules = {
                CompressionType.GZIP: gzip,
                CompressionType.LZMA: lzma,
                CompressionType.BZIP2: bz2,
            }
            
            if config.compression in compression_modules:
                module = compression_modules[config.compression]
                compressed_file = output_file.replace('.json', f'.json.{config.compression.value}')
                
                with module.open(compressed_file, 'wt', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=config.json_indent, ensure_ascii=False)
                
                output_file = compressed_file
            else:
                # 回退到无压缩
                with open(output_file, 'w', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=config.json_indent, ensure_ascii=False)
        
        return [output_file], []
    
    def validate_output(self, output_files: List[str], original_dataset: FeatureDataset) -> bool:
        """验证JSON输出文件"""
        try:
            total_loaded_records = 0
            
            for file_path in output_files:
                # 根据文件扩展名确定如何读取
                if file_path.endswith('.gz'):
                    import gzip
                    with gzip.open(file_path, 'rt', encoding='utf-8') as f:
                        data = json.load(f)
                elif file_path.endswith('.bz2'):
                    import bz2
                    with bz2.open(file_path, 'rt', encoding='utf-8') as f:
                        data = json.load(f)
                elif file_path.endswith('.lzma'):
                    import lzma
                    with lzma.open(file_path, 'rt', encoding='utf-8') as f:
                        data = json.load(f)
                else:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                
                if not isinstance(data, dict) or 'records' not in data:
                    return False
                
                records = data['records']
                if not isinstance(records, list):
                    return False
                
                # 验证每个记录的结构
                for record in records:
                    if not isinstance(record, dict):
                        return False
                    if 'file_path' not in record or 'features' not in record:
                        return False
                    if not isinstance(record['features'], list):
                        return False
                
                total_loaded_records += len(records)
            
            # 验证记录数量
            expected_records = len([r for r in original_dataset.records if r.success])
            return total_loaded_records == expected_records
            
        except Exception as e:
            self.logger.error(f"JSON validation failed: {e}")
            return False