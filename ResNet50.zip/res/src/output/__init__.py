# -*- coding: utf-8 -*-
"""
Output module

Multi-format feature output system with advanced compression and validation.
"""

# Core data structures
from .data_structures import (
    OutputFormat, CompressionType, FeatureRecord, FeatureDataset,
    OutputConfig, OutputResult, ChunkInfo, SaveProgress,
    OutputValidationError, UnsupportedFormatError,
    estimate_memory_usage, calculate_optimal_chunk_size
)

# Writers and interfaces
from .writers import (
    IFeatureWriter, BaseFeatureWriter,
    NumpyFeatureWriter, HDF5FeatureWriter, CSVFeatureWriter, JSONFeatureWriter
)

from .advanced_writers import (
    ParquetFeatureWriter, PickleFeatureWriter, MatlabFeatureWriter
)

# Core output management
from .output_manager import (
    OutputWriterFactory, FeatureOutputManager
)

__all__ = [
    # Data structures and enums
    'OutputFormat',
    'CompressionType',
    'FeatureRecord',
    'FeatureDataset',
    'OutputConfig',
    'OutputResult',
    'ChunkInfo',
    'SaveProgress',
    
    # Exceptions
    'OutputValidationError',
    'UnsupportedFormatError',
    
    # Utility functions
    'estimate_memory_usage',
    'calculate_optimal_chunk_size',
    
    # Writer interfaces and implementations
    'IFeatureWriter',
    'BaseFeatureWriter',
    'NumpyFeatureWriter',
    'HDF5FeatureWriter',
    'CSVFeatureWriter',
    'JSONFeatureWriter',
    'ParquetFeatureWriter',
    'PickleFeatureWriter',
    'MatlabFeatureWriter',
    
    # Core management
    'OutputWriterFactory',
    'FeatureOutputManager'
]