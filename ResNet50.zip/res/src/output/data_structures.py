# -*- coding: utf-8 -*-
"""
Output data structures and types

Defines data structures for feature output management.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union, Tuple
from datetime import datetime
from pathlib import Path
import numpy as np
from enum import Enum


class OutputFormat(Enum):
    """支持的输出格式"""
    NUMPY = "numpy"
    NUMPY_COMPRESSED = "numpy_compressed"
    HDF5 = "hdf5"
    CSV = "csv"
    JSON = "json"
    PARQUET = "parquet"
    PICKLE = "pickle"
    MATLAB = "matlab"


class CompressionType(Enum):
    """压缩类型"""
    NONE = "none"
    GZIP = "gzip"
    LZMA = "lzma"
    BZIP2 = "bzip2"
    LZ4 = "lz4"
    SNAPPY = "snappy"


@dataclass
class FeatureRecord:
    """单个特征记录"""
    file_path: str
    features: np.ndarray
    feature_dimensions: Tuple[int, ...]
    metadata: Dict[str, Any]
    extraction_timestamp: datetime
    processing_time: float
    success: bool = True
    error_message: Optional[str] = None


@dataclass
class FeatureDataset:
    """特征数据集"""
    records: List[FeatureRecord]
    dataset_metadata: Dict[str, Any] = field(default_factory=dict)
    creation_timestamp: datetime = field(default_factory=datetime.now)
    
    def __post_init__(self):
        """后处理初始化"""
        if not self.dataset_metadata:
            self.dataset_metadata = self._generate_default_metadata()
    
    def _generate_default_metadata(self) -> Dict[str, Any]:
        """生成默认元数据"""
        successful_records = [r for r in self.records if r.success]
        
        if not successful_records:
            return {
                'total_records': len(self.records),
                'successful_records': 0,
                'failed_records': len(self.records),
                'feature_dimensions': None,
                'total_processing_time': sum(r.processing_time for r in self.records)
            }
        
        # 特征维度（假设所有成功的记录具有相同维度）
        feature_dims = successful_records[0].feature_dimensions
        
        return {
            'total_records': len(self.records),
            'successful_records': len(successful_records),
            'failed_records': len(self.records) - len(successful_records),
            'feature_dimensions': feature_dims,
            'total_processing_time': sum(r.processing_time for r in self.records),
            'average_processing_time': np.mean([r.processing_time for r in self.records]),
            'creation_timestamp': self.creation_timestamp.isoformat(),
            'source_files': [r.file_path for r in successful_records]
        }
    
    @property
    def feature_matrix(self) -> Optional[np.ndarray]:
        """获取特征矩阵"""
        successful_records = [r for r in self.records if r.success]
        if not successful_records:
            return None
        
        features = [r.features for r in successful_records]
        return np.stack(features)
    
    @property
    def file_paths(self) -> List[str]:
        """获取所有文件路径"""
        return [r.file_path for r in self.records if r.success]
    
    @property
    def success_rate(self) -> float:
        """计算成功率"""
        if not self.records:
            return 0.0
        successful = sum(1 for r in self.records if r.success)
        return successful / len(self.records)


@dataclass
class OutputConfig:
    """输出配置"""
    format: OutputFormat
    output_path: str
    filename_prefix: str = "features"
    compression: CompressionType = CompressionType.NONE
    compression_level: int = 6
    include_metadata: bool = True
    include_failed_records: bool = False
    chunk_size: Optional[int] = None  # 分块大小，用于大数据集
    overwrite: bool = False
    create_backup: bool = True
    validate_output: bool = True
    
    # 格式特定选项
    csv_delimiter: str = ","
    csv_include_header: bool = True
    json_indent: int = 2
    hdf5_dataset_name: str = "features"
    hdf5_metadata_group: str = "metadata"
    
    def __post_init__(self):
        """后处理验证"""
        self.output_path = str(Path(self.output_path).resolve())
        
        # 验证分块大小
        if self.chunk_size is not None and self.chunk_size < 1:
            raise ValueError("chunk_size must be positive")
        
        # 验证压缩级别
        if not (0 <= self.compression_level <= 9):
            raise ValueError("compression_level must be between 0 and 9")


@dataclass
class OutputResult:
    """输出结果"""
    success: bool
    output_files: List[str]
    metadata_files: List[str]
    total_records: int
    successful_records: int
    failed_records: int
    output_size_bytes: int
    processing_time: float
    error_messages: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    
    @property
    def success_rate(self) -> float:
        """计算成功率"""
        if self.total_records == 0:
            return 0.0
        return self.successful_records / self.total_records
    
    @property
    def output_size_mb(self) -> float:
        """输出大小（MB）"""
        return self.output_size_bytes / (1024 * 1024)


@dataclass
class ChunkInfo:
    """分块信息"""
    chunk_index: int
    chunk_size: int
    start_index: int
    end_index: int
    chunk_file_path: str
    estimated_memory_mb: float


@dataclass
class SaveProgress:
    """保存进度信息"""
    total_chunks: int
    completed_chunks: int
    current_chunk: int
    total_records: int
    processed_records: int
    estimated_time_remaining: float
    current_operation: str
    
    @property
    def completion_percentage(self) -> float:
        """完成百分比"""
        if self.total_chunks == 0:
            return 0.0
        return (self.completed_chunks / self.total_chunks) * 100
    
    @property
    def records_completion_percentage(self) -> float:
        """记录完成百分比"""
        if self.total_records == 0:
            return 0.0
        return (self.processed_records / self.total_records) * 100


class OutputValidationError(Exception):
    """输出验证错误"""
    
    def __init__(self, message: str, validation_details: Dict[str, Any] = None):
        super().__init__(message)
        self.validation_details = validation_details or {}


class UnsupportedFormatError(Exception):
    """不支持的格式错误"""
    
    def __init__(self, format_name: str, supported_formats: List[str] = None):
        message = f"Unsupported output format: {format_name}"
        if supported_formats:
            message += f". Supported formats: {', '.join(supported_formats)}"
        super().__init__(message)
        self.format_name = format_name
        self.supported_formats = supported_formats or []


def estimate_memory_usage(dataset: FeatureDataset, 
                         output_format: OutputFormat,
                         compression: CompressionType = CompressionType.NONE) -> float:
    """
    估算内存使用量（MB）
    
    Args:
        dataset: 特征数据集
        output_format: 输出格式
        compression: 压缩类型
        
    Returns:
        估算的内存使用量（MB）
    """
    if not dataset.records:
        return 0.0
    
    successful_records = [r for r in dataset.records if r.success]
    if not successful_records:
        return 0.0
    
    # 基础内存：特征矩阵
    feature_matrix = dataset.feature_matrix
    if feature_matrix is None:
        return 0.0
    
    base_memory_mb = feature_matrix.nbytes / (1024 * 1024)
    
    # 格式相关的内存开销
    format_multipliers = {
        OutputFormat.NUMPY: 1.1,  # 轻微开销
        OutputFormat.NUMPY_COMPRESSED: 1.5,  # 压缩过程中的临时内存
        OutputFormat.HDF5: 1.3,  # HDF5 缓冲
        OutputFormat.CSV: 2.5,  # 文本转换开销
        OutputFormat.JSON: 3.0,  # JSON序列化开销
        OutputFormat.PARQUET: 1.8,  # 列式存储转换
        OutputFormat.PICKLE: 1.2,  # 序列化开销
        OutputFormat.MATLAB: 1.4   # MATLAB格式转换
    }
    
    multiplier = format_multipliers.get(output_format, 1.5)
    
    # 压缩相关的额外开销
    if compression != CompressionType.NONE:
        multiplier *= 1.3
    
    return base_memory_mb * multiplier


def calculate_optimal_chunk_size(dataset: FeatureDataset,
                                available_memory_mb: float,
                                output_format: OutputFormat,
                                safety_factor: float = 0.7) -> int:
    """
    计算最优分块大小
    
    Args:
        dataset: 特征数据集
        available_memory_mb: 可用内存（MB）
        output_format: 输出格式
        safety_factor: 安全系数
        
    Returns:
        最优分块大小
    """
    if not dataset.records:
        return 1
    
    successful_records = [r for r in dataset.records if r.success]
    if not successful_records:
        return 1
    
    # 计算单个记录的平均内存使用
    single_record = successful_records[0]
    single_record_mb = single_record.features.nbytes / (1024 * 1024)
    
    # 考虑格式开销
    total_memory_per_record = estimate_memory_usage(
        FeatureDataset([single_record]), output_format
    )
    
    # 计算安全的分块大小
    safe_memory = available_memory_mb * safety_factor
    optimal_chunk_size = int(safe_memory / total_memory_per_record)
    
    # 确保至少为1，最多不超过总记录数
    return max(1, min(optimal_chunk_size, len(successful_records)))