"""
DICOM文件加载器实现 - 遵循单一职责原则和开闭原则

专注于DICOM文件的读取、验证和元数据提取功能。
"""

import os
import glob
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
import numpy as np
import pydicom
from pydicom.errors import InvalidDicomError
from pydicom.dataset import FileDataset

from ..core.interfaces import IDICOMLoader, DICOMImage
from ..core.exceptions import DICOMLoadError, DICOMValidationError
from ..core.logger import log_manager


class DICOMLoader(IDICOMLoader):
    """
    DICOM文件加载器实现
    
    遵循单一职责原则，专注于DICOM文件的加载和基本验证。
    """
    
    def __init__(self, validate_on_load: bool = True, force_pixel_data: bool = True):
        """
        初始化DICOM加载器
        
        Args:
            validate_on_load: 加载时是否进行验证
            force_pixel_data: 是否强制要求像素数据存在
        """
        self.validate_on_load = validate_on_load
        self.force_pixel_data = force_pixel_data
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.performance_logger = log_manager.get_performance_logger(self.__class__.__name__)
        
        # 支持的DICOM文件扩展名
        self.supported_extensions = {'.dcm', '.dicom', '.DCM', '.DICOM'}
        
        # 统计信息
        self.stats = {
            'files_processed': 0,
            'files_loaded': 0,
            'files_failed': 0,
            'validation_errors': 0
        }
    
    def load_dicom_file(self, file_path: str) -> DICOMImage:
        """
        加载单个DICOM文件
        
        Args:
            file_path: DICOM文件路径
            
        Returns:
            DICOMImage对象
            
        Raises:
            DICOMLoadError: 文件加载失败
            DICOMValidationError: 文件验证失败
        """
        file_path = Path(file_path)
        self.logger.debug(f"开始加载DICOM文件: {file_path}")
        
        with log_manager.create_operation_context("load_single_file", file_path=str(file_path)):
            try:
                self.stats['files_processed'] += 1
                
                # 检查文件存在性
                if not file_path.exists():
                    raise DICOMLoadError(str(file_path), "文件不存在")
                
                if not file_path.is_file():
                    raise DICOMLoadError(str(file_path), "路径不是文件")
                
                # 读取DICOM文件
                try:
                    dicom_dataset = pydicom.dcmread(str(file_path), force=True)
                except InvalidDicomError as e:
                    raise DICOMLoadError(str(file_path), f"无效的DICOM文件: {str(e)}")
                except Exception as e:
                    raise DICOMLoadError(str(file_path), f"读取文件失败: {str(e)}")
                
                # 验证DICOM文件
                if self.validate_on_load:
                    validation_result = self._validate_dicom_dataset(dicom_dataset, str(file_path))
                    if not validation_result['is_valid']:
                        self.stats['validation_errors'] += 1
                        raise DICOMValidationError(str(file_path), validation_result['errors'])
                
                # 提取像素数据
                pixel_data = self._extract_pixel_data(dicom_dataset, str(file_path))
                
                # 提取元数据
                metadata = self._extract_metadata(dicom_dataset)
                
                # 创建DICOMImage对象
                dicom_image = DICOMImage(
                    file_path=str(file_path),
                    pixel_data=pixel_data,
                    metadata=metadata,
                    original_shape=pixel_data.shape,
                    modality=getattr(dicom_dataset, 'Modality', 'Unknown'),
                    patient_id=getattr(dicom_dataset, 'PatientID', None)
                )
                
                self.stats['files_loaded'] += 1
                self.logger.debug(f"成功加载DICOM文件: {file_path}")
                
                return dicom_image
                
            except (DICOMLoadError, DICOMValidationError):
                self.stats['files_failed'] += 1
                raise
            except Exception as e:
                self.stats['files_failed'] += 1
                raise DICOMLoadError(str(file_path), f"加载过程中发生未预期错误: {str(e)}")
    
    def validate_dicom(self, file_path: str) -> bool:
        """
        验证DICOM文件是否有效
        
        Args:
            file_path: DICOM文件路径
            
        Returns:
            是否有效
        """
        try:
            file_path = Path(file_path)
            
            if not file_path.exists() or not file_path.is_file():
                return False
            
            # 尝试读取DICOM文件（包含像素数据以进行完整验证）
            dicom_dataset = pydicom.dcmread(str(file_path), force=True)
            
            # 基本验证（但不强制要求像素数据）
            temp_force_pixel_data = self.force_pixel_data
            self.force_pixel_data = False  # 临时禁用像素数据强制要求
            validation_result = self._validate_dicom_dataset(dicom_dataset, str(file_path))
            self.force_pixel_data = temp_force_pixel_data  # 恢复原设置
            
            return validation_result['is_valid']
            
        except Exception as e:
            self.logger.debug(f"验证DICOM文件失败: {file_path}, 错误: {str(e)}")
            return False
    
    def scan_directory(self, directory_path: str) -> List[str]:
        """
        扫描目录中的DICOM文件
        
        Args:
            directory_path: 目录路径
            
        Returns:
            DICOM文件路径列表
        """
        directory_path = Path(directory_path)
        self.logger.info(f"开始扫描目录: {directory_path}")
        
        with log_manager.create_operation_context("scan_directory", directory_path=str(directory_path)):
            try:
                if not directory_path.exists():
                    raise DICOMLoadError(str(directory_path), "目录不存在")
                
                if not directory_path.is_dir():
                    raise DICOMLoadError(str(directory_path), "路径不是目录")
                
                dicom_files = []
                
                # 递归搜索DICOM文件
                for ext in self.supported_extensions:
                    pattern = f"**/*{ext}"
                    files = list(directory_path.glob(pattern))
                    dicom_files.extend(str(f) for f in files)
                
                # 去重并排序
                dicom_files = sorted(list(set(dicom_files)))
                
                # 验证找到的文件
                validated_files = []
                for file_path in dicom_files:
                    if self.validate_dicom(file_path):
                        validated_files.append(file_path)
                    else:
                        self.logger.warning(f"跳过无效的DICOM文件: {file_path}")
                
                self.logger.info(f"目录扫描完成: 找到 {len(validated_files)} 个有效DICOM文件")
                
                return validated_files
                
            except DICOMLoadError:
                raise
            except Exception as e:
                raise DICOMLoadError(str(directory_path), f"扫描目录失败: {str(e)}")
    
    def load_batch(self, file_paths: List[str]) -> Tuple[List[DICOMImage], List[Exception]]:
        """
        批量加载DICOM文件
        
        Args:
            file_paths: 文件路径列表
            
        Returns:
            (成功加载的DICOMImage列表, 失败的异常列表)
        """
        self.logger.info(f"开始批量加载 {len(file_paths)} 个DICOM文件")
        
        with log_manager.create_operation_context("load_batch", file_count=len(file_paths)):
            loaded_images = []
            errors = []
            
            for i, file_path in enumerate(file_paths):
                try:
                    dicom_image = self.load_dicom_file(file_path)
                    loaded_images.append(dicom_image)
                    
                    # 定期报告进度
                    if (i + 1) % 10 == 0:
                        self.logger.info(f"批量加载进度: {i + 1}/{len(file_paths)}")
                        
                except Exception as e:
                    errors.append(e)
                    self.logger.error(f"加载文件失败: {file_path}, 错误: {str(e)}")
            
            self.logger.info(f"批量加载完成: 成功 {len(loaded_images)}, 失败 {len(errors)}")
            
            return loaded_images, errors
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取加载统计信息"""
        return {
            'files_processed': self.stats['files_processed'],
            'files_loaded': self.stats['files_loaded'],
            'files_failed': self.stats['files_failed'],
            'validation_errors': self.stats['validation_errors'],
            'success_rate': self.stats['files_loaded'] / max(self.stats['files_processed'], 1)
        }
    
    def reset_statistics(self) -> None:
        """重置统计信息"""
        self.stats = {
            'files_processed': 0,
            'files_loaded': 0,
            'files_failed': 0,
            'validation_errors': 0
        }
    
    def _validate_dicom_dataset(self, dataset: FileDataset, file_path: str) -> Dict[str, Any]:
        """
        验证DICOM数据集
        
        Args:
            dataset: DICOM数据集
            file_path: 文件路径
            
        Returns:
            验证结果字典
        """
        errors = []
        warnings = []
        
        try:
            # 检查基本的DICOM标签 (放宽要求)
            # SOPClassUID在某些情况下可能缺失，不强制要求
            essential_tags = ['SOPInstanceUID', 'StudyInstanceUID']
            for tag in essential_tags:
                if not hasattr(dataset, tag):
                    errors.append(f"缺少基本的DICOM标签: {tag}")
            
            # SOPClassUID缺失时给出警告而不是错误
            if not hasattr(dataset, 'SOPClassUID'):
                warnings.append("缺少SOPClassUID标签，但继续处理")
            
            # 检查像素数据
            if self.force_pixel_data:
                if not hasattr(dataset, 'pixel_array'):
                    try:
                        pixel_array = dataset.pixel_array
                        if pixel_array is None or pixel_array.size == 0:
                            errors.append("像素数据为空")
                    except Exception as e:
                        errors.append(f"无法获取像素数据: {str(e)}")
            
            # 检查图像相关标签
            if hasattr(dataset, 'Rows') and hasattr(dataset, 'Columns'):
                if dataset.Rows <= 0 or dataset.Columns <= 0:
                    errors.append(f"无效的图像尺寸: {dataset.Rows}x{dataset.Columns}")
            else:
                warnings.append("缺少图像尺寸信息")
            
            # 检查位深度
            if hasattr(dataset, 'BitsAllocated'):
                if dataset.BitsAllocated not in [8, 16, 32]:
                    warnings.append(f"不常见的位深度: {dataset.BitsAllocated}")
            
            # 检查传输语法
            if hasattr(dataset, 'file_meta') and hasattr(dataset.file_meta, 'TransferSyntaxUID'):
                transfer_syntax = dataset.file_meta.TransferSyntaxUID
                # 这里可以添加对特定传输语法的检查
            else:
                warnings.append("缺少传输语法信息")
            
        except Exception as e:
            errors.append(f"验证过程中发生错误: {str(e)}")
        
        return {
            'is_valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings
        }
    
    def _extract_pixel_data(self, dataset: FileDataset, file_path: str) -> np.ndarray:
        """
        提取像素数据
        
        Args:
            dataset: DICOM数据集
            file_path: 文件路径
            
        Returns:
            像素数据numpy数组
        """
        try:
            pixel_array = dataset.pixel_array
            
            if pixel_array is None:
                raise DICOMLoadError(file_path, "像素数据为None")
            
            if pixel_array.size == 0:
                raise DICOMLoadError(file_path, "像素数据为空")
            
            # 确保数据类型合适
            if pixel_array.dtype == np.bool_:
                pixel_array = pixel_array.astype(np.uint8)
            
            # 处理不同的像素数据形状
            if len(pixel_array.shape) == 2:
                # 灰度图像，转换为 (height, width, 1)
                pixel_array = np.expand_dims(pixel_array, axis=2)
            elif len(pixel_array.shape) == 3:
                # 检查是否需要调整通道顺序
                if pixel_array.shape[0] == 3 or pixel_array.shape[0] == 1:
                    # 从 (channels, height, width) 转换为 (height, width, channels)
                    pixel_array = np.transpose(pixel_array, (1, 2, 0))
            elif len(pixel_array.shape) == 4:
                # 多帧图像，取第一帧
                pixel_array = pixel_array[0]
                if len(pixel_array.shape) == 2:
                    pixel_array = np.expand_dims(pixel_array, axis=2)
            
            # 确保像素值在合理范围内
            if pixel_array.dtype == np.uint16:
                # 16位图像可能需要窗位窗宽调整
                if hasattr(dataset, 'WindowCenter') and hasattr(dataset, 'WindowWidth'):
                    try:
                        window_center = float(dataset.WindowCenter)
                        window_width = float(dataset.WindowWidth)
                        
                        # 应用窗位窗宽
                        pixel_array = self._apply_windowing(pixel_array, window_center, window_width)
                    except (ValueError, TypeError):
                        # 如果窗位窗宽无效，使用简单的归一化
                        pixel_array = self._normalize_uint16(pixel_array)
                else:
                    pixel_array = self._normalize_uint16(pixel_array)
            
            return pixel_array
            
        except Exception as e:
            raise DICOMLoadError(file_path, f"提取像素数据失败: {str(e)}")
    
    def _apply_windowing(self, pixel_array: np.ndarray, center: float, width: float) -> np.ndarray:
        """应用窗位窗宽"""
        min_val = center - width / 2
        max_val = center + width / 2
        
        # 截断并归一化到0-255
        windowed = np.clip(pixel_array, min_val, max_val)
        windowed = ((windowed - min_val) / width * 255).astype(np.uint8)
        
        return windowed
    
    def _normalize_uint16(self, pixel_array: np.ndarray) -> np.ndarray:
        """归一化16位图像到8位"""
        # 使用百分位数来处理异常值
        p1, p99 = np.percentile(pixel_array, [1, 99])
        normalized = np.clip(pixel_array, p1, p99)
        normalized = ((normalized - p1) / (p99 - p1) * 255).astype(np.uint8)
        
        return normalized
    
    def _extract_metadata(self, dataset: FileDataset) -> Dict[str, Any]:
        """
        提取DICOM元数据
        
        Args:
            dataset: DICOM数据集
            
        Returns:
            元数据字典
        """
        metadata = {}
        
        # 基本信息
        basic_tags = {
            'PatientID': 'patient_id',
            'PatientName': 'patient_name',
            'StudyInstanceUID': 'study_uid',
            'SeriesInstanceUID': 'series_uid',
            'SOPInstanceUID': 'instance_uid',
            'Modality': 'modality',
            'StudyDate': 'study_date',
            'SeriesDate': 'series_date',
            'AcquisitionDate': 'acquisition_date'
        }
        
        for dicom_tag, meta_key in basic_tags.items():
            if hasattr(dataset, dicom_tag):
                value = getattr(dataset, dicom_tag)
                metadata[meta_key] = str(value) if value is not None else None
        
        # 图像信息
        image_tags = {
            'Rows': 'height',
            'Columns': 'width',
            'BitsAllocated': 'bits_allocated',
            'BitsStored': 'bits_stored',
            'SamplesPerPixel': 'samples_per_pixel',
            'PhotometricInterpretation': 'photometric_interpretation',
            'PixelSpacing': 'pixel_spacing',
            'SliceThickness': 'slice_thickness'
        }
        
        for dicom_tag, meta_key in image_tags.items():
            if hasattr(dataset, dicom_tag):
                value = getattr(dataset, dicom_tag)
                metadata[meta_key] = value
        
        # 窗位窗宽
        if hasattr(dataset, 'WindowCenter') and hasattr(dataset, 'WindowWidth'):
            metadata['window_center'] = getattr(dataset, 'WindowCenter')
            metadata['window_width'] = getattr(dataset, 'WindowWidth')
        
        # 设备信息
        device_tags = {
            'Manufacturer': 'manufacturer',
            'ManufacturerModelName': 'model_name',
            'SoftwareVersions': 'software_version'
        }
        
        for dicom_tag, meta_key in device_tags.items():
            if hasattr(dataset, dicom_tag):
                value = getattr(dataset, dicom_tag)
                metadata[meta_key] = str(value) if value is not None else None
        
        return metadata


class DICOMLoaderFactory:
    """
    DICOM加载器工厂类 - 遵循开闭原则
    
    允许创建不同配置的DICOM加载器实例。
    """
    
    @staticmethod
    def create_standard_loader() -> DICOMLoader:
        """创建标准配置的加载器"""
        return DICOMLoader(validate_on_load=True, force_pixel_data=True)
    
    @staticmethod
    def create_fast_loader() -> DICOMLoader:
        """创建快速加载器（跳过验证）"""
        return DICOMLoader(validate_on_load=False, force_pixel_data=True)
    
    @staticmethod
    def create_metadata_only_loader() -> DICOMLoader:
        """创建仅元数据加载器"""
        return DICOMLoader(validate_on_load=True, force_pixel_data=False)
    
    @staticmethod
    def create_custom_loader(validate_on_load: bool = True, force_pixel_data: bool = True) -> DICOMLoader:
        """创建自定义配置的加载器"""
        return DICOMLoader(validate_on_load=validate_on_load, force_pixel_data=force_pixel_data)