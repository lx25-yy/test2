# -*- coding: utf-8 -*-
"""
Image preprocessing implementations for DICOM images

Converts DICOM images to ResNet50-compatible format following SOLID principles.
"""

from abc import ABC
from typing import Tuple, Optional, Dict, Any, List
import numpy as np
import torch
from torch import nn
import torchvision.transforms as transforms
from PIL import Image
import cv2

from ..core.interfaces import IImagePreprocessor, DICOMImage
from ..core.exceptions import ImagePreprocessingError
from ..core.logger import log_manager


class BaseImagePreprocessor(IImagePreprocessor):
    """
    Base image preprocessor implementing common functionality
    
    Follows Single Responsibility Principle by focusing on image preprocessing tasks.
    """
    
    def __init__(self, target_size: Tuple[int, int] = (224, 224)):
        """
        Initialize base preprocessor
        
        Args:
            target_size: Target image size for model input
        """
        self.target_size = target_size
        self.logger = log_manager.get_logger(self.__class__.__name__)
        
        # Image statistics for different normalization methods
        self.normalization_stats = {
            'imagenet': {
                'mean': [0.485, 0.456, 0.406],
                'std': [0.229, 0.224, 0.225]
            },
            'custom': {
                'mean': [0.5, 0.5, 0.5],
                'std': [0.5, 0.5, 0.5]
            }
        }
    
    def resize_image(self, image: np.ndarray, target_size: Tuple[int, int]) -> np.ndarray:
        """
        Resize image to target dimensions
        
        Args:
            image: Input image array
            target_size: Target (height, width)
            
        Returns:
            Resized image array
        """
        try:
            if len(image.shape) == 2:
                # Grayscale image
                resized = cv2.resize(image, (target_size[1], target_size[0]), 
                                   interpolation=cv2.INTER_LINEAR)
            elif len(image.shape) == 3:
                # Color image
                resized = cv2.resize(image, (target_size[1], target_size[0]), 
                                   interpolation=cv2.INTER_LINEAR)
            else:
                raise ImagePreprocessingError(
                    f"shape: {image.shape}", 
                    "resize_image", 
                    f"Unsupported image shape: {image.shape}"
                )
            
            return resized
            
        except Exception as e:
            raise ImagePreprocessingError(
                f"shape: {image.shape}, target: {target_size}",
                "resize_image",
                f"Resize failed: {str(e)}"
            )
    
    def normalize_pixels(self, image: np.ndarray) -> np.ndarray:
        """
        Normalize pixel values to [0, 1] range
        
        Args:
            image: Input image array
            
        Returns:
            Normalized image array
        """
        try:
            if image.dtype == np.uint8:
                # Already in [0, 255] range, convert to [0, 1]
                normalized = image.astype(np.float32) / 255.0
            elif image.dtype == np.uint16:
                # 16-bit image, normalize to [0, 1]
                normalized = image.astype(np.float32) / 65535.0
            elif image.dtype in [np.float32, np.float64]:
                # Float image, assume already normalized or apply min-max normalization
                if image.max() <= 1.0 and image.min() >= 0.0:
                    normalized = image.astype(np.float32)
                else:
                    # Apply min-max normalization
                    img_min, img_max = image.min(), image.max()
                    if img_max > img_min:
                        normalized = ((image - img_min) / (img_max - img_min)).astype(np.float32)
                    else:
                        normalized = np.zeros_like(image, dtype=np.float32)
            else:
                raise ImagePreprocessingError(
                    f"dtype: {image.dtype}",
                    "normalize_pixels",
                    f"Unsupported image dtype: {image.dtype}"
                )
            
            return normalized
            
        except Exception as e:
            raise ImagePreprocessingError(
                f"dtype: {image.dtype}, shape: {image.shape}",
                "normalize_pixels",
                f"Normalization failed: {str(e)}"
            )
    
    def convert_to_rgb(self, image: np.ndarray) -> np.ndarray:
        """
        Convert image to RGB format
        
        Args:
            image: Input image array
            
        Returns:
            RGB image array
        """
        try:
            if len(image.shape) == 2:
                # Grayscale to RGB: duplicate channels
                rgb_image = np.stack([image, image, image], axis=2)
            elif len(image.shape) == 3:
                if image.shape[2] == 1:
                    # Single channel to RGB
                    rgb_image = np.repeat(image, 3, axis=2)
                elif image.shape[2] == 3:
                    # Already RGB
                    rgb_image = image
                elif image.shape[2] == 4:
                    # RGBA to RGB: drop alpha channel
                    rgb_image = image[:, :, :3]
                else:
                    raise ImagePreprocessingError(
                        f"channels: {image.shape[2]}",
                        "convert_to_rgb",
                        f"Unsupported number of channels: {image.shape[2]}"
                    )
            else:
                raise ImagePreprocessingError(
                    f"shape: {image.shape}",
                    "convert_to_rgb",
                    f"Unsupported image shape: {image.shape}"
                )
            
            return rgb_image
            
        except Exception as e:
            raise ImagePreprocessingError(
                f"shape: {image.shape}",
                "convert_to_rgb",
                f"RGB conversion failed: {str(e)}"
            )
    
    def preprocess_image(self, dicom_image: DICOMImage) -> torch.Tensor:
        """
        Base preprocessing implementation - to be overridden by subclasses
        
        Args:
            dicom_image: Input DICOM image
            
        Returns:
            Preprocessed torch tensor
        """
        raise NotImplementedError("Subclasses must implement preprocess_image method")


class ResNetPreprocessor(BaseImagePreprocessor):
    """
    ResNet-specific image preprocessor
    
    Implements preprocessing pipeline optimized for ResNet models.
    """
    
    def __init__(self, 
                 target_size: Tuple[int, int] = (224, 224),
                 normalize_method: str = 'imagenet',
                 custom_mean: Optional[Tuple[float, float, float]] = None,
                 custom_std: Optional[Tuple[float, float, float]] = None):
        """
        Initialize ResNet preprocessor
        
        Args:
            target_size: Target image size
            normalize_method: Normalization method ('imagenet', 'custom', 'none')
            custom_mean: Custom normalization mean values
            custom_std: Custom normalization std values
        """
        super().__init__(target_size)
        self.normalize_method = normalize_method
        
        # Set normalization parameters
        if normalize_method == 'custom' and custom_mean and custom_std:
            self.normalization_stats['custom']['mean'] = list(custom_mean)
            self.normalization_stats['custom']['std'] = list(custom_std)
        
        # Create torchvision transforms
        self._build_transforms()
    
    def _build_transforms(self):
        """Build torchvision transforms pipeline"""
        transform_list = []
        
        # Normalization
        if self.normalize_method in self.normalization_stats:
            stats = self.normalization_stats[self.normalize_method]
            transform_list.append(
                transforms.Normalize(mean=stats['mean'], std=stats['std'])
            )
        
        self.transforms = transforms.Compose(transform_list) if transform_list else None
    
    def preprocess_image(self, dicom_image: DICOMImage) -> torch.Tensor:
        """
        Preprocess DICOM image for ResNet model
        
        Args:
            dicom_image: Input DICOM image
            
        Returns:
            Preprocessed torch tensor ready for ResNet
        """
        try:
            with log_manager.create_operation_context("preprocess_image", 
                                                    file_path=dicom_image.file_path):
                
                # Step 1: Get pixel data
                image = dicom_image.pixel_data.copy()
                self.logger.debug(f"Input image shape: {image.shape}, dtype: {image.dtype}")
                
                # Step 2: Resize to target size
                resized_image = self.resize_image(image, self.target_size)
                self.logger.debug(f"Resized image shape: {resized_image.shape}")
                
                # Step 3: Convert to RGB if needed
                rgb_image = self.convert_to_rgb(resized_image)
                self.logger.debug(f"RGB image shape: {rgb_image.shape}")
                
                # Step 4: Normalize pixel values to [0, 1]
                normalized_image = self.normalize_pixels(rgb_image)
                self.logger.debug(f"Normalized range: [{normalized_image.min():.3f}, {normalized_image.max():.3f}]")
                
                # Step 5: Convert to torch tensor (HWC -> CHW)
                tensor = torch.from_numpy(normalized_image)
                if len(tensor.shape) == 3:
                    tensor = tensor.permute(2, 0, 1)  # HWC -> CHW
                
                self.logger.debug(f"Tensor shape: {tensor.shape}")
                
                # Step 6: Apply normalization transforms if specified
                if self.transforms:
                    tensor = self.transforms(tensor)
                    self.logger.debug(f"After transforms - mean: {tensor.mean():.3f}, std: {tensor.std():.3f}")
                
                return tensor
                
        except ImagePreprocessingError:
            raise
        except Exception as e:
            raise ImagePreprocessingError(
                dicom_image.file_path,
                "preprocess_image", 
                f"Preprocessing failed: {str(e)}"
            )


class FlexiblePreprocessor(BaseImagePreprocessor):
    """
    Flexible preprocessor with configurable options
    
    Allows runtime configuration of preprocessing steps.
    """
    
    def __init__(self, config: Dict[str, Any]):
        """
        Initialize flexible preprocessor
        
        Args:
            config: Configuration dictionary with preprocessing parameters
        """
        target_size = config.get('target_size', (224, 224))
        super().__init__(target_size)
        
        self.config = config
        self.validate_config()
    
    def validate_config(self):
        """Validate preprocessor configuration"""
        required_keys = ['target_size', 'normalize_method']
        for key in required_keys:
            if key not in self.config:
                raise ImagePreprocessingError(
                    f"config_key: {key}",
                    "validate_config",
                    f"Missing required config key: {key}"
                )
    
    def preprocess_image(self, dicom_image: DICOMImage) -> torch.Tensor:
        """
        Flexible preprocessing implementation
        
        Args:
            dicom_image: Input DICOM image
            
        Returns:
            Preprocessed torch tensor
        """
        try:
            image = dicom_image.pixel_data.copy()
            
            # Apply configured preprocessing steps
            processing_steps = self.config.get('processing_steps', [
                'resize', 'convert_to_rgb', 'normalize_pixels', 'to_tensor'
            ])
            
            for step in processing_steps:
                if step == 'resize':
                    image = self.resize_image(image, self.target_size)
                elif step == 'convert_to_rgb':
                    image = self.convert_to_rgb(image)
                elif step == 'normalize_pixels':
                    image = self.normalize_pixels(image)
                elif step == 'to_tensor':
                    tensor = torch.from_numpy(image)
                    if len(tensor.shape) == 3:
                        tensor = tensor.permute(2, 0, 1)
                    image = tensor
                else:
                    self.logger.warning(f"Unknown processing step: {step}")
            
            return image if isinstance(image, torch.Tensor) else torch.from_numpy(image)
            
        except Exception as e:
            raise ImagePreprocessingError(
                dicom_image.file_path,
                "preprocess_image",
                f"Flexible preprocessing failed: {str(e)}"
            )


class BatchPreprocessor:
    """
    Batch preprocessor for efficient processing of multiple images
    
    Follows Single Responsibility Principle by focusing on batch operations.
    """
    
    def __init__(self, preprocessor: IImagePreprocessor, batch_size: int = 32):
        """
        Initialize batch preprocessor
        
        Args:
            preprocessor: Single image preprocessor
            batch_size: Batch size for processing
        """
        self.preprocessor = preprocessor
        self.batch_size = batch_size
        self.logger = log_manager.get_logger(self.__class__.__name__)
    
    def preprocess_batch(self, dicom_images: List[DICOMImage]) -> torch.Tensor:
        """
        Preprocess a batch of DICOM images
        
        Args:
            dicom_images: List of DICOM images
            
        Returns:
            Batched tensor of shape (batch_size, channels, height, width)
        """
        try:
            with log_manager.create_operation_context("preprocess_batch", 
                                                    batch_size=len(dicom_images)):
                
                processed_tensors = []
                
                for i, dicom_image in enumerate(dicom_images):
                    try:
                        tensor = self.preprocessor.preprocess_image(dicom_image)
                        processed_tensors.append(tensor)
                        
                        if (i + 1) % 10 == 0:
                            self.logger.debug(f"Processed {i + 1}/{len(dicom_images)} images")
                            
                    except Exception as e:
                        self.logger.error(f"Failed to preprocess {dicom_image.file_path}: {e}")
                        # Continue with other images
                        continue
                
                if not processed_tensors:
                    raise ImagePreprocessingError(
                        f"batch_size: {len(dicom_images)}",
                        "preprocess_batch",
                        "No images were successfully preprocessed"
                    )
                
                # Stack tensors into batch
                batch_tensor = torch.stack(processed_tensors)
                self.logger.info(f"Created batch tensor of shape: {batch_tensor.shape}")
                
                return batch_tensor
                
        except Exception as e:
            raise ImagePreprocessingError(
                f"batch_size: {len(dicom_images)}",
                "preprocess_batch",
                f"Batch preprocessing failed: {str(e)}"
            )
    
    def preprocess_batch_generator(self, dicom_images: List[DICOMImage]):
        """
        Generator for batch preprocessing
        
        Args:
            dicom_images: List of DICOM images
            
        Yields:
            Batched tensors
        """
        for i in range(0, len(dicom_images), self.batch_size):
            batch = dicom_images[i:i + self.batch_size]
            yield self.preprocess_batch(batch)


class PreprocessorFactory:
    """
    Factory for creating different types of preprocessors
    
    Follows Open/Closed Principle - open for extension, closed for modification.
    """
    
    @staticmethod
    def create_resnet_preprocessor(target_size: Tuple[int, int] = (224, 224),
                                 normalize_method: str = 'imagenet') -> ResNetPreprocessor:
        """Create ResNet-optimized preprocessor"""
        return ResNetPreprocessor(target_size=target_size, normalize_method=normalize_method)
    
    @staticmethod
    def create_custom_preprocessor(config: Dict[str, Any]) -> FlexiblePreprocessor:
        """Create custom preprocessor from configuration"""
        return FlexiblePreprocessor(config)
    
    @staticmethod
    def create_batch_preprocessor(preprocessor: IImagePreprocessor, 
                                batch_size: int = 32) -> BatchPreprocessor:
        """Create batch preprocessor"""
        return BatchPreprocessor(preprocessor, batch_size)
    
    @staticmethod
    def create_from_config(config: Dict[str, Any]) -> IImagePreprocessor:
        """
        Create preprocessor from configuration
        
        Args:
            config: Configuration dictionary
            
        Returns:
            Configured preprocessor instance
        """
        preprocessor_type = config.get('type', 'resnet')
        
        if preprocessor_type == 'resnet':
            return PreprocessorFactory.create_resnet_preprocessor(
                target_size=tuple(config.get('target_size', [224, 224])),
                normalize_method=config.get('normalize_method', 'imagenet')
            )
        elif preprocessor_type == 'flexible':
            return PreprocessorFactory.create_custom_preprocessor(config)
        else:
            raise ImagePreprocessingError(
                f"type: {preprocessor_type}",
                "create_from_config",
                f"Unknown preprocessor type: {preprocessor_type}"
            )


class ImageAugmentor:
    """
    Image augmentation utilities for data enhancement
    
    Follows Single Responsibility Principle by focusing on augmentation tasks.
    """
    
    def __init__(self, augmentation_config: Dict[str, Any]):
        """
        Initialize image augmentor
        
        Args:
            augmentation_config: Configuration for augmentations
        """
        self.config = augmentation_config
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self._build_augmentations()
    
    def _build_augmentations(self):
        """Build augmentation pipeline"""
        aug_list = []
        
        if self.config.get('random_rotation', False):
            degrees = self.config.get('rotation_degrees', 10)
            aug_list.append(transforms.RandomRotation(degrees))
        
        if self.config.get('random_flip', False):
            aug_list.append(transforms.RandomHorizontalFlip(p=0.5))
        
        if self.config.get('color_jitter', False):
            brightness = self.config.get('brightness', 0.1)
            contrast = self.config.get('contrast', 0.1)
            aug_list.append(transforms.ColorJitter(brightness=brightness, contrast=contrast))
        
        self.augmentations = transforms.Compose(aug_list) if aug_list else None
    
    def augment_tensor(self, tensor: torch.Tensor) -> torch.Tensor:
        """
        Apply augmentations to tensor
        
        Args:
            tensor: Input tensor
            
        Returns:
            Augmented tensor
        """
        if self.augmentations:
            return self.augmentations(tensor)
        return tensor