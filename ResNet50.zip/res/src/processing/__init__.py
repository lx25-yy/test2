# -*- coding: utf-8 -*-
"""
Processing module

Batch processing management, memory optimization, and performance monitoring.
"""

from .batch_manager import (
    BatchManager, BatchConfig, MemoryMonitor, BatchSizeOptimizer, 
    ProgressTracker, DICOMFeatureExtractionStrategy, MemoryStats, 
    ProcessingProgress, IProcessingStrategy
)
from .batch_factory import (
    BatchProcessingFactory, BatchProcessingUtils, PerformanceBenchmark
)

__all__ = [
    # Core batch management
    'BatchManager',
    'BatchConfig',
    'MemoryMonitor',
    'BatchSizeOptimizer',
    'ProgressTracker',
    
    # Processing strategies
    'DICOMFeatureExtractionStrategy',
    'IProcessingStrategy',
    
    # Data structures
    'MemoryStats',
    'ProcessingProgress',
    
    # Factory and utilities
    'BatchProcessingFactory',
    'BatchProcessingUtils',
    'PerformanceBenchmark'
]