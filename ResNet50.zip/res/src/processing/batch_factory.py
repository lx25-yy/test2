# -*- coding: utf-8 -*-
"""
Batch processing factory and utilities

Factory classes for creating batch processing components and utilities.
"""

from typing import Dict, Any, Optional, Callable
from pathlib import Path

from ..core.interfaces import IDICOMLoader, IImagePreprocessor, IFeatureExtractor, IBatchManager
from ..core.exceptions import BatchProcessingError, ConfigurationError
from ..core.logger import log_manager
from .batch_manager import (
    BatchManager, BatchConfig, DICOMFeatureExtractionStrategy,
    MemoryMonitor, BatchSizeOptimizer, ProgressTracker
)


class BatchProcessingFactory:
    """
    批处理组件工厂
    
    遵循抽象工厂模式，用于创建批处理系统的各种组件。
    """
    
    @staticmethod
    def create_batch_manager(config: Optional[Dict[str, Any]] = None) -> IBatchManager:
        """
        创建批处理管理器
        
        Args:
            config: 批处理配置字典
            
        Returns:
            批处理管理器实例
        """
        logger = log_manager.get_logger("BatchProcessingFactory")
        
        try:
            if config is None:
                config = BatchProcessingFactory.get_default_batch_config()
            
            # 创建批处理配置
            batch_config = BatchConfig(
                initial_batch_size=config.get('initial_batch_size', 8),
                min_batch_size=config.get('min_batch_size', 1),
                max_batch_size=config.get('max_batch_size', 32),
                memory_threshold=config.get('memory_threshold', 0.85),
                auto_optimize=config.get('auto_optimize', True),
                progress_callback=config.get('progress_callback', None)
            )
            
            manager = BatchManager(batch_config)
            logger.info("Batch manager created successfully")
            return manager
            
        except Exception as e:
            raise BatchProcessingError("BatchProcessingFactory", 
                                f"Failed to create batch manager: {str(e)}")
    
    @staticmethod
    def create_dicom_processing_strategy(
        dicom_loader: IDICOMLoader,
        preprocessor: IImagePreprocessor,
        feature_extractor: IFeatureExtractor
    ) -> DICOMFeatureExtractionStrategy:
        """
        创建DICOM处理策略
        
        Args:
            dicom_loader: DICOM加载器
            preprocessor: 图像预处理器
            feature_extractor: 特征提取器
            
        Returns:
            DICOM特征提取策略实例
        """
        logger = log_manager.get_logger("BatchProcessingFactory")
        
        try:
            strategy = DICOMFeatureExtractionStrategy(
                dicom_loader, preprocessor, feature_extractor
            )
            logger.info("DICOM processing strategy created successfully")
            return strategy
            
        except Exception as e:
            raise BatchProcessingError("BatchProcessingFactory", 
                                f"Failed to create processing strategy: {str(e)}")
    
    @staticmethod
    def create_memory_monitor(update_interval: float = 1.0) -> MemoryMonitor:
        """
        创建内存监控器
        
        Args:
            update_interval: 更新间隔（秒）
            
        Returns:
            内存监控器实例
        """
        try:
            monitor = MemoryMonitor(update_interval)
            return monitor
        except Exception as e:
            raise BatchProcessingError("BatchProcessingFactory", 
                                f"Failed to create memory monitor: {str(e)}")
    
    @staticmethod
    def create_batch_optimizer(
        memory_monitor: MemoryMonitor,
        initial_batch_size: int = 8,
        min_batch_size: int = 1,
        max_batch_size: int = 32,
        memory_threshold: float = 0.85
    ) -> BatchSizeOptimizer:
        """
        创建批处理大小优化器
        
        Args:
            memory_monitor: 内存监控器
            initial_batch_size: 初始批处理大小
            min_batch_size: 最小批处理大小
            max_batch_size: 最大批处理大小
            memory_threshold: 内存阈值
            
        Returns:
            批处理大小优化器实例
        """
        try:
            optimizer = BatchSizeOptimizer(
                memory_monitor, initial_batch_size, min_batch_size,
                max_batch_size, memory_threshold
            )
            return optimizer
        except Exception as e:
            raise BatchProcessingError("BatchProcessingFactory", 
                                f"Failed to create batch optimizer: {str(e)}")
    
    @staticmethod
    def create_progress_tracker(total_items: int) -> ProgressTracker:
        """
        创建进度追踪器
        
        Args:
            total_items: 总处理项目数
            
        Returns:
            进度追踪器实例
        """
        try:
            tracker = ProgressTracker(total_items)
            return tracker
        except Exception as e:
            raise BatchProcessingError("BatchProcessingFactory", 
                                f"Failed to create progress tracker: {str(e)}")
    
    @staticmethod
    def create_batch_processing_pipeline(
        dicom_loader: IDICOMLoader,
        preprocessor: IImagePreprocessor,
        feature_extractor: IFeatureExtractor,
        batch_config: Optional[Dict[str, Any]] = None
    ) -> tuple[IBatchManager, DICOMFeatureExtractionStrategy]:
        """
        创建完整的批处理流水线
        
        Args:
            dicom_loader: DICOM加载器
            preprocessor: 图像预处理器
            feature_extractor: 特征提取器
            batch_config: 批处理配置
            
        Returns:
            (批处理管理器, 处理策略)元组
        """
        logger = log_manager.get_logger("BatchProcessingFactory")
        
        try:
            # 创建批处理管理器
            batch_manager = BatchProcessingFactory.create_batch_manager(batch_config)
            
            # 创建处理策略
            processing_strategy = BatchProcessingFactory.create_dicom_processing_strategy(
                dicom_loader, preprocessor, feature_extractor
            )
            
            logger.info("Batch processing pipeline created successfully")
            return batch_manager, processing_strategy
            
        except Exception as e:
            raise BatchProcessingError("BatchProcessingFactory", 
                                f"Failed to create batch processing pipeline: {str(e)}")
    
    @staticmethod
    def get_default_batch_config() -> Dict[str, Any]:
        """
        获取默认批处理配置
        
        Returns:
            默认配置字典
        """
        return {
            'initial_batch_size': 8,
            'min_batch_size': 1,
            'max_batch_size': 32,
            'memory_threshold': 0.85,
            'auto_optimize': True,
            'progress_callback': None
        }
    
    @staticmethod
    def validate_batch_config(config: Dict[str, Any]) -> tuple[bool, list[str]]:
        """
        验证批处理配置
        
        Args:
            config: 配置字典
            
        Returns:
            (是否有效, 错误信息列表)
        """
        errors = []
        
        # 检查必需的配置项
        required_keys = ['initial_batch_size', 'min_batch_size', 'max_batch_size']
        for key in required_keys:
            if key not in config:
                errors.append(f"Missing required config key: {key}")
        
        # 检查批处理大小的逻辑关系
        if 'min_batch_size' in config and 'max_batch_size' in config:
            if config['min_batch_size'] > config['max_batch_size']:
                errors.append("min_batch_size cannot be greater than max_batch_size")
        
        if 'initial_batch_size' in config:
            if config['initial_batch_size'] < config.get('min_batch_size', 1):
                errors.append("initial_batch_size cannot be less than min_batch_size")
            if config['initial_batch_size'] > config.get('max_batch_size', 32):
                errors.append("initial_batch_size cannot be greater than max_batch_size")
        
        # 检查内存阈值
        if 'memory_threshold' in config:
            threshold = config['memory_threshold']
            if not (0.0 < threshold <= 1.0):
                errors.append("memory_threshold must be between 0.0 and 1.0")
        
        # 检查数值类型
        numeric_keys = ['initial_batch_size', 'min_batch_size', 'max_batch_size']
        for key in numeric_keys:
            if key in config and not isinstance(config[key], int):
                errors.append(f"{key} must be an integer")
        
        if 'memory_threshold' in config and not isinstance(config['memory_threshold'], (int, float)):
            errors.append("memory_threshold must be a number")
        
        return len(errors) == 0, errors


class BatchProcessingUtils:
    """
    批处理实用工具类
    
    提供批处理相关的辅助功能。
    """
    
    @staticmethod
    def estimate_optimal_batch_size(
        available_memory_mb: float,
        single_item_memory_mb: float,
        safety_factor: float = 0.8
    ) -> int:
        """
        估算最优批处理大小
        
        Args:
            available_memory_mb: 可用内存（MB）
            single_item_memory_mb: 单个项目内存占用（MB）
            safety_factor: 安全系数（0-1）
            
        Returns:
            推荐的批处理大小
        """
        if single_item_memory_mb <= 0:
            return 1
        
        safe_memory = available_memory_mb * safety_factor
        optimal_batch_size = int(safe_memory / single_item_memory_mb)
        
        return max(1, optimal_batch_size)
    
    @staticmethod
    def calculate_processing_efficiency(
        total_items: int,
        processing_time: float,
        memory_usage_mb: float
    ) -> Dict[str, float]:
        """
        计算处理效率指标
        
        Args:
            total_items: 总处理项目数
            processing_time: 总处理时间（秒）
            memory_usage_mb: 内存使用量（MB）
            
        Returns:
            效率指标字典
        """
        if processing_time <= 0:
            return {
                'items_per_second': 0.0,
                'seconds_per_item': 0.0,
                'memory_per_item_mb': memory_usage_mb / total_items if total_items > 0 else 0.0,
                'efficiency_score': 0.0
            }
        
        items_per_second = total_items / processing_time
        seconds_per_item = processing_time / total_items
        memory_per_item = memory_usage_mb / total_items if total_items > 0 else 0.0
        
        # 效率评分：基于处理速度和内存效率
        # 假设理想速度为10 items/sec，理想内存为10MB/item
        speed_score = min(items_per_second / 10.0, 1.0)
        memory_score = min(10.0 / max(memory_per_item, 1.0), 1.0)
        efficiency_score = (speed_score + memory_score) / 2.0
        
        return {
            'items_per_second': items_per_second,
            'seconds_per_item': seconds_per_item,
            'memory_per_item_mb': memory_per_item,
            'efficiency_score': efficiency_score
        }
    
    @staticmethod
    def create_progress_callback(
        print_interval: int = 10,
        detailed_stats: bool = True
    ) -> Callable:
        """
        创建进度回调函数
        
        Args:
            print_interval: 打印间隔（每处理多少项打印一次）
            detailed_stats: 是否显示详细统计
            
        Returns:
            进度回调函数
        """
        last_print_count = [0]  # 使用列表避免闭包问题
        
        def progress_callback(progress_info):
            from .batch_manager import ProcessingProgress
            
            if isinstance(progress_info, ProcessingProgress):
                # 检查是否到了打印间隔
                if progress_info.processed_items - last_print_count[0] >= print_interval:
                    last_print_count[0] = progress_info.processed_items
                    
                    completion_percent = (progress_info.processed_items / progress_info.total_items) * 100
                    
                    print(f"\n[Processing Progress] {completion_percent:.1f}% Complete")
                    print(f"Processed: {progress_info.processed_items}/{progress_info.total_items}")
                    print(f"Failed: {progress_info.failed_items}")
                    print(f"Rate: {progress_info.processing_rate:.2f} items/sec")
                    print(f"ETA: {progress_info.estimated_time_remaining:.1f}s")
                    
                    if detailed_stats:
                        print(f"Batch size: {progress_info.current_batch_size}")
                        print(f"Memory: CPU {progress_info.memory_stats.cpu_memory_percent:.1f}%, GPU {progress_info.memory_stats.gpu_memory_percent:.1f}%")
                    
                    print("=" * 50)
        
        return progress_callback
    
    @staticmethod
    def save_processing_report(
        processing_stats: Dict[str, Any],
        output_path: str
    ) -> str:
        """
        保存处理报告
        
        Args:
            processing_stats: 处理统计信息
            output_path: 输出路径
            
        Returns:
            报告文件路径
        """
        import json
        from datetime import datetime
        
        report_path = Path(output_path) / f"processing_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        # 添加时间戳
        processing_stats['report_timestamp'] = datetime.now().isoformat()
        
        try:
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(processing_stats, f, indent=2, ensure_ascii=False)
            
            return str(report_path)
            
        except Exception as e:
            raise BatchProcessingError("BatchProcessingUtils", 
                                f"Failed to save processing report: {str(e)}")
    
    @staticmethod
    def load_processing_config(config_path: str) -> Dict[str, Any]:
        """
        加载处理配置文件
        
        Args:
            config_path: 配置文件路径
            
        Returns:
            配置字典
        """
        import json
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # 验证配置
            is_valid, errors = BatchProcessingFactory.validate_batch_config(config)
            if not is_valid:
                raise ConfigurationError(f"Invalid batch configuration: {', '.join(errors)}")
            
            return config
            
        except FileNotFoundError:
            raise BatchProcessingError("BatchProcessingUtils", 
                                f"Configuration file not found: {config_path}")
        except json.JSONDecodeError as e:
            raise BatchProcessingError("BatchProcessingUtils", 
                                f"Invalid JSON configuration: {str(e)}")
        except Exception as e:
            raise BatchProcessingError("BatchProcessingUtils", 
                                f"Failed to load configuration: {str(e)}")


class PerformanceBenchmark:
    """
    性能基准测试工具
    
    用于评估不同批处理配置的性能。
    """
    
    def __init__(self):
        """初始化性能基准测试"""
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.benchmark_results = []
    
    def run_batch_size_benchmark(
        self,
        batch_manager: IBatchManager,
        processing_strategy,
        test_data: list,
        batch_sizes: list[int] = None
    ) -> Dict[str, Any]:
        """
        运行批处理大小基准测试
        
        Args:
            batch_manager: 批处理管理器
            processing_strategy: 处理策略
            test_data: 测试数据
            batch_sizes: 要测试的批处理大小列表
            
        Returns:
            基准测试结果
        """
        if batch_sizes is None:
            batch_sizes = [1, 2, 4, 8, 16, 32]
        
        results = {
            'batch_size_results': [],
            'optimal_batch_size': None,
            'best_performance_score': 0.0
        }
        
        # 限制测试数据大小
        test_data_sample = test_data[:min(len(test_data), 20)]
        
        for batch_size in batch_sizes:
            try:
                self.logger.info(f"Testing batch size: {batch_size}")
                
                # 配置批处理大小
                batch_manager.batch_optimizer.current_batch_size = batch_size
                
                # 开始测试
                batch_manager.start_processing_session(len(test_data_sample))
                
                start_time = time.time()
                memory_before = batch_manager.memory_monitor.get_current_stats()
                
                # 处理测试数据
                results_data = batch_manager.process_batch(test_data_sample, processing_strategy)
                
                end_time = time.time()
                memory_after = batch_manager.memory_monitor.get_current_stats()
                
                batch_manager.end_processing_session()
                
                # 计算性能指标
                processing_time = end_time - start_time
                throughput = len(test_data_sample) / processing_time
                memory_usage = max(memory_before.gpu_memory_used_mb, memory_after.gpu_memory_used_mb)
                
                # 性能评分（综合吞吐量和内存效率）
                performance_score = throughput / (memory_usage / 100.0 + 1.0)
                
                batch_result = {
                    'batch_size': batch_size,
                    'processing_time': processing_time,
                    'throughput_items_per_sec': throughput,
                    'memory_usage_mb': memory_usage,
                    'performance_score': performance_score,
                    'success_rate': len(results_data) / len(test_data_sample)
                }
                
                results['batch_size_results'].append(batch_result)
                
                # 更新最优配置
                if performance_score > results['best_performance_score']:
                    results['best_performance_score'] = performance_score
                    results['optimal_batch_size'] = batch_size
                
                self.logger.info(f"Batch size {batch_size}: {throughput:.2f} items/sec, {memory_usage:.1f} MB")
                
            except Exception as e:
                self.logger.error(f"Benchmark failed for batch size {batch_size}: {e}")
                continue
        
        return results
    
    def generate_benchmark_report(self, results: Dict[str, Any]) -> str:
        """
        生成基准测试报告
        
        Args:
            results: 基准测试结果
            
        Returns:
            报告字符串
        """
        report = ["=== Batch Processing Performance Benchmark ===\n"]
        
        if results['optimal_batch_size']:
            report.append(f"Optimal batch size: {results['optimal_batch_size']}")
            report.append(f"Best performance score: {results['best_performance_score']:.2f}\n")
        
        report.append("Detailed Results:")
        report.append("Batch Size | Throughput (items/sec) | Memory (MB) | Performance Score")
        report.append("-" * 70)
        
        for result in results['batch_size_results']:
            report.append(
                f"{result['batch_size']:10d} | "
                f"{result['throughput_items_per_sec']:18.2f} | "
                f"{result['memory_usage_mb']:11.1f} | "
                f"{result['performance_score']:16.2f}"
            )
        
        return "\n".join(report)