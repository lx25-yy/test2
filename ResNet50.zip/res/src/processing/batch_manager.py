# -*- coding: utf-8 -*-
"""
Batch processing management with memory optimization

Implements intelligent batch processing, memory monitoring, and dynamic optimization.
"""

import time
import gc
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional, Callable, Iterator, Tuple
from dataclasses import dataclass
from pathlib import Path
import torch
import psutil
import threading
import queue

from ..core.interfaces import IDICOMLoader, IImagePreprocessor, IFeatureExtractor, IBatchManager
from ..core.exceptions import ResourceError, BatchProcessingError, MemoryError
from ..core.logger import log_manager


@dataclass
class BatchConfig:
    """批处理配置"""
    initial_batch_size: int = 8
    min_batch_size: int = 1
    max_batch_size: int = 32
    memory_threshold: float = 0.85  # 85% memory usage threshold
    auto_optimize: bool = True
    progress_callback: Optional[Callable] = None


@dataclass
class MemoryStats:
    """内存使用统计"""
    cpu_memory_used_mb: float
    cpu_memory_total_mb: float
    cpu_memory_percent: float
    gpu_memory_used_mb: float = 0.0
    gpu_memory_total_mb: float = 0.0
    gpu_memory_percent: float = 0.0
    timestamp: float = 0.0


@dataclass
class ProcessingProgress:
    """处理进度信息"""
    total_items: int
    processed_items: int
    failed_items: int
    current_batch_size: int
    processing_rate: float  # items per second
    estimated_time_remaining: float  # seconds
    memory_stats: MemoryStats


class IProcessingStrategy(ABC):
    """处理策略接口"""
    
    @abstractmethod
    def process_batch(self, batch_data: List[Any], **kwargs) -> List[Any]:
        """处理批次数据"""
        pass
    
    @abstractmethod
    def estimate_memory_usage(self, batch_size: int) -> float:
        """估算内存使用量（MB）"""
        pass


class MemoryMonitor:
    """内存监控器"""
    
    def __init__(self, update_interval: float = 1.0):
        """
        初始化内存监控器
        
        Args:
            update_interval: 更新间隔（秒）
        """
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.update_interval = update_interval
        self._monitoring = False
        self._monitor_thread = None
        self._stats_queue = queue.Queue(maxsize=100)
        self._current_stats = None
    
    def start_monitoring(self):
        """开始监控"""
        if self._monitoring:
            return
        
        self._monitoring = True
        self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._monitor_thread.start()
        self.logger.info("Memory monitoring started")
    
    def stop_monitoring(self):
        """停止监控"""
        self._monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=2.0)
        self.logger.info("Memory monitoring stopped")
    
    def get_current_stats(self) -> MemoryStats:
        """获取当前内存统计"""
        if self._current_stats is None:
            self._current_stats = self._collect_memory_stats()
        return self._current_stats
    
    def get_stats_history(self) -> List[MemoryStats]:
        """获取内存统计历史"""
        history = []
        while not self._stats_queue.empty():
            try:
                history.append(self._stats_queue.get_nowait())
            except queue.Empty:
                break
        return history
    
    def _monitor_loop(self):
        """监控循环"""
        while self._monitoring:
            try:
                stats = self._collect_memory_stats()
                self._current_stats = stats
                
                # 保存到历史记录
                try:
                    self._stats_queue.put_nowait(stats)
                except queue.Full:
                    # 队列满了，移除最旧的记录
                    try:
                        self._stats_queue.get_nowait()
                        self._stats_queue.put_nowait(stats)
                    except queue.Empty:
                        pass
                
                time.sleep(self.update_interval)
                
            except Exception as e:
                self.logger.error(f"Memory monitoring error: {e}")
                time.sleep(self.update_interval)
    
    def _collect_memory_stats(self) -> MemoryStats:
        """收集内存统计信息"""
        # CPU内存
        cpu_memory = psutil.virtual_memory()
        cpu_used_mb = (cpu_memory.total - cpu_memory.available) / 1024 / 1024
        cpu_total_mb = cpu_memory.total / 1024 / 1024
        cpu_percent = cpu_memory.percent
        
        # GPU内存
        gpu_used_mb = 0.0
        gpu_total_mb = 0.0
        gpu_percent = 0.0
        
        if torch.cuda.is_available():
            try:
                gpu_used_mb = torch.cuda.memory_allocated() / 1024 / 1024
                gpu_total_mb = torch.cuda.get_device_properties(0).total_memory / 1024 / 1024
                gpu_percent = (gpu_used_mb / gpu_total_mb) * 100 if gpu_total_mb > 0 else 0
            except Exception as e:
                self.logger.warning(f"Failed to get GPU memory stats: {e}")
        
        return MemoryStats(
            cpu_memory_used_mb=cpu_used_mb,
            cpu_memory_total_mb=cpu_total_mb,
            cpu_memory_percent=cpu_percent,
            gpu_memory_used_mb=gpu_used_mb,
            gpu_memory_total_mb=gpu_total_mb,
            gpu_memory_percent=gpu_percent,
            timestamp=time.time()
        )


class BatchSizeOptimizer:
    """批处理大小优化器"""
    
    def __init__(self, 
                 memory_monitor: MemoryMonitor,
                 initial_batch_size: int = 8,
                 min_batch_size: int = 1,
                 max_batch_size: int = 32,
                 memory_threshold: float = 0.85):
        """
        初始化批处理大小优化器
        
        Args:
            memory_monitor: 内存监控器
            initial_batch_size: 初始批处理大小
            min_batch_size: 最小批处理大小
            max_batch_size: 最大批处理大小
            memory_threshold: 内存阈值（0-1）
        """
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.memory_monitor = memory_monitor
        self.current_batch_size = initial_batch_size
        self.min_batch_size = min_batch_size
        self.max_batch_size = max_batch_size
        self.memory_threshold = memory_threshold
        
        # 性能追踪
        self.batch_performance = []  # (batch_size, processing_time, memory_peak)
    
    def get_optimal_batch_size(self, processing_strategy: Optional[IProcessingStrategy] = None) -> int:
        """获取最优批处理大小"""
        memory_stats = self.memory_monitor.get_current_stats()
        
        # 检查GPU内存（优先）
        if torch.cuda.is_available() and memory_stats.gpu_memory_total_mb > 0:
            memory_percent = memory_stats.gpu_memory_percent / 100
        else:
            memory_percent = memory_stats.cpu_memory_percent / 100
        
        # 内存压力过高，减小批处理大小
        if memory_percent > self.memory_threshold:
            new_batch_size = max(self.min_batch_size, self.current_batch_size // 2)
            if new_batch_size != self.current_batch_size:
                self.logger.warning(f"High memory usage ({memory_percent:.1%}), reducing batch size: {self.current_batch_size} -> {new_batch_size}")
                self.current_batch_size = new_batch_size
        
        # 内存充足且性能良好，尝试增加批处理大小
        elif memory_percent < self.memory_threshold * 0.7 and self.current_batch_size < self.max_batch_size:
            # 基于历史性能数据决定是否增加
            if self._should_increase_batch_size():
                new_batch_size = min(self.max_batch_size, self.current_batch_size * 2)
                self.logger.info(f"Low memory usage ({memory_percent:.1%}), increasing batch size: {self.current_batch_size} -> {new_batch_size}")
                self.current_batch_size = new_batch_size
        
        # 如果有处理策略，考虑其内存估算
        if processing_strategy:
            estimated_memory = processing_strategy.estimate_memory_usage(self.current_batch_size)
            if estimated_memory > memory_stats.gpu_memory_total_mb * self.memory_threshold:
                # 根据内存估算调整批处理大小
                safe_batch_size = int(self.current_batch_size * self.memory_threshold * memory_stats.gpu_memory_total_mb / estimated_memory)
                self.current_batch_size = max(self.min_batch_size, safe_batch_size)
        
        return self.current_batch_size
    
    def record_batch_performance(self, batch_size: int, processing_time: float, peak_memory_mb: float):
        """记录批处理性能"""
        self.batch_performance.append((batch_size, processing_time, peak_memory_mb))
        
        # 只保留最近的性能记录
        if len(self.batch_performance) > 20:
            self.batch_performance = self.batch_performance[-20:]
    
    def _should_increase_batch_size(self) -> bool:
        """基于历史性能判断是否应该增加批处理大小"""
        if len(self.batch_performance) < 3:
            return True  # 数据不足，尝试增加
        
        recent_performance = self.batch_performance[-3:]
        
        # 检查最近的性能趋势
        for batch_size, processing_time, memory_peak in recent_performance:
            items_per_second = batch_size / processing_time
            # 如果处理速度下降或内存使用过高，不增加批处理大小
            if items_per_second < 1.0 or memory_peak > self.memory_threshold * 1000:  # 假设1GB阈值
                return False
        
        return True


class ProgressTracker:
    """进度追踪器"""
    
    def __init__(self, total_items: int):
        """
        初始化进度追踪器
        
        Args:
            total_items: 总处理项目数
        """
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.total_items = total_items
        self.processed_items = 0
        self.failed_items = 0
        self.start_time = time.time()
        self.last_update_time = self.start_time
        self.processing_times = []  # 记录最近的处理时间
    
    def update_progress(self, processed_count: int, failed_count: int = 0, current_batch_size: int = 1):
        """更新进度"""
        self.processed_items += processed_count
        self.failed_items += failed_count
        
        current_time = time.time()
        batch_time = current_time - self.last_update_time
        self.processing_times.append(batch_time)
        
        # 只保留最近的时间记录
        if len(self.processing_times) > 10:
            self.processing_times = self.processing_times[-10:]
        
        self.last_update_time = current_time
    
    def get_progress_info(self, memory_stats: MemoryStats, current_batch_size: int) -> ProcessingProgress:
        """获取进度信息"""
        current_time = time.time()
        elapsed_time = current_time - self.start_time
        
        # 计算处理速度
        if elapsed_time > 0:
            processing_rate = self.processed_items / elapsed_time
        else:
            processing_rate = 0.0
        
        # 估算剩余时间
        remaining_items = self.total_items - self.processed_items - self.failed_items
        if processing_rate > 0:
            estimated_time_remaining = remaining_items / processing_rate
        else:
            estimated_time_remaining = 0.0
        
        return ProcessingProgress(
            total_items=self.total_items,
            processed_items=self.processed_items,
            failed_items=self.failed_items,
            current_batch_size=current_batch_size,
            processing_rate=processing_rate,
            estimated_time_remaining=estimated_time_remaining,
            memory_stats=memory_stats
        )
    
    def print_progress(self, progress_info: ProcessingProgress):
        """打印进度信息"""
        completion_percent = (progress_info.processed_items / progress_info.total_items) * 100
        
        print(f"\n=== Processing Progress ===")
        print(f"Completed: {progress_info.processed_items}/{progress_info.total_items} ({completion_percent:.1f}%)")
        print(f"Failed: {progress_info.failed_items}")
        print(f"Current batch size: {progress_info.current_batch_size}")
        print(f"Processing rate: {progress_info.processing_rate:.2f} items/sec")
        print(f"ETA: {progress_info.estimated_time_remaining:.1f} seconds")
        print(f"Memory: CPU {progress_info.memory_stats.cpu_memory_percent:.1f}%, GPU {progress_info.memory_stats.gpu_memory_percent:.1f}%")


class BatchManager(IBatchManager):
    """
    智能批处理管理器
    
    实现动态批处理大小调整、内存监控和进度追踪。
    """
    
    def __init__(self, config: BatchConfig):
        """
        初始化批处理管理器
        
        Args:
            config: 批处理配置
        """
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.config = config
        
        # 组件初始化
        self.memory_monitor = MemoryMonitor()
        self.batch_optimizer = BatchSizeOptimizer(
            self.memory_monitor,
            config.initial_batch_size,
            config.min_batch_size,
            config.max_batch_size,
            config.memory_threshold
        )
        self.progress_tracker = None
        
        # 状态
        self.is_processing = False
        self.processing_strategy = None
        
        self.logger.info("Batch manager initialized")
    
    def start_processing_session(self, total_items: int):
        """开始处理会话"""
        if self.is_processing:
            raise BatchProcessingError("BatchManager", "Processing session already active")
        
        self.is_processing = True
        self.progress_tracker = ProgressTracker(total_items)
        self.memory_monitor.start_monitoring()
        
        self.logger.info(f"Processing session started for {total_items} items")
    
    def end_processing_session(self):
        """结束处理会话"""
        if not self.is_processing:
            return
        
        self.is_processing = False
        self.memory_monitor.stop_monitoring()
        
        if self.progress_tracker:
            final_progress = self.progress_tracker.get_progress_info(
                self.memory_monitor.get_current_stats(),
                self.batch_optimizer.current_batch_size
            )
            self.logger.info(f"Processing session completed: {final_progress.processed_items}/{final_progress.total_items} processed, {final_progress.failed_items} failed")
        
        # 清理GPU内存
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()
    
    def process_batch(self, items: List[Any], processing_strategy: IProcessingStrategy) -> List[Any]:
        """
        处理批次数据
        
        Args:
            items: 要处理的项目列表
            processing_strategy: 处理策略
            
        Returns:
            处理结果列表
        """
        if not self.is_processing:
            raise BatchProcessingError("BatchManager", "No active processing session")
        
        batch_start_time = time.time()
        
        try:
            # 获取最优批处理大小
            if self.config.auto_optimize:
                optimal_batch_size = self.batch_optimizer.get_optimal_batch_size(processing_strategy)
            else:
                optimal_batch_size = self.config.initial_batch_size
            
            # 如果当前批次大于最优大小，分割处理
            if len(items) > optimal_batch_size:
                return self._process_large_batch(items, processing_strategy, optimal_batch_size)
            
            # 处理当前批次
            memory_before = self.memory_monitor.get_current_stats()
            
            results = processing_strategy.process_batch(items)
            
            memory_after = self.memory_monitor.get_current_stats()
            batch_time = time.time() - batch_start_time
            
            # 记录性能
            peak_memory = max(memory_before.gpu_memory_used_mb, memory_after.gpu_memory_used_mb)
            self.batch_optimizer.record_batch_performance(len(items), batch_time, peak_memory)
            
            # 更新进度
            self.progress_tracker.update_progress(len(results), 0, len(items))
            
            # 显示进度（如果有回调）
            if self.config.progress_callback:
                progress_info = self.progress_tracker.get_progress_info(memory_after, len(items))
                self.config.progress_callback(progress_info)
            
            return results
            
        except Exception as e:
            # 更新失败计数
            self.progress_tracker.update_progress(0, len(items), len(items))
            raise BatchProcessingError("BatchManager", f"Batch processing failed: {str(e)}")
    
    def _process_large_batch(self, items: List[Any], processing_strategy: IProcessingStrategy, optimal_batch_size: int) -> List[Any]:
        """处理大批次数据（分割成小批次）"""
        all_results = []
        processed_items = set()  # 追踪已处理的项目，避免重复
        i = 0
        
        while i < len(items):
            # 确定当前批次的结束位置
            batch_end = min(i + optimal_batch_size, len(items))
            batch_items = items[i:batch_end]
            
            # 过滤掉已经处理过的项目
            unique_batch_items = [item for item in batch_items if item not in processed_items]
            
            if not unique_batch_items:
                i = batch_end
                continue
                
            try:
                batch_results = processing_strategy.process_batch(unique_batch_items)
                all_results.extend(batch_results)
                
                # 记录已处理的项目
                for item in unique_batch_items:
                    processed_items.add(item)
                
                # 更新进度
                self.progress_tracker.update_progress(len(batch_results), 0, len(unique_batch_items))
                
            except Exception as e:
                self.logger.error(f"Sub-batch processing failed: {e}")
                self.progress_tracker.update_progress(0, len(unique_batch_items), len(unique_batch_items))
                # 继续处理其他批次
                pass
            
            # 移动到下一个批次
            i = batch_end
            
            # 重新检查内存状况并调整批次大小（仅对后续批次有效）
            if self.config.auto_optimize and i < len(items):
                optimal_batch_size = self.batch_optimizer.get_optimal_batch_size(processing_strategy)
        
        return all_results
    
    def get_current_stats(self) -> Dict[str, Any]:
        """获取当前统计信息"""
        if not self.is_processing or not self.progress_tracker:
            return {}
        
        memory_stats = self.memory_monitor.get_current_stats()
        progress_info = self.progress_tracker.get_progress_info(memory_stats, self.batch_optimizer.current_batch_size)
        
        return {
            'progress': {
                'total_items': progress_info.total_items,
                'processed_items': progress_info.processed_items,
                'failed_items': progress_info.failed_items,
                'completion_percent': (progress_info.processed_items / progress_info.total_items) * 100,
                'processing_rate': progress_info.processing_rate,
                'estimated_time_remaining': progress_info.estimated_time_remaining
            },
            'batch_optimization': {
                'current_batch_size': self.batch_optimizer.current_batch_size,
                'min_batch_size': self.batch_optimizer.min_batch_size,
                'max_batch_size': self.batch_optimizer.max_batch_size,
                'auto_optimize_enabled': self.config.auto_optimize
            },
            'memory': {
                'cpu_memory_percent': memory_stats.cpu_memory_percent,
                'cpu_memory_used_mb': memory_stats.cpu_memory_used_mb,
                'cpu_memory_total_mb': memory_stats.cpu_memory_total_mb,
                'gpu_memory_percent': memory_stats.gpu_memory_percent,
                'gpu_memory_used_mb': memory_stats.gpu_memory_used_mb,
                'gpu_memory_total_mb': memory_stats.gpu_memory_total_mb
            }
        }


class DICOMFeatureExtractionStrategy(IProcessingStrategy):
    """
    DICOM特征提取处理策略
    
    集成DICOM加载、预处理和特征提取的完整流程。
    """
    
    def __init__(self,
                 dicom_loader: IDICOMLoader,
                 preprocessor: IImagePreprocessor,
                 feature_extractor: IFeatureExtractor):
        """
        初始化DICOM特征提取策略
        
        Args:
            dicom_loader: DICOM加载器
            preprocessor: 图像预处理器
            feature_extractor: 特征提取器
        """
        self.logger = log_manager.get_logger(self.__class__.__name__)
        self.dicom_loader = dicom_loader
        self.preprocessor = preprocessor
        self.feature_extractor = feature_extractor
    
    def process_batch(self, batch_data: List[str], **kwargs) -> List[Dict[str, Any]]:
        """
        处理DICOM文件批次
        
        Args:
            batch_data: DICOM文件路径列表
            
        Returns:
            包含特征和元数据的结果列表
        """
        try:
            # Step 1: 加载DICOM文件
            dicom_images = []
            for file_path in batch_data:
                try:
                    dicom_image = self.dicom_loader.load_dicom_file(file_path)
                    dicom_images.append(dicom_image)
                except Exception as e:
                    self.logger.error(f"Failed to load DICOM file {file_path}: {e}")
                    continue
            
            if not dicom_images:
                return []
            
            # Step 2: 预处理图像
            preprocessed_tensors = []
            for dicom_image in dicom_images:
                try:
                    tensor = self.preprocessor.preprocess_image(dicom_image)
                    preprocessed_tensors.append(tensor)
                except Exception as e:
                    self.logger.error(f"Failed to preprocess image {dicom_image.file_path}: {e}")
                    continue
            
            if not preprocessed_tensors:
                return []
            
            # Step 3: 批量特征提取
            batch_tensor = torch.stack(preprocessed_tensors)
            features = self.feature_extractor.extract_features(batch_tensor)
            
            # Step 4: 构建结果
            results = []
            for i, (dicom_image, feature_vector) in enumerate(zip(dicom_images, features)):
                result = {
                    'file_path': dicom_image.file_path,
                    'features': feature_vector.numpy(),
                    'feature_shape': feature_vector.shape,
                    'metadata': {
                        'patient_id': getattr(dicom_image, 'patient_id', 'unknown'),
                        'study_date': getattr(dicom_image, 'study_date', 'unknown'),
                        'modality': getattr(dicom_image, 'modality', 'unknown'),
                        'original_shape': dicom_image.original_shape,
                        'pixel_spacing': getattr(dicom_image, 'pixel_spacing', None)
                    }
                }
                results.append(result)
            
            return results
            
        except Exception as e:
            raise BatchProcessingError("DICOMFeatureExtractionStrategy", 
                                f"Batch processing failed: {str(e)}")
    
    def estimate_memory_usage(self, batch_size: int) -> float:
        """
        估算内存使用量
        
        Args:
            batch_size: 批处理大小
            
        Returns:
            估算的内存使用量（MB）
        """
        # 粗略估算：
        # - DICOM图像加载: ~10MB per image
        # - 预处理tensor: ~3MB per image (3x224x224x4 bytes)
        # - 特征向量: ~8KB per image (2048x4 bytes)
        # - 模型参数: ~100MB (固定开销)
        
        dicom_memory = batch_size * 10  # MB
        tensor_memory = batch_size * 3  # MB
        feature_memory = batch_size * 0.008  # MB
        model_memory = 100  # MB
        
        total_memory = dicom_memory + tensor_memory + feature_memory + model_memory
        
        # 添加20%的安全边际
        return total_memory * 1.2