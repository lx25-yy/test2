#!/usr/bin/env python3
"""
DICOM Training Pipeline
完整的DICOM医学影像深度学习训练管道
"""

import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
import pydicom
import cv2
from PIL import Image
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm import tqdm
import json
from datetime import datetime

class DICOMDataset(Dataset):
    """
    DICOM数据集类
    """
    def __init__(self, dicom_files, labels=None, transform=None, target_size=(224, 224)):
        self.dicom_files = dicom_files
        self.labels = labels
        self.transform = transform
        self.target_size = target_size
        
        # 如果没有提供标签，创建虚拟标签（用于推理）
        if labels is None:
            self.labels = [0] * len(dicom_files)
    
    def __len__(self):
        return len(self.dicom_files)
    
    def __getitem__(self, idx):
        try:
            # 读取DICOM文件
            ds = pydicom.dcmread(self.dicom_files[idx])
            pixel_array = ds.pixel_array
            
            # 处理图像
            if len(pixel_array.shape) == 3 and pixel_array.shape[2] == 3:
                # RGB图像
                image = pixel_array
            elif len(pixel_array.shape) == 2:
                # 灰度图像转RGB
                image = cv2.cvtColor(pixel_array, cv2.COLOR_GRAY2RGB)
            else:
                raise ValueError(f"Unsupported image shape: {pixel_array.shape}")
            
            # 转换为PIL图像
            image = Image.fromarray(image.astype(np.uint8))
            
            # 应用变换
            if self.transform:
                image = self.transform(image)
            
            label = self.labels[idx]
            
            return image, label, self.dicom_files[idx]
            
        except Exception as e:
            print(f"Error loading {self.dicom_files[idx]}: {e}")
            # 返回零张量作为备选
            if self.transform:
                dummy_image = torch.zeros(3, self.target_size[0], self.target_size[1])
            else:
                dummy_image = np.zeros((self.target_size[0], self.target_size[1], 3))
            return dummy_image, self.labels[idx], self.dicom_files[idx]

class DICOMTrainer:
    """
    DICOM训练器
    """
    def __init__(self, model, device='cuda', save_dir='./checkpoints'):
        self.model = model
        self.device = device
        self.save_dir = save_dir
        self.best_accuracy = 0.0
        self.training_history = {'train_loss': [], 'val_loss': [], 'val_accuracy': []}
        
        os.makedirs(save_dir, exist_ok=True)
        
        # 将模型移动到设备
        self.model.to(device)
    
    def train_epoch(self, train_loader, criterion, optimizer):
        """训练一个epoch"""
        self.model.train()
        running_loss = 0.0
        correct = 0
        total = 0
        
        progress_bar = tqdm(train_loader, desc="Training", leave=False)
        
        for batch_idx, (images, labels, _) in enumerate(progress_bar):
            images, labels = images.to(self.device), labels.to(self.device)
            
            optimizer.zero_grad()
            
            outputs = self.model(images)
            loss = criterion(outputs, labels)
            
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item()
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            # 更新进度条
            progress_bar.set_postfix({
                'Loss': f'{loss.item():.4f}',
                'Acc': f'{100.*correct/total:.2f}%'
            })
        
        epoch_loss = running_loss / len(train_loader)
        epoch_acc = 100. * correct / total
        
        return epoch_loss, epoch_acc
    
    def validate_epoch(self, val_loader, criterion):
        """验证一个epoch"""
        self.model.eval()
        running_loss = 0.0
        correct = 0
        total = 0
        all_predictions = []
        all_labels = []
        
        with torch.no_grad():
            progress_bar = tqdm(val_loader, desc="Validation", leave=False)
            
            for images, labels, _ in progress_bar:
                images, labels = images.to(self.device), labels.to(self.device)
                
                outputs = self.model(images)
                loss = criterion(outputs, labels)
                
                running_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
                
                all_predictions.extend(predicted.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())
                
                progress_bar.set_postfix({
                    'Loss': f'{loss.item():.4f}',
                    'Acc': f'{100.*correct/total:.2f}%'
                })
        
        epoch_loss = running_loss / len(val_loader)
        epoch_acc = 100. * correct / total
        
        return epoch_loss, epoch_acc, all_predictions, all_labels
    
    def train(self, train_loader, val_loader, num_epochs=10, learning_rate=0.001):
        """完整训练过程"""
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(self.model.parameters(), lr=learning_rate)
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)
        
        print(f"Starting training for {num_epochs} epochs...")
        print(f"Device: {self.device}")
        print(f"Model: {self.model.__class__.__name__}")
        
        for epoch in range(num_epochs):
            print(f"\nEpoch {epoch+1}/{num_epochs}")
            print("-" * 50)
            
            # 训练
            train_loss, train_acc = self.train_epoch(train_loader, criterion, optimizer)
            
            # 验证
            val_loss, val_acc, val_predictions, val_labels = self.validate_epoch(val_loader, criterion)
            
            # 更新学习率
            scheduler.step()
            
            # 记录历史
            self.training_history['train_loss'].append(train_loss)
            self.training_history['val_loss'].append(val_loss)
            self.training_history['val_accuracy'].append(val_acc)
            
            print(f"Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%")
            print(f"Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.2f}%")
            
            # 保存最佳模型
            if val_acc > self.best_accuracy:
                self.best_accuracy = val_acc
                self.save_checkpoint(epoch, val_acc)
                print(f"New best model saved! Accuracy: {val_acc:.2f}%")
            
            # 保存训练历史
            self.save_training_history()
    
    def save_checkpoint(self, epoch, accuracy):
        """保存模型检查点"""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'accuracy': accuracy,
            'training_history': self.training_history,
            'timestamp': datetime.now().isoformat()
        }
        
        checkpoint_path = os.path.join(self.save_dir, f'best_model_acc_{accuracy:.2f}.pth')
        torch.save(checkpoint, checkpoint_path)
        
        # 保存最新的模型
        latest_path = os.path.join(self.save_dir, 'latest_model.pth')
        torch.save(checkpoint, latest_path)
    
    def save_training_history(self):
        """保存训练历史"""
        history_path = os.path.join(self.save_dir, 'training_history.json')
        with open(history_path, 'w') as f:
            json.dump(self.training_history, f, indent=2)
    
    def plot_training_history(self):
        """绘制训练历史"""
        if len(self.training_history['train_loss']) == 0:
            print("No training history to plot")
            return
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
        
        # 损失图
        ax1.plot(self.training_history['train_loss'], label='Training Loss', marker='o')
        ax1.plot(self.training_history['val_loss'], label='Validation Loss', marker='s')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Loss')
        ax1.set_title('Training and Validation Loss')
        ax1.legend()
        ax1.grid(True)
        
        # 准确率图
        ax2.plot(self.training_history['val_accuracy'], label='Validation Accuracy', marker='o', color='green')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Accuracy (%)')
        ax2.set_title('Validation Accuracy')
        ax2.legend()
        ax2.grid(True)
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.save_dir, 'training_history.png'), dpi=300, bbox_inches='tight')
        plt.show()

def create_transforms(image_size=(224, 224)):
    """创建数据变换"""
    train_transform = transforms.Compose([
        transforms.Resize(image_size),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomRotation(degrees=15),
        transforms.ColorJitter(brightness=0.1, contrast=0.1, saturation=0.1, hue=0.1),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    val_transform = transforms.Compose([
        transforms.Resize(image_size),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    return train_transform, val_transform

def prepare_dicom_data(dicom_dir='.', test_size=0.2, random_state=42):
    """准备DICOM数据"""
    # 获取所有DICOM文件
    dicom_files = [f for f in os.listdir(dicom_dir) if f.endswith('.dcm')]
    dicom_paths = [os.path.join(dicom_dir, f) for f in dicom_files]
    
    print(f"Found {len(dicom_files)} DICOM files")
    
    # 创建虚拟标签（在实际应用中应该从文件名、目录结构或标注文件中获取）
    # 这里简单地根据文件名创建二分类标签
    labels = []
    for filename in dicom_files:
        # 假设文件名包含类别信息，或者根据某种规则创建标签
        # 这里简单地用文件编号的奇偶性作为标签
        file_num = int(filename.split('.')[0])
        labels.append(file_num % 2)  # 0 或 1
    
    # 分割数据
    train_files, val_files, train_labels, val_labels = train_test_split(
        dicom_paths, labels, test_size=test_size, random_state=random_state, stratify=labels
    )
    
    print(f"Train files: {len(train_files)}")
    print(f"Validation files: {len(val_files)}")
    print(f"Train label distribution: {np.bincount(train_labels)}")
    print(f"Validation label distribution: {np.bincount(val_labels)}")
    
    return train_files, val_files, train_labels, val_labels

def main():
    """主函数"""
    print("=== DICOM Training Pipeline ===")
    
    # 设置设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # 准备数据
    train_files, val_files, train_labels, val_labels = prepare_dicom_data(
        dicom_dir='.', test_size=0.2, random_state=42
    )
    
    # 创建变换
    train_transform, val_transform = create_transforms(image_size=(224, 224))
    
    # 创建数据集
    train_dataset = DICOMDataset(train_files, train_labels, transform=train_transform)
    val_dataset = DICOMDataset(val_files, val_labels, transform=val_transform)
    
    # 创建数据加载器
    train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True, num_workers=2)
    val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False, num_workers=2)
    
    # 创建模型（使用简单的ResNet18）
    import torchvision.models as models
    model = models.resnet18(weights='DEFAULT')
    model.fc = nn.Linear(model.fc.in_features, 2)  # 二分类
    
    # 创建训练器
    trainer = DICOMTrainer(model, device=device, save_dir='./checkpoints')
    
    # 开始训练
    trainer.train(
        train_loader=train_loader,
        val_loader=val_loader,
        num_epochs=5,  # 演示用较少的epoch
        learning_rate=0.001
    )
    
    # 绘制训练历史
    trainer.plot_training_history()
    
    print(f"\nTraining completed! Best accuracy: {trainer.best_accuracy:.2f}%")
    print(f"Model checkpoints saved in: {trainer.save_dir}")

if __name__ == "__main__":
    main()