#!/usr/bin/env python3
"""
DICOM Processing Demo Script
演示当前环境的DICOM处理能力
"""

import os
import pydicom
import numpy as np
import matplotlib.pyplot as plt
import torch
import torchvision.transforms as transforms
from PIL import Image
import cv2
import pandas as pd
from pathlib import Path

def analyze_dicom_file(dicom_path):
    """分析单个DICOM文件"""
    try:
        ds = pydicom.dcmread(dicom_path)
        
        info = {
            'filename': os.path.basename(dicom_path),
            'patient_id': ds.get('PatientID', 'N/A'),
            'modality': ds.get('Modality', 'N/A'),
            'study_date': ds.get('StudyDate', 'N/A'),
            'series_description': ds.get('SeriesDescription', 'N/A'),
            'rows': ds.get('Rows', 'N/A'),
            'columns': ds.get('Columns', 'N/A'),
            'bits_allocated': ds.get('BitsAllocated', 'N/A'),
            'photometric_interpretation': ds.get('PhotometricInterpretation', 'N/A'),
        }
        
        if hasattr(ds, 'pixel_array'):
            pixel_array = ds.pixel_array
            info.update({
                'pixel_shape': pixel_array.shape,
                'pixel_dtype': str(pixel_array.dtype),
                'pixel_min': pixel_array.min(),
                'pixel_max': pixel_array.max(),
                'pixel_mean': pixel_array.mean(),
                'pixel_std': pixel_array.std(),
                'has_pixel_data': True
            })
        else:
            info['has_pixel_data'] = False
            
        return info, ds
    except Exception as e:
        return {'filename': os.path.basename(dicom_path), 'error': str(e)}, None

def process_dicom_image(pixel_array, output_dir='processed_images'):
    """处理DICOM图像数据"""
    os.makedirs(output_dir, exist_ok=True)
    
    results = {}
    
    # 原始图像信息
    results['original_shape'] = pixel_array.shape
    results['original_dtype'] = str(pixel_array.dtype)
    
    # 如果是彩色图像
    if len(pixel_array.shape) == 3 and pixel_array.shape[2] == 3:
        # 转换为灰度
        gray_image = cv2.cvtColor(pixel_array, cv2.COLOR_RGB2GRAY)
        results['gray_shape'] = gray_image.shape
        
        # 边缘检测
        edges = cv2.Canny(gray_image, 50, 150)
        results['edges_detected'] = np.sum(edges > 0)
        
        # 直方图均衡化
        equalized = cv2.equalizeHist(gray_image)
        results['histogram_equalized'] = True
        
        # 创建PIL图像
        pil_image = Image.fromarray(pixel_array)
        results['pil_mode'] = pil_image.mode
        
        # PyTorch处理
        transform = transforms.Compose([
            transforms.ToTensor(),
            transforms.Resize((224, 224)),  # 标准输入尺寸
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        tensor_image = transform(pil_image)
        results['tensor_shape'] = tensor_image.shape
        results['tensor_dtype'] = str(tensor_image.dtype)
        
        # 如果有GPU，移动到GPU
        if torch.cuda.is_available():
            tensor_image_gpu = tensor_image.cuda()
            results['gpu_processed'] = True
        else:
            results['gpu_processed'] = False
            
    else:
        # 处理灰度图像
        results['is_grayscale'] = True
        
    return results

def analyze_all_dicoms(directory='.'):
    """分析目录中所有DICOM文件"""
    dicom_files = [f for f in os.listdir(directory) if f.endswith('.dcm')]
    
    print(f"Found {len(dicom_files)} DICOM files")
    
    all_info = []
    
    for i, dicom_file in enumerate(dicom_files[:10]):  # 只处理前10个文件作为示例
        print(f"Processing {dicom_file} ({i+1}/{min(10, len(dicom_files))})")
        
        info, ds = analyze_dicom_file(dicom_file)
        all_info.append(info)
        
        if ds is not None and hasattr(ds, 'pixel_array'):
            processing_results = process_dicom_image(ds.pixel_array)
            info.update(processing_results)
    
    # 创建DataFrame
    df = pd.DataFrame(all_info)
    
    # 保存分析结果
    df.to_csv('dicom_analysis_results.csv', index=False)
    print("Analysis results saved to 'dicom_analysis_results.csv'")
    
    return df

def demonstrate_deep_learning_readiness():
    """展示深度学习准备情况"""
    print("\n=== Deep Learning Readiness Check ===")
    
    # 检查设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Device: {device}")
    
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    
    # 创建简单的模型示例
    import torchvision.models as models
    
    print("\n=== Available Pre-trained Models ===")
    model_names = ['resnet18', 'resnet50', 'densenet121', 'efficientnet_b0']
    
    for model_name in model_names:
        try:
            model = getattr(models, model_name)(pretrained=False)
            total_params = sum(p.numel() for p in model.parameters())
            print(f"{model_name}: {total_params:,} parameters")
        except:
            print(f"{model_name}: Not available")
    
    # 创建自定义医学影像分类模型示例
    class MedicalImageClassifier(torch.nn.Module):
        def __init__(self, num_classes=2):
            super().__init__()
            self.backbone = models.resnet18(pretrained=True)
            self.backbone.fc = torch.nn.Linear(self.backbone.fc.in_features, num_classes)
            
        def forward(self, x):
            return self.backbone(x)
    
    model = MedicalImageClassifier(num_classes=2)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"\nCustom Medical Image Classifier: {total_params:,} parameters")
    
    # 测试模型前向传播
    dummy_input = torch.randn(1, 3, 224, 224)
    if torch.cuda.is_available():
        model = model.cuda()
        dummy_input = dummy_input.cuda()
    
    with torch.no_grad():
        output = model(dummy_input)
        print(f"Model output shape: {output.shape}")
    
    print("✓ Deep learning environment is ready!")

if __name__ == "__main__":
    print("=== DICOM Processing Environment Analysis ===")
    print("Current working directory:", os.getcwd())
    
    # 分析DICOM文件
    print("\n1. Analyzing DICOM files...")
    df = analyze_all_dicoms()
    
    # 显示基本统计信息
    print("\n2. Basic Statistics:")
    print(f"Total files analyzed: {len(df)}")
    if 'has_pixel_data' in df.columns:
        print(f"Files with pixel data: {df['has_pixel_data'].sum()}")
    
    if 'pixel_shape' in df.columns:
        shapes = df['pixel_shape'].dropna()
        if len(shapes) > 0:
            print(f"Common image shapes: {shapes.value_counts().head()}")
    
    # 展示深度学习准备情况
    print("\n3. Deep Learning Readiness:")
    demonstrate_deep_learning_readiness()
    
    print("\n=== Analysis Complete ===")