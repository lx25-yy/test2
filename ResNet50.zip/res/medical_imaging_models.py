#!/usr/bin/env python3
"""
Medical Imaging Deep Learning Models
医学影像深度学习模型示例集合
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from torchvision import transforms
import numpy as np

class MedicalImageClassifier2D(nn.Module):
    """
    2D医学影像分类器 - 适用于单张DICOM图像
    """
    def __init__(self, num_classes=2, backbone='resnet50', pretrained=True):
        super().__init__()
        
        # 选择骨干网络
        if backbone == 'resnet18':
            self.backbone = models.resnet18(weights='DEFAULT' if pretrained else None)
            feature_dim = 512
        elif backbone == 'resnet50':
            self.backbone = models.resnet50(weights='DEFAULT' if pretrained else None)
            feature_dim = 2048
        elif backbone == 'densenet121':
            self.backbone = models.densenet121(weights='DEFAULT' if pretrained else None)
            feature_dim = 1024
        elif backbone == 'efficientnet_b0':
            self.backbone = models.efficientnet_b0(weights='DEFAULT' if pretrained else None)
            feature_dim = 1280
        else:
            raise ValueError(f"Unsupported backbone: {backbone}")
        
        # 修改分类头
        if hasattr(self.backbone, 'fc'):
            self.backbone.fc = nn.Linear(self.backbone.fc.in_features, feature_dim)
        elif hasattr(self.backbone, 'classifier'):
            if isinstance(self.backbone.classifier, nn.Sequential):
                self.backbone.classifier[-1] = nn.Linear(self.backbone.classifier[-1].in_features, feature_dim)
            else:
                self.backbone.classifier = nn.Linear(self.backbone.classifier.in_features, feature_dim)
        
        # 自定义分类头
        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(feature_dim, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(512, num_classes)
        )
        
    def forward(self, x):
        features = self.backbone(x)
        return self.classifier(features)

class MedicalImageClassifier3D(nn.Module):
    """
    3D医学影像分类器 - 适用于DICOM序列/体数据
    """
    def __init__(self, num_classes=2, in_channels=1):
        super().__init__()
        
        # 3D卷积块
        self.conv1 = self._make_conv_block(in_channels, 64, 3, 1, 1)
        self.conv2 = self._make_conv_block(64, 128, 3, 1, 1)
        self.conv3 = self._make_conv_block(128, 256, 3, 1, 1)
        self.conv4 = self._make_conv_block(256, 512, 3, 1, 1)
        
        # 3D池化
        self.pool = nn.MaxPool3d(2, 2)
        
        # 全局平均池化
        self.global_avg_pool = nn.AdaptiveAvgPool3d(1)
        
        # 分类头
        self.classifier = nn.Sequential(
            nn.Dropout(0.5),
            nn.Linear(512, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes)
        )
        
    def _make_conv_block(self, in_channels, out_channels, kernel_size, stride, padding):
        return nn.Sequential(
            nn.Conv3d(in_channels, out_channels, kernel_size, stride, padding),
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv3d(out_channels, out_channels, kernel_size, stride, padding),
            nn.BatchNorm3d(out_channels),
            nn.ReLU(inplace=True)
        )
        
    def forward(self, x):
        # 输入形状: (batch_size, 1, depth, height, width)
        x = self.pool(self.conv1(x))
        x = self.pool(self.conv2(x))
        x = self.pool(self.conv3(x))
        x = self.pool(self.conv4(x))
        
        # 全局平均池化
        x = self.global_avg_pool(x)
        x = x.view(x.size(0), -1)
        
        return self.classifier(x)

class UNet2D(nn.Module):
    """
    2D U-Net用于医学图像分割
    """
    def __init__(self, in_channels=1, out_channels=1, init_features=32):
        super().__init__()
        
        features = init_features
        
        # 编码器
        self.encoder1 = self._make_encoder(in_channels, features)
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        
        self.encoder2 = self._make_encoder(features, features * 2)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        
        self.encoder3 = self._make_encoder(features * 2, features * 4)
        self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2)
        
        self.encoder4 = self._make_encoder(features * 4, features * 8)
        self.pool4 = nn.MaxPool2d(kernel_size=2, stride=2)
        
        # 瓶颈层
        self.bottleneck = self._make_encoder(features * 8, features * 16)
        
        # 解码器
        self.upconv4 = nn.ConvTranspose2d(features * 16, features * 8, kernel_size=2, stride=2)
        self.decoder4 = self._make_encoder(features * 16, features * 8)
        
        self.upconv3 = nn.ConvTranspose2d(features * 8, features * 4, kernel_size=2, stride=2)
        self.decoder3 = self._make_encoder(features * 8, features * 4)
        
        self.upconv2 = nn.ConvTranspose2d(features * 4, features * 2, kernel_size=2, stride=2)
        self.decoder2 = self._make_encoder(features * 4, features * 2)
        
        self.upconv1 = nn.ConvTranspose2d(features * 2, features, kernel_size=2, stride=2)
        self.decoder1 = self._make_encoder(features * 2, features)
        
        # 输出层
        self.conv_final = nn.Conv2d(features, out_channels, kernel_size=1)
        
    def _make_encoder(self, in_channels, out_channels):
        return nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True)
        )
        
    def forward(self, x):
        # 编码器
        enc1 = self.encoder1(x)
        enc2 = self.encoder2(self.pool1(enc1))
        enc3 = self.encoder3(self.pool2(enc2))
        enc4 = self.encoder4(self.pool3(enc3))
        
        # 瓶颈层
        bottleneck = self.bottleneck(self.pool4(enc4))
        
        # 解码器
        dec4 = self.upconv4(bottleneck)
        dec4 = torch.cat((dec4, enc4), dim=1)
        dec4 = self.decoder4(dec4)
        
        dec3 = self.upconv3(dec4)
        dec3 = torch.cat((dec3, enc3), dim=1)
        dec3 = self.decoder3(dec3)
        
        dec2 = self.upconv2(dec3)
        dec2 = torch.cat((dec2, enc2), dim=1)
        dec2 = self.decoder2(dec2)
        
        dec1 = self.upconv1(dec2)
        dec1 = torch.cat((dec1, enc1), dim=1)
        dec1 = self.decoder1(dec1)
        
        return self.conv_final(dec1)

class MedicalViT(nn.Module):
    """
    医学影像Vision Transformer
    """
    def __init__(self, image_size=224, patch_size=16, num_classes=2, dim=768, depth=12, heads=12, mlp_dim=3072):
        super().__init__()
        
        self.image_size = image_size
        self.patch_size = patch_size
        self.num_patches = (image_size // patch_size) ** 2
        self.patch_dim = 3 * patch_size ** 2
        
        # Patch embedding
        self.patch_embedding = nn.Linear(self.patch_dim, dim)
        self.pos_embedding = nn.Parameter(torch.randn(1, self.num_patches + 1, dim))
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        
        # Transformer blocks
        self.transformer = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=dim, nhead=heads, dim_feedforward=mlp_dim, dropout=0.1),
            num_layers=depth
        )
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, num_classes)
        )
        
    def forward(self, x):
        batch_size = x.size(0)
        
        # 将图像分割成patches
        x = x.unfold(2, self.patch_size, self.patch_size).unfold(3, self.patch_size, self.patch_size)
        x = x.contiguous().view(batch_size, 3, -1, self.patch_size, self.patch_size)
        x = x.permute(0, 2, 1, 3, 4).contiguous()
        x = x.view(batch_size, self.num_patches, -1)
        
        # Patch embedding
        x = self.patch_embedding(x)
        
        # 添加cls token
        cls_tokens = self.cls_token.expand(batch_size, -1, -1)
        x = torch.cat([cls_tokens, x], dim=1)
        
        # 添加位置编码
        x = x + self.pos_embedding
        
        # Transformer
        x = self.transformer(x)
        
        # 使用cls token进行分类
        cls_output = x[:, 0]
        return self.classifier(cls_output)

class DICOMDataProcessor:
    """
    DICOM数据处理器
    """
    def __init__(self, target_size=(224, 224)):
        self.target_size = target_size
        
        # 标准化的预处理管道
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize(target_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
        ])
        
        # 灰度图像预处理
        self.grayscale_transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize(target_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5], std=[0.5])
        ])
        
        # 分割任务预处理
        self.segmentation_transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize(target_size),
            transforms.ToTensor()
        ])
    
    def preprocess_rgb(self, pixel_array):
        """预处理RGB图像"""
        if len(pixel_array.shape) == 3 and pixel_array.shape[2] == 3:
            return self.transform(pixel_array.astype(np.uint8))
        else:
            raise ValueError("Input must be RGB image")
    
    def preprocess_grayscale(self, pixel_array):
        """预处理灰度图像"""
        if len(pixel_array.shape) == 2:
            return self.grayscale_transform(pixel_array.astype(np.uint8))
        elif len(pixel_array.shape) == 3 and pixel_array.shape[2] == 3:
            # 转换为灰度
            import cv2
            gray = cv2.cvtColor(pixel_array, cv2.COLOR_RGB2GRAY)
            return self.grayscale_transform(gray.astype(np.uint8))
        else:
            raise ValueError("Invalid image format")
    
    def preprocess_for_segmentation(self, pixel_array):
        """预处理用于分割任务"""
        if len(pixel_array.shape) == 3 and pixel_array.shape[2] == 3:
            import cv2
            gray = cv2.cvtColor(pixel_array, cv2.COLOR_RGB2GRAY)
            return self.segmentation_transform(gray.astype(np.uint8))
        elif len(pixel_array.shape) == 2:
            return self.segmentation_transform(pixel_array.astype(np.uint8))
        else:
            raise ValueError("Invalid image format")

def create_model(model_type, num_classes=2, **kwargs):
    """
    创建模型工厂函数
    """
    if model_type == '2d_classifier':
        return MedicalImageClassifier2D(num_classes=num_classes, **kwargs)
    elif model_type == '3d_classifier':
        return MedicalImageClassifier3D(num_classes=num_classes, **kwargs)
    elif model_type == 'unet':
        return UNet2D(**kwargs)
    elif model_type == 'vit':
        return MedicalViT(num_classes=num_classes, **kwargs)
    else:
        raise ValueError(f"Unknown model type: {model_type}")

def model_summary(model, input_size):
    """
    模型摘要
    """
    def count_parameters(model):
        return sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    print(f"Model: {model.__class__.__name__}")
    print(f"Total parameters: {count_parameters(model):,}")
    
    # 测试前向传播
    if len(input_size) == 4:  # 2D input
        dummy_input = torch.randn(1, *input_size)
    elif len(input_size) == 5:  # 3D input
        dummy_input = torch.randn(1, *input_size)
    else:
        raise ValueError("Invalid input size")
    
    with torch.no_grad():
        try:
            output = model(dummy_input)
            print(f"Input shape: {dummy_input.shape}")
            print(f"Output shape: {output.shape}")
        except Exception as e:
            print(f"Forward pass failed: {e}")

if __name__ == "__main__":
    print("=== Medical Imaging Models Demo ===")
    
    # 创建不同类型的模型
    models_config = [
        ('2d_classifier', {'backbone': 'resnet50', 'num_classes': 2}),
        ('3d_classifier', {'num_classes': 2}),
        ('unet', {'in_channels': 1, 'out_channels': 1}),
        ('vit', {'num_classes': 2, 'image_size': 224})
    ]
    
    for model_type, config in models_config:
        print(f"\n=== {model_type.upper()} ===")
        try:
            model = create_model(model_type, **config)
            
            if model_type == '2d_classifier' or model_type == 'vit':
                model_summary(model, (3, 224, 224))
            elif model_type == '3d_classifier':
                model_summary(model, (1, 32, 224, 224))
            elif model_type == 'unet':
                model_summary(model, (1, 224, 224))
                
        except Exception as e:
            print(f"Error creating {model_type}: {e}")
    
    print("\n=== Data Processor Demo ===")
    processor = DICOMDataProcessor()
    
    # 创建虚拟的DICOM像素数据
    dummy_rgb = np.random.randint(0, 255, (410, 520, 3), dtype=np.uint8)
    dummy_gray = np.random.randint(0, 255, (410, 520), dtype=np.uint8)
    
    try:
        processed_rgb = processor.preprocess_rgb(dummy_rgb)
        print(f"RGB preprocessing: {dummy_rgb.shape} -> {processed_rgb.shape}")
        
        processed_gray = processor.preprocess_grayscale(dummy_gray)
        print(f"Grayscale preprocessing: {dummy_gray.shape} -> {processed_gray.shape}")
        
        processed_seg = processor.preprocess_for_segmentation(dummy_gray)
        print(f"Segmentation preprocessing: {dummy_gray.shape} -> {processed_seg.shape}")
        
    except Exception as e:
        print(f"Data processing error: {e}")
    
    print("\n=== GPU Availability ===")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"GPU count: {torch.cuda.device_count()}")
        print(f"Current GPU: {torch.cuda.get_device_name(0)}")
        print(f"GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")