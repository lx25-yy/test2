# -*- coding: utf-8 -*-
"""
DICOM file inspection script
"""

import sys
from pathlib import Path
import pydicom
from pydicom.errors import InvalidDicomError

def check_single_dicom(file_path):
    """Check a single DICOM file"""
    try:
        print(f"\nChecking: {file_path}")
        
        # Try to read the file
        try:
            dataset = pydicom.dcmread(str(file_path), force=True)
            print("  - Successfully read with pydicom")
        except InvalidDicomError as e:
            print(f"  - InvalidDicomError: {e}")
            return False
        except Exception as e:
            print(f"  - Read error: {e}")
            return False
        
        # Check basic properties
        print(f"  - File meta info present: {hasattr(dataset, 'file_meta')}")
        
        # Check required tags
        required_tags = ['SOPClassUID', 'SOPInstanceUID', 'StudyInstanceUID']
        missing_tags = []
        
        for tag in required_tags:
            if hasattr(dataset, tag):
                print(f"  - {tag}: {getattr(dataset, tag)}")
            else:
                missing_tags.append(tag)
        
        if missing_tags:
            print(f"  - Missing required tags: {missing_tags}")
        
        # Check image properties
        if hasattr(dataset, 'Rows') and hasattr(dataset, 'Columns'):
            print(f"  - Image size: {dataset.Rows} x {dataset.Columns}")
        else:
            print("  - No image size info")
        
        if hasattr(dataset, 'Modality'):
            print(f"  - Modality: {dataset.Modality}")
        
        # Check pixel data
        try:
            pixel_array = dataset.pixel_array
            print(f"  - Pixel data shape: {pixel_array.shape}")
            print(f"  - Pixel data type: {pixel_array.dtype}")
            print(f"  - Pixel value range: {pixel_array.min()} - {pixel_array.max()}")
        except Exception as e:
            print(f"  - Pixel data error: {e}")
        
        return len(missing_tags) == 0
        
    except Exception as e:
        print(f"  - General error: {e}")
        return False

def main():
    """Main function"""
    current_dir = Path(".")
    dcm_files = list(current_dir.glob("*.dcm"))
    
    if not dcm_files:
        print("No .dcm files found in current directory")
        return
    
    print(f"Found {len(dcm_files)} .dcm files")
    
    # Check first few files
    valid_count = 0
    invalid_count = 0
    
    for i, dcm_file in enumerate(dcm_files[:5]):  # Check first 5
        is_valid = check_single_dicom(dcm_file)
        if is_valid:
            valid_count += 1
        else:
            invalid_count += 1
    
    print(f"\nSummary of first 5 files:")
    print(f"Valid: {valid_count}")
    print(f"Invalid: {invalid_count}")
    
    if valid_count > 0:
        print("Some files appear to be valid DICOM files")
    else:
        print("Files may be missing required DICOM tags")

if __name__ == "__main__":
    main()