# -*- coding: utf-8 -*-
"""
Image preprocessor unit tests

Test various preprocessing functions to ensure correct image transformation for ResNet.
"""

import unittest
import tempfile
import shutil
from pathlib import Path
import numpy as np
import torch
from unittest.mock import Mock

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.preprocessors import (
    ResNetPreprocessor, FlexiblePreprocessor, BatchPreprocessor, 
    PreprocessorFactory, ImageAugmentor
)
from src.core.interfaces import DICOMImage
from src.core.exceptions import ImagePreprocessingError
from src.core.logger import log_manager


class TestBaseImagePreprocessor(unittest.TestCase):
    """Test base image preprocessor functionality"""
    
    def setUp(self):
        """Test setup"""
        # Configure logging
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.preprocessor = ResNetPreprocessor()
        
        # Create test images
        self.rgb_image = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        self.gray_image = np.random.randint(0, 255, (100, 100), dtype=np.uint8)
        self.float_image = np.random.rand(100, 100, 3).astype(np.float32)
    
    def test_resize_image(self):
        """Test image resizing"""
        target_size = (224, 224)
        
        # Test RGB image resize
        resized = self.preprocessor.resize_image(self.rgb_image, target_size)
        self.assertEqual(resized.shape[:2], target_size)
        self.assertEqual(resized.shape[2], 3)
        
        # Test grayscale image resize
        resized_gray = self.preprocessor.resize_image(self.gray_image, target_size)
        self.assertEqual(resized_gray.shape, target_size)
    
    def test_normalize_pixels(self):
        """Test pixel normalization"""
        # Test uint8 normalization
        normalized = self.preprocessor.normalize_pixels(self.rgb_image)
        self.assertEqual(normalized.dtype, np.float32)
        self.assertGreaterEqual(normalized.min(), 0.0)
        self.assertLessEqual(normalized.max(), 1.0)
        
        # Test uint16 normalization
        uint16_image = np.random.randint(0, 65535, (50, 50, 3), dtype=np.uint16)
        normalized_16 = self.preprocessor.normalize_pixels(uint16_image)
        self.assertEqual(normalized_16.dtype, np.float32)
        self.assertGreaterEqual(normalized_16.min(), 0.0)
        self.assertLessEqual(normalized_16.max(), 1.0)
        
        # Test float image (already normalized)
        normalized_float = self.preprocessor.normalize_pixels(self.float_image)
        self.assertEqual(normalized_float.dtype, np.float32)
        np.testing.assert_array_almost_equal(normalized_float, self.float_image, decimal=5)
    
    def test_convert_to_rgb(self):
        """Test RGB conversion"""
        # Test grayscale to RGB
        rgb_from_gray = self.preprocessor.convert_to_rgb(self.gray_image)
        self.assertEqual(rgb_from_gray.shape, (100, 100, 3))
        
        # Test single channel to RGB
        single_channel = np.random.randint(0, 255, (100, 100, 1), dtype=np.uint8)
        rgb_from_single = self.preprocessor.convert_to_rgb(single_channel)
        self.assertEqual(rgb_from_single.shape, (100, 100, 3))
        
        # Test RGB (no change needed)
        rgb_unchanged = self.preprocessor.convert_to_rgb(self.rgb_image)
        self.assertEqual(rgb_unchanged.shape, self.rgb_image.shape)
        np.testing.assert_array_equal(rgb_unchanged, self.rgb_image)
        
        # Test RGBA to RGB
        rgba_image = np.random.randint(0, 255, (100, 100, 4), dtype=np.uint8)
        rgb_from_rgba = self.preprocessor.convert_to_rgb(rgba_image)
        self.assertEqual(rgb_from_rgba.shape, (100, 100, 3))
    
    def test_invalid_inputs(self):
        """Test error handling for invalid inputs"""
        # Test invalid image shape for resize
        invalid_image = np.random.rand(10, 10, 10, 10)  # 4D image
        with self.assertRaises(ImagePreprocessingError):
            self.preprocessor.resize_image(invalid_image, (224, 224))
        
        # Test unsupported number of channels
        invalid_channels = np.random.randint(0, 255, (100, 100, 5), dtype=np.uint8)
        with self.assertRaises(ImagePreprocessingError):
            self.preprocessor.convert_to_rgb(invalid_channels)


class TestResNetPreprocessor(unittest.TestCase):
    """Test ResNet-specific preprocessor"""
    
    def setUp(self):
        """Test setup"""
        # Configure logging
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.preprocessor = ResNetPreprocessor()
        
        # Create mock DICOM image
        self.mock_dicom = self._create_mock_dicom_image()
    
    def _create_mock_dicom_image(self) -> DICOMImage:
        """Create a mock DICOM image for testing"""
        pixel_data = np.random.randint(0, 255, (410, 520, 3), dtype=np.uint8)
        metadata = {
            'height': 410,
            'width': 520,
            'modality': 'OT'
        }
        
        return DICOMImage(
            file_path="test.dcm",
            pixel_data=pixel_data,
            metadata=metadata,
            original_shape=(410, 520, 3),
            modality="OT"
        )
    
    def test_preprocess_image_basic(self):
        """Test basic image preprocessing"""
        tensor = self.preprocessor.preprocess_image(self.mock_dicom)
        
        # Check tensor properties
        self.assertIsInstance(tensor, torch.Tensor)
        self.assertEqual(tensor.shape, (3, 224, 224))  # CHW format
        self.assertEqual(tensor.dtype, torch.float32)
    
    def test_preprocess_image_with_imagenet_normalization(self):
        """Test preprocessing with ImageNet normalization"""
        preprocessor = ResNetPreprocessor(normalize_method='imagenet')
        tensor = preprocessor.preprocess_image(self.mock_dicom)
        
        self.assertEqual(tensor.shape, (3, 224, 224))
        # ImageNet normalization should give values around [-2, 2] range
        self.assertGreater(tensor.max(), -3.0)
        self.assertLess(tensor.min(), 3.0)
    
    def test_preprocess_image_custom_size(self):
        """Test preprocessing with custom target size"""
        custom_size = (256, 256)
        preprocessor = ResNetPreprocessor(target_size=custom_size)
        tensor = preprocessor.preprocess_image(self.mock_dicom)
        
        self.assertEqual(tensor.shape, (3, 256, 256))
    
    def test_preprocess_image_custom_normalization(self):
        """Test preprocessing with custom normalization"""
        custom_mean = (0.5, 0.5, 0.5)
        custom_std = (0.2, 0.2, 0.2)
        
        preprocessor = ResNetPreprocessor(
            normalize_method='custom',
            custom_mean=custom_mean,
            custom_std=custom_std
        )
        
        tensor = preprocessor.preprocess_image(self.mock_dicom)
        self.assertEqual(tensor.shape, (3, 224, 224))
    
    def test_preprocess_grayscale_image(self):
        """Test preprocessing of grayscale image"""
        # Create grayscale DICOM image
        gray_pixel_data = np.random.randint(0, 255, (410, 520), dtype=np.uint8)
        gray_dicom = DICOMImage(
            file_path="gray_test.dcm",
            pixel_data=gray_pixel_data,
            metadata={'height': 410, 'width': 520},
            original_shape=(410, 520),
            modality="OT"
        )
        
        tensor = self.preprocessor.preprocess_image(gray_dicom)
        self.assertEqual(tensor.shape, (3, 224, 224))  # Should be converted to RGB


class TestFlexiblePreprocessor(unittest.TestCase):
    """Test flexible preprocessor"""
    
    def setUp(self):
        """Test setup"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.config = {
            'target_size': (224, 224),
            'normalize_method': 'imagenet',
            'processing_steps': ['resize', 'convert_to_rgb', 'normalize_pixels', 'to_tensor']
        }
        
        self.preprocessor = FlexiblePreprocessor(self.config)
        self.mock_dicom = self._create_mock_dicom_image()
    
    def _create_mock_dicom_image(self) -> DICOMImage:
        """Create a mock DICOM image for testing"""
        pixel_data = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        return DICOMImage(
            file_path="test.dcm",
            pixel_data=pixel_data,
            metadata={},
            original_shape=(100, 100, 3),
            modality="OT"
        )
    
    def test_config_validation(self):
        """Test configuration validation"""
        # Test missing required key
        invalid_config = {'normalize_method': 'imagenet'}
        with self.assertRaises(ImagePreprocessingError):
            FlexiblePreprocessor(invalid_config)
    
    def test_flexible_preprocessing(self):
        """Test flexible preprocessing pipeline"""
        tensor = self.preprocessor.preprocess_image(self.mock_dicom)
        
        self.assertIsInstance(tensor, torch.Tensor)
        self.assertEqual(tensor.shape, (3, 224, 224))
    
    def test_custom_processing_steps(self):
        """Test custom processing steps"""
        custom_config = {
            'target_size': (128, 128),
            'normalize_method': 'none',
            'processing_steps': ['resize', 'to_tensor']
        }
        
        preprocessor = FlexiblePreprocessor(custom_config)
        tensor = preprocessor.preprocess_image(self.mock_dicom)
        
        # Should be 128x128 and may not be RGB converted
        self.assertIn(128, tensor.shape)


class TestBatchPreprocessor(unittest.TestCase):
    """Test batch preprocessor"""
    
    def setUp(self):
        """Test setup"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.single_preprocessor = ResNetPreprocessor()
        self.batch_preprocessor = BatchPreprocessor(self.single_preprocessor, batch_size=4)
        
        # Create multiple mock DICOM images
        self.mock_dicoms = [self._create_mock_dicom_image(i) for i in range(6)]
    
    def _create_mock_dicom_image(self, index: int) -> DICOMImage:
        """Create a mock DICOM image for testing"""
        pixel_data = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        return DICOMImage(
            file_path=f"test_{index}.dcm",
            pixel_data=pixel_data,
            metadata={},
            original_shape=(100, 100, 3),
            modality="OT"
        )
    
    def test_preprocess_batch(self):
        """Test batch preprocessing"""
        # Test with smaller batch
        batch_tensor = self.batch_preprocessor.preprocess_batch(self.mock_dicoms[:3])
        
        self.assertIsInstance(batch_tensor, torch.Tensor)
        self.assertEqual(batch_tensor.shape, (3, 3, 224, 224))  # (batch, channels, height, width)
    
    def test_preprocess_batch_generator(self):
        """Test batch preprocessing generator"""
        batches = list(self.batch_preprocessor.preprocess_batch_generator(self.mock_dicoms))
        
        # Should create 2 batches: 4 + 2 images
        self.assertEqual(len(batches), 2)
        self.assertEqual(batches[0].shape[0], 4)  # First batch: 4 images
        self.assertEqual(batches[1].shape[0], 2)  # Second batch: 2 images
    
    def test_batch_with_failed_images(self):
        """Test batch processing with some failed images"""
        # Create a bad DICOM image that will fail preprocessing
        bad_dicom = DICOMImage(
            file_path="bad.dcm",
            pixel_data=np.array([]),  # Empty array will cause failure
            metadata={},
            original_shape=(),
            modality="OT"
        )
        
        mixed_dicoms = self.mock_dicoms[:2] + [bad_dicom] + self.mock_dicoms[2:4]
        
        # Should process successfully despite the bad image
        batch_tensor = self.batch_preprocessor.preprocess_batch(mixed_dicoms)
        self.assertEqual(batch_tensor.shape[0], 4)  # 4 successful images (2+2, excluding bad one)


class TestPreprocessorFactory(unittest.TestCase):
    """Test preprocessor factory"""
    
    def test_create_resnet_preprocessor(self):
        """Test ResNet preprocessor creation"""
        preprocessor = PreprocessorFactory.create_resnet_preprocessor()
        self.assertIsInstance(preprocessor, ResNetPreprocessor)
        self.assertEqual(preprocessor.target_size, (224, 224))
    
    def test_create_custom_preprocessor(self):
        """Test custom preprocessor creation"""
        config = {
            'target_size': (256, 256),
            'normalize_method': 'custom'
        }
        
        preprocessor = PreprocessorFactory.create_custom_preprocessor(config)
        self.assertIsInstance(preprocessor, FlexiblePreprocessor)
    
    def test_create_batch_preprocessor(self):
        """Test batch preprocessor creation"""
        single_preprocessor = ResNetPreprocessor()
        batch_preprocessor = PreprocessorFactory.create_batch_preprocessor(
            single_preprocessor, batch_size=16
        )
        
        self.assertIsInstance(batch_preprocessor, BatchPreprocessor)
        self.assertEqual(batch_preprocessor.batch_size, 16)
    
    def test_create_from_config(self):
        """Test preprocessor creation from config"""
        # Test ResNet config
        resnet_config = {
            'type': 'resnet',
            'target_size': [256, 256],
            'normalize_method': 'imagenet'
        }
        
        preprocessor = PreprocessorFactory.create_from_config(resnet_config)
        self.assertIsInstance(preprocessor, ResNetPreprocessor)
        
        # Test flexible config
        flexible_config = {
            'type': 'flexible',
            'target_size': (128, 128),
            'normalize_method': 'custom'
        }
        
        preprocessor = PreprocessorFactory.create_from_config(flexible_config)
        self.assertIsInstance(preprocessor, FlexiblePreprocessor)
        
        # Test unknown type
        unknown_config = {'type': 'unknown'}
        with self.assertRaises(ImagePreprocessingError):
            PreprocessorFactory.create_from_config(unknown_config)


class TestImageAugmentor(unittest.TestCase):
    """Test image augmentor"""
    
    def test_augmentor_creation(self):
        """Test augmentor creation and configuration"""
        config = {
            'random_rotation': True,
            'rotation_degrees': 15,
            'random_flip': True,
            'color_jitter': True,
            'brightness': 0.2,
            'contrast': 0.2
        }
        
        augmentor = ImageAugmentor(config)
        self.assertIsNotNone(augmentor.augmentations)
    
    def test_augment_tensor(self):
        """Test tensor augmentation"""
        config = {'random_flip': True}
        augmentor = ImageAugmentor(config)
        
        # Create test tensor
        tensor = torch.rand(3, 224, 224)
        augmented = augmentor.augment_tensor(tensor)
        
        self.assertEqual(augmented.shape, tensor.shape)
        self.assertIsInstance(augmented, torch.Tensor)
    
    def test_no_augmentation(self):
        """Test augmentor with no augmentations"""
        config = {}
        augmentor = ImageAugmentor(config)
        
        tensor = torch.rand(3, 224, 224)
        result = augmentor.augment_tensor(tensor)
        
        # Should return original tensor when no augmentations
        torch.testing.assert_close(result, tensor)


if __name__ == '__main__':
    # Create test suite
    test_classes = [
        TestBaseImagePreprocessor,
        TestResNetPreprocessor, 
        TestFlexiblePreprocessor,
        TestBatchPreprocessor,
        TestPreprocessorFactory,
        TestImageAugmentor
    ]
    
    loader = unittest.TestLoader()
    suites = [loader.loadTestsFromTestCase(test_class) for test_class in test_classes]
    combined_suite = unittest.TestSuite(suites)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(combined_suite)
    
    # Output results
    if result.wasSuccessful():
        print(f"\nAll tests passed ({result.testsRun} tests)")
    else:
        print(f"\nTests failed: {len(result.failures)} failures, {len(result.errors)} errors")
        
        for failure in result.failures:
            print(f"\nFailure: {failure[0]}")
            print(failure[1])
        
        for error in result.errors:
            print(f"\nError: {error[0]}")
            print(error[1])