# -*- coding: utf-8 -*-
"""
Output system unit tests

Test multi-format feature output functionality.
"""

import unittest
import tempfile
import shutil
import os
from pathlib import Path
import numpy as np
from datetime import datetime
from unittest.mock import Mock, patch

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.output.data_structures import (
    OutputFormat, CompressionType, FeatureRecord, FeatureDataset,
    OutputConfig, OutputResult, estimate_memory_usage, calculate_optimal_chunk_size
)
from src.output.writers import NumpyFeatureWriter, CSVFeatureWriter, JSONFeatureWriter
from src.output.output_manager import OutputWriterFactory, FeatureOutputManager
from src.core.logger import log_manager


class TestFeatureRecord(unittest.TestCase):
    """测试特征记录数据结构"""
    
    def test_feature_record_creation(self):
        """测试特征记录创建"""
        features = np.random.randn(2048)
        record = FeatureRecord(
            file_path="test.dcm",
            features=features,
            feature_dimensions=(2048,),
            metadata={"patient_id": "test"},
            extraction_timestamp=datetime.now(),
            processing_time=1.5,
            success=True
        )
        
        self.assertEqual(record.file_path, "test.dcm")
        self.assertEqual(record.feature_dimensions, (2048,))
        self.assertTrue(record.success)
        self.assertEqual(record.metadata["patient_id"], "test")
        np.testing.assert_array_equal(record.features, features)


class TestFeatureDataset(unittest.TestCase):
    """测试特征数据集"""
    
    def setUp(self):
        """测试设置"""
        self.records = []
        for i in range(5):
            features = np.random.randn(2048)
            record = FeatureRecord(
                file_path=f"test_{i}.dcm",
                features=features,
                feature_dimensions=(2048,),
                metadata={"index": i},
                extraction_timestamp=datetime.now(),
                processing_time=1.0 + i * 0.1,
                success=True
            )
            self.records.append(record)
        
        self.dataset = FeatureDataset(self.records)
    
    def test_dataset_creation(self):
        """测试数据集创建"""
        self.assertEqual(len(self.dataset.records), 5)
        self.assertIsInstance(self.dataset.dataset_metadata, dict)
        self.assertEqual(self.dataset.dataset_metadata['total_records'], 5)
        self.assertEqual(self.dataset.dataset_metadata['successful_records'], 5)
    
    def test_feature_matrix(self):
        """测试特征矩阵属性"""
        matrix = self.dataset.feature_matrix
        self.assertIsNotNone(matrix)
        self.assertEqual(matrix.shape, (5, 2048))
    
    def test_success_rate(self):
        """测试成功率计算"""
        self.assertEqual(self.dataset.success_rate, 1.0)
        
        # 添加失败记录
        failed_record = FeatureRecord(
            file_path="failed.dcm",
            features=np.array([]),
            feature_dimensions=(0,),
            metadata={},
            extraction_timestamp=datetime.now(),
            processing_time=0.0,
            success=False,
            error_message="Test error"
        )
        
        dataset_with_failure = FeatureDataset(self.records + [failed_record])
        self.assertAlmostEqual(dataset_with_failure.success_rate, 5/6)


class TestOutputConfig(unittest.TestCase):
    """测试输出配置"""
    
    def test_output_config_creation(self):
        """测试输出配置创建"""
        config = OutputConfig(
            format=OutputFormat.NUMPY,
            output_path="/tmp/output",
            filename_prefix="features",
            compression=CompressionType.GZIP,
            compression_level=6
        )
        
        self.assertEqual(config.format, OutputFormat.NUMPY)
        self.assertEqual(config.compression, CompressionType.GZIP)
        self.assertEqual(config.compression_level, 6)
        self.assertTrue(config.include_metadata)
    
    def test_config_validation(self):
        """测试配置验证"""
        # 测试无效的压缩级别
        with self.assertRaises(ValueError):
            OutputConfig(
                format=OutputFormat.NUMPY,
                output_path="/tmp/output",
                compression_level=15  # 无效值
            )
        
        # 测试无效的分块大小
        with self.assertRaises(ValueError):
            OutputConfig(
                format=OutputFormat.NUMPY,
                output_path="/tmp/output",
                chunk_size=0  # 无效值
            )


class TestOutputWriterFactory(unittest.TestCase):
    """测试输出写入器工厂"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
    
    def test_create_numpy_writer(self):
        """测试创建NumPy写入器"""
        writer = OutputWriterFactory.create_writer(OutputFormat.NUMPY)
        self.assertIsInstance(writer, NumpyFeatureWriter)
    
    def test_create_csv_writer(self):
        """测试创建CSV写入器"""
        writer = OutputWriterFactory.create_writer(OutputFormat.CSV)
        self.assertIsInstance(writer, CSVFeatureWriter)
    
    def test_create_json_writer(self):
        """测试创建JSON写入器"""
        writer = OutputWriterFactory.create_writer(OutputFormat.JSON)
        self.assertIsInstance(writer, JSONFeatureWriter)
    
    def test_get_supported_formats(self):
        """测试获取支持的格式"""
        formats = OutputWriterFactory.get_supported_formats()
        self.assertIsInstance(formats, list)
        self.assertIn(OutputFormat.NUMPY, formats)
        self.assertIn(OutputFormat.CSV, formats)
        self.assertIn(OutputFormat.JSON, formats)
    
    def test_is_format_supported(self):
        """测试格式支持检查"""
        self.assertTrue(OutputWriterFactory.is_format_supported(OutputFormat.NUMPY))
        self.assertTrue(OutputWriterFactory.is_format_supported(OutputFormat.CSV))


class TestNumpyFeatureWriter(unittest.TestCase):
    """测试NumPy特征写入器"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.temp_dir = tempfile.mkdtemp()
        self.writer = NumpyFeatureWriter()
        
        # 创建测试数据集
        records = []
        for i in range(3):
            features = np.random.randn(100)  # 较小的特征向量用于测试
            record = FeatureRecord(
                file_path=f"test_{i}.dcm",
                features=features,
                feature_dimensions=(100,),
                metadata={"index": i},
                extraction_timestamp=datetime.now(),
                processing_time=1.0,
                success=True
            )
            records.append(record)
        
        self.dataset = FeatureDataset(records)
        self.config = OutputConfig(
            format=OutputFormat.NUMPY,
            output_path=self.temp_dir,
            filename_prefix="test_features"
        )
    
    def tearDown(self):
        """测试清理"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_get_file_extension(self):
        """测试文件扩展名"""
        self.assertEqual(self.writer.get_file_extension(), ".npy")
    
    def test_estimate_output_size(self):
        """测试输出大小估算"""
        size = self.writer.estimate_output_size(self.dataset, self.config)
        self.assertGreater(size, 0)
        self.assertIsInstance(size, int)
    
    def test_write_uncompressed(self):
        """测试无压缩写入"""
        result = self.writer.write(self.dataset, self.config)
        
        self.assertTrue(result.success)
        self.assertEqual(len(result.output_files), 1)
        self.assertEqual(result.successful_records, 3)
        self.assertEqual(result.failed_records, 0)
        
        # 验证文件存在
        output_file = result.output_files[0]
        self.assertTrue(os.path.exists(output_file))
        
        # 验证内容
        loaded_features = np.load(output_file)
        self.assertEqual(loaded_features.shape, (3, 100))
    
    def test_write_compressed(self):
        """测试压缩写入"""
        self.config.compression = CompressionType.GZIP
        result = self.writer.write(self.dataset, self.config)
        
        self.assertTrue(result.success)
        self.assertEqual(len(result.output_files), 1)
        
        # 验证文件存在且是压缩格式
        output_file = result.output_files[0]
        self.assertTrue(output_file.endswith('.npz'))
        self.assertTrue(os.path.exists(output_file))
    
    def test_validate_output(self):
        """测试输出验证"""
        result = self.writer.write(self.dataset, self.config)
        is_valid = self.writer.validate_output(result.output_files, self.dataset)
        self.assertTrue(is_valid)


class TestCSVFeatureWriter(unittest.TestCase):
    """测试CSV特征写入器"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.temp_dir = tempfile.mkdtemp()
        self.writer = CSVFeatureWriter()
        
        # 创建测试数据集
        records = []
        for i in range(2):
            features = np.random.randn(10)  # 小特征向量用于CSV测试
            record = FeatureRecord(
                file_path=f"test_{i}.dcm",
                features=features,
                feature_dimensions=(10,),
                metadata={"index": i},
                extraction_timestamp=datetime.now(),
                processing_time=1.0,
                success=True
            )
            records.append(record)
        
        self.dataset = FeatureDataset(records)
        self.config = OutputConfig(
            format=OutputFormat.CSV,
            output_path=self.temp_dir,
            filename_prefix="test_features"
        )
    
    def tearDown(self):
        """测试清理"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_get_file_extension(self):
        """测试文件扩展名"""
        self.assertEqual(self.writer.get_file_extension(), ".csv")
    
    def test_write_csv(self):
        """测试CSV写入"""
        result = self.writer.write(self.dataset, self.config)
        
        self.assertTrue(result.success)
        self.assertEqual(len(result.output_files), 1)
        
        # 验证文件存在
        output_file = result.output_files[0]
        self.assertTrue(os.path.exists(output_file))
        
        # 验证CSV内容
        import pandas as pd
        df = pd.read_csv(output_file)
        
        self.assertEqual(len(df), 2)
        self.assertIn('file_path', df.columns)
        feature_columns = [col for col in df.columns if col.startswith('feature_')]
        self.assertEqual(len(feature_columns), 10)
    
    def test_validate_output(self):
        """测试CSV输出验证"""
        result = self.writer.write(self.dataset, self.config)
        is_valid = self.writer.validate_output(result.output_files, self.dataset)
        self.assertTrue(is_valid)


class TestJSONFeatureWriter(unittest.TestCase):
    """测试JSON特征写入器"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.temp_dir = tempfile.mkdtemp()
        self.writer = JSONFeatureWriter()
        
        # 创建测试数据集
        records = []
        for i in range(2):
            features = np.random.randn(5)  # 小特征向量用于JSON测试
            record = FeatureRecord(
                file_path=f"test_{i}.dcm",
                features=features,
                feature_dimensions=(5,),
                metadata={"index": i},
                extraction_timestamp=datetime.now(),
                processing_time=1.0,
                success=True
            )
            records.append(record)
        
        self.dataset = FeatureDataset(records)
        self.config = OutputConfig(
            format=OutputFormat.JSON,
            output_path=self.temp_dir,
            filename_prefix="test_features"
        )
    
    def tearDown(self):
        """测试清理"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_get_file_extension(self):
        """测试文件扩展名"""
        self.assertEqual(self.writer.get_file_extension(), ".json")
    
    def test_write_json(self):
        """测试JSON写入"""
        result = self.writer.write(self.dataset, self.config)
        
        self.assertTrue(result.success)
        self.assertEqual(len(result.output_files), 1)
        
        # 验证文件存在
        output_file = result.output_files[0]
        self.assertTrue(os.path.exists(output_file))
        
        # 验证JSON内容
        import json
        with open(output_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        self.assertIsInstance(data, dict)
        self.assertIn('records', data)
        self.assertIn('metadata', data)
        self.assertEqual(len(data['records']), 2)
        
        # 检查记录结构
        for record in data['records']:
            self.assertIn('file_path', record)
            self.assertIn('features', record)
            self.assertEqual(len(record['features']), 5)
    
    def test_validate_output(self):
        """测试JSON输出验证"""
        result = self.writer.write(self.dataset, self.config)
        is_valid = self.writer.validate_output(result.output_files, self.dataset)
        self.assertTrue(is_valid)


class TestFeatureOutputManager(unittest.TestCase):
    """测试特征输出管理器"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.temp_dir = tempfile.mkdtemp()
        self.output_manager = FeatureOutputManager()
        
        # 创建测试数据集
        records = []
        for i in range(3):
            features = np.random.randn(50)
            record = FeatureRecord(
                file_path=f"test_{i}.dcm",
                features=features,
                feature_dimensions=(50,),
                metadata={"index": i},
                extraction_timestamp=datetime.now(),
                processing_time=1.0,
                success=True
            )
            records.append(record)
        
        self.dataset = FeatureDataset(records)
    
    def tearDown(self):
        """测试清理"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_save_features_numpy(self):
        """测试保存NumPy格式特征"""
        config = OutputConfig(
            format=OutputFormat.NUMPY,
            output_path=self.temp_dir,
            filename_prefix="test_features"
        )
        
        result = self.output_manager.save_features(self.dataset, config)
        
        self.assertTrue(result.success)
        self.assertEqual(result.successful_records, 3)
        self.assertGreater(result.output_size_bytes, 0)
    
    def test_save_features_multi_format(self):
        """测试多格式保存"""
        configs = [
            OutputConfig(
                format=OutputFormat.NUMPY,
                output_path=self.temp_dir,
                filename_prefix="numpy_features"
            ),
            OutputConfig(
                format=OutputFormat.JSON,
                output_path=self.temp_dir,
                filename_prefix="json_features"
            )
        ]
        
        results = self.output_manager.save_features_multi_format(self.dataset, configs)
        
        self.assertEqual(len(results), 2)
        self.assertIn('numpy', results)
        self.assertIn('json', results)
        
        for format_name, result in results.items():
            self.assertTrue(result.success, f"Format {format_name} failed")
    
    def test_estimate_output_size(self):
        """测试输出大小估算"""
        config = OutputConfig(
            format=OutputFormat.NUMPY,
            output_path=self.temp_dir,
            filename_prefix="test_features"
        )
        
        estimated_size = self.output_manager.estimate_output_size(self.dataset, config)
        self.assertGreater(estimated_size, 0)
    
    def test_get_supported_formats(self):
        """测试获取支持的格式"""
        formats = self.output_manager.get_supported_formats()
        self.assertIsInstance(formats, list)
        self.assertGreater(len(formats), 0)
    
    def test_create_metadata_file(self):
        """测试创建元数据文件"""
        metadata_file = self.output_manager.create_metadata_file(
            self.dataset, self.temp_dir, include_statistics=True
        )
        
        self.assertTrue(os.path.exists(metadata_file))
        
        # 验证元数据内容
        import json
        with open(metadata_file, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
        
        self.assertIn('dataset_info', metadata)
        self.assertIn('feature_statistics', metadata)
        self.assertEqual(metadata['total_records'], 3)
        self.assertEqual(metadata['successful_records'], 3)


class TestUtilityFunctions(unittest.TestCase):
    """测试实用工具函数"""
    
    def setUp(self):
        """测试设置"""
        # 创建测试数据集
        records = []
        for i in range(5):
            features = np.random.randn(100)
            record = FeatureRecord(
                file_path=f"test_{i}.dcm",
                features=features,
                feature_dimensions=(100,),
                metadata={"index": i},
                extraction_timestamp=datetime.now(),
                processing_time=1.0,
                success=True
            )
            records.append(record)
        
        self.dataset = FeatureDataset(records)
    
    def test_estimate_memory_usage(self):
        """测试内存使用估算"""
        memory_usage = estimate_memory_usage(
            self.dataset, 
            OutputFormat.NUMPY, 
            CompressionType.NONE
        )
        
        self.assertGreater(memory_usage, 0)
        self.assertIsInstance(memory_usage, float)
    
    def test_calculate_optimal_chunk_size(self):
        """测试最优分块大小计算"""
        chunk_size = calculate_optimal_chunk_size(
            self.dataset,
            available_memory_mb=100.0,
            output_format=OutputFormat.NUMPY,
            safety_factor=0.7
        )
        
        self.assertGreater(chunk_size, 0)
        self.assertLessEqual(chunk_size, len(self.dataset.records))


if __name__ == '__main__':
    # 创建测试套件
    test_classes = [
        TestFeatureRecord,
        TestFeatureDataset,
        TestOutputConfig,
        TestOutputWriterFactory,
        TestNumpyFeatureWriter,
        TestCSVFeatureWriter,
        TestJSONFeatureWriter,
        TestFeatureOutputManager,
        TestUtilityFunctions
    ]
    
    loader = unittest.TestLoader()
    suites = [loader.loadTestsFromTestCase(test_class) for test_class in test_classes]
    combined_suite = unittest.TestSuite(suites)
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(combined_suite)
    
    # 输出结果
    if result.wasSuccessful():
        print(f"\nAll output system tests passed ({result.testsRun} tests)")
    else:
        print(f"\nOutput system tests failed: {len(result.failures)} failures, {len(result.errors)} errors")
        
        for failure in result.failures:
            print(f"\nFailure: {failure[0]}")
            print(failure[1])
        
        for error in result.errors:
            print(f"\nError: {error[0]}")
            print(error[1])