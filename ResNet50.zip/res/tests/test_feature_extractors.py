# -*- coding: utf-8 -*-
"""
Feature extractor unit tests

Test ResNet50 feature extraction functionality to ensure correct implementation.
"""

import unittest
import tempfile
import shutil
from pathlib import Path
import numpy as np
import torch
from unittest.mock import Mock, patch

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models.feature_extractors import (
    ResNet50FeatureExtractor, MultiLayerFeatureExtractor, FeatureExtractorFactory
)
from src.core.exceptions import FeatureExtractionError, ModelError
from src.core.logger import log_manager


class TestResNet50FeatureExtractor(unittest.TestCase):
    """Test ResNet50 feature extractor"""
    
    def setUp(self):
        """Test setup"""
        # Configure logging
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        # Use CPU for testing to avoid GPU dependency
        self.device = 'cpu'
        self.extractor = ResNet50FeatureExtractor(device=self.device)
        
        # Create test tensors
        self.single_image = torch.randn(3, 224, 224)
        self.batch_images = torch.randn(4, 3, 224, 224)
        self.small_batch = torch.randn(2, 3, 224, 224)
    
    def test_initialization(self):
        """Test feature extractor initialization"""
        self.assertIsNotNone(self.extractor.model)
        self.assertIsNotNone(self.extractor.feature_extractor)
        self.assertEqual(self.extractor.target_layer, 'layer4.2.conv3')
        self.assertEqual(self.extractor.device.type, 'cpu')
    
    def test_device_setup(self):
        """Test device setup functionality"""
        # Test CPU device
        cpu_extractor = ResNet50FeatureExtractor(device='cpu')
        self.assertEqual(cpu_extractor.device.type, 'cpu')
        
        # Test auto device selection
        auto_extractor = ResNet50FeatureExtractor(device='auto')
        self.assertIn(auto_extractor.device.type, ['cpu', 'cuda'])
    
    def test_get_feature_dimensions(self):
        """Test feature dimensions retrieval"""
        dimensions = self.extractor.get_feature_dimensions()
        
        # ResNet50 conv5_block3_out should produce 2048-dimensional features
        self.assertEqual(dimensions, (2048,))
    
    def test_get_layer_name(self):
        """Test layer name retrieval"""
        layer_name = self.extractor.get_layer_name()
        self.assertEqual(layer_name, 'layer4.2.conv3')
    
    def test_extract_features_single_image(self):
        """Test single image feature extraction"""
        features = self.extractor.extract_features_from_single_image(self.single_image)
        
        # Check feature properties
        self.assertIsInstance(features, torch.Tensor)
        self.assertEqual(features.shape, (2048,))
        self.assertEqual(features.dtype, torch.float32)
    
    def test_extract_features_batch(self):
        """Test batch feature extraction"""
        features = self.extractor.extract_features(self.batch_images)
        
        # Check feature properties
        self.assertIsInstance(features, torch.Tensor)
        self.assertEqual(features.shape, (4, 2048))
        self.assertEqual(features.dtype, torch.float32)
    
    def test_extract_features_different_batch_sizes(self):
        """Test feature extraction with different batch sizes"""
        # Test with single image batch
        single_batch = self.single_image.unsqueeze(0)
        features_single = self.extractor.extract_features(single_batch)
        self.assertEqual(features_single.shape, (1, 2048))
        
        # Test with small batch
        features_small = self.extractor.extract_features(self.small_batch)
        self.assertEqual(features_small.shape, (2, 2048))
    
    def test_layer_mapping(self):
        """Test layer name mapping functionality"""
        # Test with common layer name
        extractor_mapped = ResNet50FeatureExtractor(
            target_layer='conv5_block3_out',
            device=self.device
        )
        
        # Should map to actual layer name
        self.assertEqual(extractor_mapped.target_layer, 'conv5_block3_out')
        
        # Should still work for feature extraction
        features = extractor_mapped.extract_features(self.small_batch)
        self.assertEqual(features.shape, (2, 2048))
    
    def test_invalid_input_shapes(self):
        """Test error handling for invalid input shapes"""
        # Test 3D tensor (missing batch dimension in extract_features)
        with self.assertRaises(FeatureExtractionError):
            self.extractor.extract_features(self.single_image)
        
        # Test wrong number of channels
        wrong_channels = torch.randn(2, 1, 224, 224)  # Only 1 channel
        with self.assertRaises(FeatureExtractionError):
            self.extractor.extract_features(wrong_channels)
        
        # Test wrong number of dimensions
        wrong_dims = torch.randn(2, 3, 224)  # Missing height dimension
        with self.assertRaises(FeatureExtractionError):
            self.extractor.extract_features(wrong_dims)
    
    def test_invalid_layer_name(self):
        """Test error handling for invalid layer names"""
        with self.assertRaises(FeatureExtractionError):
            ResNet50FeatureExtractor(
                target_layer='nonexistent_layer',
                device=self.device
            )
    
    def test_get_available_layers(self):
        """Test getting available layers"""
        layers = self.extractor.get_available_layers()
        
        self.assertIsInstance(layers, list)
        self.assertGreater(len(layers), 0)
        self.assertIn('layer4.2.conv3', layers)
    
    def test_statistics_tracking(self):
        """Test statistics tracking"""
        # Reset statistics
        self.extractor.reset_statistics()
        
        initial_stats = self.extractor.get_statistics()
        self.assertEqual(initial_stats['total_extractions'], 0)
        self.assertEqual(initial_stats['successful_extractions'], 0)
        
        # Perform feature extraction
        self.extractor.extract_features(self.small_batch)
        
        # Check updated statistics
        updated_stats = self.extractor.get_statistics()
        self.assertEqual(updated_stats['total_extractions'], 2)
        self.assertEqual(updated_stats['successful_extractions'], 2)
        self.assertGreater(updated_stats['total_processing_time'], 0)
    
    def test_memory_usage_tracking(self):
        """Test memory usage tracking"""
        memory_info = self.extractor.get_memory_usage()
        
        self.assertIsInstance(memory_info, dict)
        self.assertIn('model_parameters_mb', memory_info)
        self.assertGreater(memory_info['model_parameters_mb'], 0)
    
    def test_different_target_layers(self):
        """Test feature extraction from different layers"""
        # Test layer4.2.relu (a valid layer in ResNet50)
        layer4_extractor = ResNet50FeatureExtractor(
            target_layer='layer4.2.relu',
            device=self.device
        )
        
        features_layer4 = layer4_extractor.extract_features(self.small_batch)
        
        # Layer4.2.relu output should be 4D, then pooled - has different dimension than final conv
        self.assertEqual(features_layer4.shape[0], 2)  # Batch size
        # The exact dimension depends on the layer - layer4.2.relu has different dim than layer4.2.conv3
        self.assertGreater(features_layer4.shape[1], 0)  # Should have some features
    
    def test_feature_consistency(self):
        """Test that same input produces same features"""
        # Extract features twice from same input
        features1 = self.extractor.extract_features(self.small_batch)
        features2 = self.extractor.extract_features(self.small_batch)
        
        # Should be identical (model is in eval mode)
        torch.testing.assert_close(features1, features2, atol=1e-6, rtol=1e-6)
    
    def test_optimization_methods(self):
        """Test inference optimization methods"""
        # Test optimization (should not raise errors)
        try:
            self.extractor.optimize_for_inference()
        except Exception as e:
            self.fail(f"Optimization failed: {e}")
        
        # Test cache clearing (should not raise errors)
        try:
            self.extractor.clear_cache()
        except Exception as e:
            self.fail(f"Cache clearing failed: {e}")


class TestMultiLayerFeatureExtractor(unittest.TestCase):
    """Test multi-layer feature extractor"""
    
    def setUp(self):
        """Test setup"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.device = 'cpu'
        self.target_layers = ['layer3.5.relu', 'layer4.2.conv3']
        self.extractor = MultiLayerFeatureExtractor(
            target_layers=self.target_layers,
            device=self.device
        )
        
        self.test_batch = torch.randn(2, 3, 224, 224)
    
    def test_initialization(self):
        """Test multi-layer extractor initialization"""
        self.assertIsNotNone(self.extractor.model)
        self.assertIsNotNone(self.extractor.feature_extractor)
        self.assertEqual(self.extractor.target_layers, self.target_layers)
    
    def test_extract_features_multiple_layers(self):
        """Test multi-layer feature extraction"""
        features_dict = self.extractor.extract_features(self.test_batch)
        
        # Should return dictionary with features from each layer
        self.assertIsInstance(features_dict, dict)
        self.assertEqual(len(features_dict), 2)  # Two target layers
        
        # Check each feature tensor
        for key, features in features_dict.items():
            self.assertIsInstance(features, torch.Tensor)
            self.assertEqual(features.shape[0], 2)  # Batch size
            self.assertEqual(len(features.shape), 2)  # Should be 2D after pooling
    
    def test_get_feature_dimensions_multilayer(self):
        """Test getting feature dimensions for multiple layers"""
        dimensions_dict = self.extractor.get_feature_dimensions()
        
        self.assertIsInstance(dimensions_dict, dict)
        self.assertEqual(len(dimensions_dict), 2)
        
        # Each layer should have its own dimensions
        for key, dims in dimensions_dict.items():
            self.assertIsInstance(dims, tuple)
            self.assertGreater(len(dims), 0)


class TestFeatureExtractorFactory(unittest.TestCase):
    """Test feature extractor factory"""
    
    def test_create_resnet50_extractor(self):
        """Test ResNet50 extractor creation"""
        extractor = FeatureExtractorFactory.create_resnet50_extractor(device='cpu')
        
        self.assertIsInstance(extractor, ResNet50FeatureExtractor)
        self.assertEqual(extractor.device.type, 'cpu')
    
    def test_create_multilayer_extractor(self):
        """Test multi-layer extractor creation"""
        layers = ['layer3.5.relu', 'layer4.2.conv3']
        extractor = FeatureExtractorFactory.create_multilayer_extractor(
            target_layers=layers,
            device='cpu'
        )
        
        self.assertIsInstance(extractor, MultiLayerFeatureExtractor)
        self.assertEqual(extractor.target_layers, layers)
    
    def test_create_from_config(self):
        """Test extractor creation from configuration"""
        # Test ResNet50 config
        resnet_config = {
            'type': 'resnet50',
            'target_layer': 'layer4.2.conv3',
            'device': 'cpu',
            'pretrained': True
        }
        
        extractor = FeatureExtractorFactory.create_from_config(resnet_config)
        self.assertIsInstance(extractor, ResNet50FeatureExtractor)
        
        # Test multi-layer config
        multilayer_config = {
            'type': 'multilayer',
            'target_layers': ['layer3.5.relu', 'layer4.2.conv3'],
            'device': 'cpu'
        }
        
        extractor = FeatureExtractorFactory.create_from_config(multilayer_config)
        self.assertIsInstance(extractor, MultiLayerFeatureExtractor)
        
        # Test unknown type
        unknown_config = {'type': 'unknown'}
        with self.assertRaises(FeatureExtractionError):
            FeatureExtractorFactory.create_from_config(unknown_config)


class TestFeatureExtractorIntegration(unittest.TestCase):
    """Integration tests for feature extractors"""
    
    def setUp(self):
        """Test setup"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.device = 'cpu'
    
    def test_feature_extraction_pipeline(self):
        """Test complete feature extraction pipeline"""
        # Create extractor
        extractor = FeatureExtractorFactory.create_resnet50_extractor(device=self.device)
        
        # Reset statistics before test
        extractor.reset_statistics()
        
        # Create realistic test data (simulating preprocessed DICOM images)
        batch_size = 3
        test_batch = torch.randn(batch_size, 3, 224, 224)
        
        # Extract features
        features = extractor.extract_features(test_batch)
        
        # Verify results
        self.assertEqual(features.shape, (batch_size, 2048))
        self.assertFalse(torch.isnan(features).any())
        self.assertFalse(torch.isinf(features).any())
        
        # Test statistics
        stats = extractor.get_statistics()
        self.assertEqual(stats['total_extractions'], batch_size)
        self.assertEqual(stats['successful_extractions'], batch_size)
    
    def test_different_image_sizes(self):
        """Test feature extraction with different input sizes"""
        extractor = FeatureExtractorFactory.create_resnet50_extractor(device=self.device)
        
        # Test different input sizes (all should work due to adaptive pooling in ResNet)
        sizes = [(224, 224), (256, 256), (299, 299)]
        
        for height, width in sizes:
            test_input = torch.randn(1, 3, height, width)
            features = extractor.extract_features(test_input)
            
            # All should produce same feature dimension
            self.assertEqual(features.shape, (1, 2048))
    
    def test_batch_processing_efficiency(self):
        """Test batch processing efficiency"""
        extractor = FeatureExtractorFactory.create_resnet50_extractor(device=self.device)
        
        # Single image processing
        single_image = torch.randn(1, 3, 224, 224)
        
        import time
        
        # Time single image processing (multiple times)
        start_time = time.time()
        for _ in range(4):
            _ = extractor.extract_features(single_image)
        single_time = time.time() - start_time
        
        # Time batch processing
        batch_images = torch.randn(4, 3, 224, 224)
        start_time = time.time()
        _ = extractor.extract_features(batch_images)
        batch_time = time.time() - start_time
        
        # Batch processing should be more efficient (though this might not always hold on CPU)
        # At minimum, batch processing should not be significantly slower
        self.assertLess(batch_time, single_time * 2)  # Should be at least 2x more efficient
    
    @unittest.skipIf(not torch.cuda.is_available(), "CUDA not available")
    def test_gpu_processing(self):
        """Test GPU processing if available"""
        extractor = FeatureExtractorFactory.create_resnet50_extractor(device='cuda')
        
        test_batch = torch.randn(2, 3, 224, 224)
        features = extractor.extract_features(test_batch)
        
        # Features should be moved back to CPU
        self.assertEqual(features.device.type, 'cpu')
        self.assertEqual(features.shape, (2, 2048))
        
        # Check GPU memory usage
        memory_info = extractor.get_memory_usage()
        self.assertIn('gpu_memory_allocated_mb', memory_info)


if __name__ == '__main__':
    # Create test suite
    test_classes = [
        TestResNet50FeatureExtractor,
        TestMultiLayerFeatureExtractor,
        TestFeatureExtractorFactory,
        TestFeatureExtractorIntegration
    ]
    
    loader = unittest.TestLoader()
    suites = [loader.loadTestsFromTestCase(test_class) for test_class in test_classes]
    combined_suite = unittest.TestSuite(suites)
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(combined_suite)
    
    # Output results
    if result.wasSuccessful():
        print(f"\nAll tests passed ({result.testsRun} tests)")
    else:
        print(f"\nTests failed: {len(result.failures)} failures, {len(result.errors)} errors")
        
        for failure in result.failures:
            print(f"\nFailure: {failure[0]}")
            print(failure[1])
        
        for error in result.errors:
            print(f"\nError: {error[0]}")
            print(error[1])