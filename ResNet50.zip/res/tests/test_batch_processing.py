# -*- coding: utf-8 -*-
"""
Batch processing system unit tests

Test batch management, memory monitoring, and optimization functionality.
"""

import unittest
import tempfile
import shutil
import time
import threading
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import torch
import numpy as np

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.processing.batch_manager import (
    BatchManager, BatchConfig, MemoryMonitor, BatchSizeOptimizer,
    ProgressTracker, DICOMFeatureExtractionStrategy, MemoryStats, ProcessingProgress
)
from src.processing.batch_factory import BatchProcessingFactory, BatchProcessingUtils, PerformanceBenchmark
from src.core.exceptions import BatchProcessingError, MemoryError
from src.core.logger import log_manager


class TestBatchConfig(unittest.TestCase):
    """测试批处理配置"""
    
    def test_default_config(self):
        """测试默认配置"""
        config = BatchConfig()
        
        self.assertEqual(config.initial_batch_size, 8)
        self.assertEqual(config.min_batch_size, 1)
        self.assertEqual(config.max_batch_size, 32)
        self.assertEqual(config.memory_threshold, 0.85)
        self.assertTrue(config.auto_optimize)
        self.assertIsNone(config.progress_callback)
    
    def test_custom_config(self):
        """测试自定义配置"""
        callback = lambda x: None
        config = BatchConfig(
            initial_batch_size=16,
            min_batch_size=2,
            max_batch_size=64,
            memory_threshold=0.9,
            auto_optimize=False,
            progress_callback=callback
        )
        
        self.assertEqual(config.initial_batch_size, 16)
        self.assertEqual(config.min_batch_size, 2)
        self.assertEqual(config.max_batch_size, 64)
        self.assertEqual(config.memory_threshold, 0.9)
        self.assertFalse(config.auto_optimize)
        self.assertEqual(config.progress_callback, callback)


class TestMemoryStats(unittest.TestCase):
    """测试内存统计数据结构"""
    
    def test_memory_stats_creation(self):
        """测试内存统计创建"""
        stats = MemoryStats(
            cpu_memory_used_mb=1000.0,
            cpu_memory_total_mb=8000.0,
            cpu_memory_percent=12.5,
            gpu_memory_used_mb=500.0,
            gpu_memory_total_mb=2000.0,
            gpu_memory_percent=25.0,
            timestamp=time.time()
        )
        
        self.assertEqual(stats.cpu_memory_used_mb, 1000.0)
        self.assertEqual(stats.cpu_memory_total_mb, 8000.0)
        self.assertEqual(stats.cpu_memory_percent, 12.5)
        self.assertEqual(stats.gpu_memory_used_mb, 500.0)
        self.assertEqual(stats.gpu_memory_total_mb, 2000.0)
        self.assertEqual(stats.gpu_memory_percent, 25.0)


class TestMemoryMonitor(unittest.TestCase):
    """测试内存监控器"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.monitor = MemoryMonitor(update_interval=0.1)
    
    def tearDown(self):
        """测试清理"""
        if self.monitor._monitoring:
            self.monitor.stop_monitoring()
    
    def test_memory_monitor_initialization(self):
        """测试内存监控器初始化"""
        self.assertIsNotNone(self.monitor)
        self.assertEqual(self.monitor.update_interval, 0.1)
        self.assertFalse(self.monitor._monitoring)
    
    def test_get_current_stats(self):
        """测试获取当前内存统计"""
        stats = self.monitor.get_current_stats()
        
        self.assertIsInstance(stats, MemoryStats)
        self.assertGreater(stats.cpu_memory_total_mb, 0)
        self.assertGreaterEqual(stats.cpu_memory_percent, 0)
        self.assertLessEqual(stats.cpu_memory_percent, 100)
    
    def test_start_stop_monitoring(self):
        """测试开始和停止监控"""
        # 开始监控
        self.monitor.start_monitoring()
        self.assertTrue(self.monitor._monitoring)
        self.assertIsNotNone(self.monitor._monitor_thread)
        
        # 等待一点时间让监控运行
        time.sleep(0.2)
        
        # 停止监控
        self.monitor.stop_monitoring()
        self.assertFalse(self.monitor._monitoring)
    
    def test_stats_history(self):
        """测试统计历史记录"""
        self.monitor.start_monitoring()
        time.sleep(0.3)  # 让监控器收集一些数据
        
        history = self.monitor.get_stats_history()
        self.assertIsInstance(history, list)
        # 可能有数据，也可能没有，取决于运行时间
        
        self.monitor.stop_monitoring()


class TestBatchSizeOptimizer(unittest.TestCase):
    """测试批处理大小优化器"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.memory_monitor = MemoryMonitor()
        self.optimizer = BatchSizeOptimizer(
            self.memory_monitor,
            initial_batch_size=8,
            min_batch_size=1,
            max_batch_size=32,
            memory_threshold=0.85
        )
    
    def test_optimizer_initialization(self):
        """测试优化器初始化"""
        self.assertEqual(self.optimizer.current_batch_size, 8)
        self.assertEqual(self.optimizer.min_batch_size, 1)
        self.assertEqual(self.optimizer.max_batch_size, 32)
        self.assertEqual(self.optimizer.memory_threshold, 0.85)
    
    def test_get_optimal_batch_size_normal_memory(self):
        """测试正常内存情况下的最优批处理大小"""
        # Mock低内存使用情况
        mock_stats = MemoryStats(
            cpu_memory_used_mb=1000.0,
            cpu_memory_total_mb=8000.0,
            cpu_memory_percent=50.0,  # 50% usage - low
            gpu_memory_used_mb=500.0,
            gpu_memory_total_mb=2000.0,
            gpu_memory_percent=25.0,  # 25% usage - low
            timestamp=time.time()
        )
        
        with patch.object(self.memory_monitor, 'get_current_stats', return_value=mock_stats):
            optimal_size = self.optimizer.get_optimal_batch_size()
            
            # 在低内存使用情况下，应该尝试增加批处理大小
            self.assertGreaterEqual(optimal_size, self.optimizer.min_batch_size)
            self.assertLessEqual(optimal_size, self.optimizer.max_batch_size)
    
    def test_get_optimal_batch_size_high_memory(self):
        """测试高内存使用情况下的最优批处理大小"""
        # Mock高内存使用情况
        mock_stats = MemoryStats(
            cpu_memory_used_mb=7000.0,
            cpu_memory_total_mb=8000.0,
            cpu_memory_percent=87.5,  # High usage
            gpu_memory_used_mb=1800.0,
            gpu_memory_total_mb=2000.0,
            gpu_memory_percent=90.0,  # Very high usage
            timestamp=time.time()
        )
        
        with patch.object(self.memory_monitor, 'get_current_stats', return_value=mock_stats):
            original_batch_size = self.optimizer.current_batch_size
            optimal_size = self.optimizer.get_optimal_batch_size()
            
            # 在高内存使用情况下，应该减少批处理大小
            self.assertLessEqual(optimal_size, original_batch_size)
            self.assertGreaterEqual(optimal_size, self.optimizer.min_batch_size)
    
    def test_record_batch_performance(self):
        """测试批处理性能记录"""
        self.optimizer.record_batch_performance(8, 2.5, 1200.0)
        self.optimizer.record_batch_performance(16, 4.0, 2000.0)
        
        self.assertEqual(len(self.optimizer.batch_performance), 2)
        self.assertEqual(self.optimizer.batch_performance[0], (8, 2.5, 1200.0))
        self.assertEqual(self.optimizer.batch_performance[1], (16, 4.0, 2000.0))


class TestProgressTracker(unittest.TestCase):
    """测试进度追踪器"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.tracker = ProgressTracker(total_items=100)
    
    def test_tracker_initialization(self):
        """测试追踪器初始化"""
        self.assertEqual(self.tracker.total_items, 100)
        self.assertEqual(self.tracker.processed_items, 0)
        self.assertEqual(self.tracker.failed_items, 0)
        self.assertGreater(self.tracker.start_time, 0)
    
    def test_update_progress(self):
        """测试更新进度"""
        self.tracker.update_progress(10, 2, 8)
        
        self.assertEqual(self.tracker.processed_items, 10)
        self.assertEqual(self.tracker.failed_items, 2)
    
    def test_get_progress_info(self):
        """测试获取进度信息"""
        # 模拟一些处理时间
        time.sleep(0.1)
        self.tracker.update_progress(20, 1, 8)
        
        mock_memory_stats = MemoryStats(
            cpu_memory_used_mb=1000.0,
            cpu_memory_total_mb=8000.0,
            cpu_memory_percent=12.5,
            timestamp=time.time()
        )
        
        progress_info = self.tracker.get_progress_info(mock_memory_stats, 8)
        
        self.assertIsInstance(progress_info, ProcessingProgress)
        self.assertEqual(progress_info.total_items, 100)
        self.assertEqual(progress_info.processed_items, 20)
        self.assertEqual(progress_info.failed_items, 1)
        self.assertEqual(progress_info.current_batch_size, 8)
        self.assertGreater(progress_info.processing_rate, 0)


class TestBatchManager(unittest.TestCase):
    """测试批处理管理器"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.config = BatchConfig(
            initial_batch_size=4,
            min_batch_size=1,
            max_batch_size=16,
            auto_optimize=False  # 禁用自动优化以便测试
        )
        self.batch_manager = BatchManager(self.config)
        
        # 创建模拟的处理策略
        self.mock_strategy = Mock()
        self.mock_strategy.process_batch.return_value = ["result1", "result2", "result3"]
        self.mock_strategy.estimate_memory_usage.return_value = 100.0
    
    def tearDown(self):
        """测试清理"""
        if self.batch_manager.is_processing:
            self.batch_manager.end_processing_session()
    
    def test_batch_manager_initialization(self):
        """测试批处理管理器初始化"""
        self.assertIsNotNone(self.batch_manager.memory_monitor)
        self.assertIsNotNone(self.batch_manager.batch_optimizer)
        self.assertFalse(self.batch_manager.is_processing)
    
    def test_start_end_processing_session(self):
        """测试开始和结束处理会话"""
        # 开始会话
        self.batch_manager.start_processing_session(50)
        self.assertTrue(self.batch_manager.is_processing)
        self.assertIsNotNone(self.batch_manager.progress_tracker)
        
        # 结束会话
        self.batch_manager.end_processing_session()
        self.assertFalse(self.batch_manager.is_processing)
    
    def test_process_batch(self):
        """测试批次处理"""
        self.batch_manager.start_processing_session(10)
        
        test_items = ["item1", "item2", "item3"]
        results = self.batch_manager.process_batch(test_items, self.mock_strategy)
        
        self.assertEqual(results, ["result1", "result2", "result3"])
        self.mock_strategy.process_batch.assert_called_once_with(test_items)
        
        self.batch_manager.end_processing_session()
    
    def test_process_batch_without_session(self):
        """测试未开始会话时的批次处理"""
        test_items = ["item1", "item2", "item3"]
        
        with self.assertRaises(BatchProcessingError):
            self.batch_manager.process_batch(test_items, self.mock_strategy)
    
    def test_get_current_stats(self):
        """测试获取当前统计信息"""
        self.batch_manager.start_processing_session(20)
        
        # 处理一些项目
        test_items = ["item1", "item2"]
        self.batch_manager.process_batch(test_items, self.mock_strategy)
        
        stats = self.batch_manager.get_current_stats()
        
        self.assertIsInstance(stats, dict)
        self.assertIn('progress', stats)
        self.assertIn('batch_optimization', stats)
        self.assertIn('memory', stats)
        
        self.batch_manager.end_processing_session()


class TestDICOMFeatureExtractionStrategy(unittest.TestCase):
    """测试DICOM特征提取策略"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        # 创建模拟组件
        self.mock_loader = Mock()
        self.mock_preprocessor = Mock()
        self.mock_extractor = Mock()
        
        # 设置模拟行为
        mock_dicom_image = Mock()
        mock_dicom_image.file_path = "test.dcm"
        mock_dicom_image.original_shape = (512, 512, 1)
        mock_dicom_image.patient_id = "test_patient"
        
        self.mock_loader.load_dicom_file.return_value = mock_dicom_image
        
        mock_tensor = torch.randn(3, 224, 224)
        self.mock_preprocessor.preprocess_image.return_value = mock_tensor
        
        mock_features = torch.randn(2048)
        self.mock_extractor.extract_features.return_value = torch.stack([mock_features])
        
        self.strategy = DICOMFeatureExtractionStrategy(
            self.mock_loader, self.mock_preprocessor, self.mock_extractor
        )
    
    def test_strategy_initialization(self):
        """测试策略初始化"""
        self.assertEqual(self.strategy.dicom_loader, self.mock_loader)
        self.assertEqual(self.strategy.preprocessor, self.mock_preprocessor)
        self.assertEqual(self.strategy.feature_extractor, self.mock_extractor)
    
    def test_process_batch(self):
        """测试批次处理"""
        test_files = ["test1.dcm"]
        results = self.strategy.process_batch(test_files)
        
        self.assertEqual(len(results), 1)
        result = results[0]
        
        self.assertIn('file_path', result)
        self.assertIn('features', result)
        self.assertIn('feature_shape', result)
        self.assertIn('metadata', result)
        
        self.assertEqual(result['file_path'], "test.dcm")
        self.assertIsInstance(result['features'], np.ndarray)
    
    def test_estimate_memory_usage(self):
        """测试内存使用估算"""
        memory_usage = self.strategy.estimate_memory_usage(8)
        
        self.assertIsInstance(memory_usage, float)
        self.assertGreater(memory_usage, 0)
    
    def test_process_batch_with_errors(self):
        """测试带错误的批次处理"""
        # 设置加载器抛出异常
        self.mock_loader.load_dicom_file.side_effect = Exception("Load error")
        
        test_files = ["error.dcm"]
        results = self.strategy.process_batch(test_files)
        
        # 应该返回空结果列表
        self.assertEqual(len(results), 0)


class TestBatchProcessingFactory(unittest.TestCase):
    """测试批处理工厂"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
    
    def test_create_batch_manager(self):
        """测试创建批处理管理器"""
        manager = BatchProcessingFactory.create_batch_manager()
        
        self.assertIsInstance(manager, BatchManager)
    
    def test_create_batch_manager_with_config(self):
        """测试使用配置创建批处理管理器"""
        config = {
            'initial_batch_size': 16,
            'min_batch_size': 2,
            'max_batch_size': 64,
            'memory_threshold': 0.9,
            'auto_optimize': False
        }
        
        manager = BatchProcessingFactory.create_batch_manager(config)
        
        self.assertIsInstance(manager, BatchManager)
        self.assertEqual(manager.config.initial_batch_size, 16)
    
    def test_create_memory_monitor(self):
        """测试创建内存监控器"""
        monitor = BatchProcessingFactory.create_memory_monitor(update_interval=0.5)
        
        self.assertIsInstance(monitor, MemoryMonitor)
        self.assertEqual(monitor.update_interval, 0.5)
    
    def test_get_default_batch_config(self):
        """测试获取默认批处理配置"""
        config = BatchProcessingFactory.get_default_batch_config()
        
        self.assertIsInstance(config, dict)
        self.assertIn('initial_batch_size', config)
        self.assertIn('min_batch_size', config)
        self.assertIn('max_batch_size', config)
        self.assertIn('memory_threshold', config)
        self.assertIn('auto_optimize', config)
    
    def test_validate_batch_config_valid(self):
        """测试验证有效配置"""
        config = {
            'initial_batch_size': 8,
            'min_batch_size': 1,
            'max_batch_size': 32,
            'memory_threshold': 0.85,
            'auto_optimize': True
        }
        
        is_valid, errors = BatchProcessingFactory.validate_batch_config(config)
        
        self.assertTrue(is_valid)
        self.assertEqual(len(errors), 0)
    
    def test_validate_batch_config_invalid(self):
        """测试验证无效配置"""
        config = {
            'initial_batch_size': 100,  # Greater than max
            'min_batch_size': 10,
            'max_batch_size': 32,
            'memory_threshold': 1.5,  # Invalid threshold
            'auto_optimize': True
        }
        
        is_valid, errors = BatchProcessingFactory.validate_batch_config(config)
        
        self.assertFalse(is_valid)
        self.assertGreater(len(errors), 0)


class TestBatchProcessingUtils(unittest.TestCase):
    """测试批处理实用工具"""
    
    def test_estimate_optimal_batch_size(self):
        """测试估算最优批处理大小"""
        # 测试正常情况
        batch_size = BatchProcessingUtils.estimate_optimal_batch_size(
            available_memory_mb=1000.0,
            single_item_memory_mb=50.0,
            safety_factor=0.8
        )
        
        # 1000 * 0.8 / 50 = 16
        self.assertEqual(batch_size, 16)
        
        # 测试边界情况
        batch_size = BatchProcessingUtils.estimate_optimal_batch_size(
            available_memory_mb=100.0,
            single_item_memory_mb=0.0,  # 无效值
            safety_factor=0.8
        )
        
        self.assertEqual(batch_size, 1)  # 应该返回最小值
    
    def test_calculate_processing_efficiency(self):
        """测试计算处理效率"""
        efficiency = BatchProcessingUtils.calculate_processing_efficiency(
            total_items=100,
            processing_time=10.0,
            memory_usage_mb=1000.0
        )
        
        self.assertIsInstance(efficiency, dict)
        self.assertIn('items_per_second', efficiency)
        self.assertIn('seconds_per_item', efficiency)
        self.assertIn('memory_per_item_mb', efficiency)
        self.assertIn('efficiency_score', efficiency)
        
        self.assertEqual(efficiency['items_per_second'], 10.0)
        self.assertEqual(efficiency['seconds_per_item'], 0.1)
        self.assertEqual(efficiency['memory_per_item_mb'], 10.0)
    
    def test_create_progress_callback(self):
        """测试创建进度回调"""
        callback = BatchProcessingUtils.create_progress_callback(
            print_interval=5,
            detailed_stats=True
        )
        
        self.assertIsNotNone(callback)
        self.assertTrue(callable(callback))


class TestPerformanceBenchmark(unittest.TestCase):
    """测试性能基准测试"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.benchmark = PerformanceBenchmark()
    
    def test_benchmark_initialization(self):
        """测试基准测试初始化"""
        self.assertIsNotNone(self.benchmark)
        self.assertEqual(len(self.benchmark.benchmark_results), 0)
    
    def test_generate_benchmark_report(self):
        """测试生成基准测试报告"""
        # 模拟基准测试结果
        results = {
            'optimal_batch_size': 8,
            'best_performance_score': 15.5,
            'batch_size_results': [
                {
                    'batch_size': 4,
                    'throughput_items_per_sec': 8.5,
                    'memory_usage_mb': 500.0,
                    'performance_score': 12.3
                },
                {
                    'batch_size': 8,
                    'throughput_items_per_sec': 12.0,
                    'memory_usage_mb': 800.0,
                    'performance_score': 15.5
                }
            ]
        }
        
        report = self.benchmark.generate_benchmark_report(results)
        
        self.assertIsInstance(report, str)
        self.assertIn("Optimal batch size: 8", report)
        self.assertIn("Best performance score: 15.50", report)
        self.assertIn("Batch Size", report)
        self.assertIn("Throughput", report)


if __name__ == '__main__':
    # 创建测试套件
    test_classes = [
        TestBatchConfig,
        TestMemoryStats,
        TestMemoryMonitor,
        TestBatchSizeOptimizer,
        TestProgressTracker,
        TestBatchManager,
        TestDICOMFeatureExtractionStrategy,
        TestBatchProcessingFactory,
        TestBatchProcessingUtils,
        TestPerformanceBenchmark
    ]
    
    loader = unittest.TestLoader()
    suites = [loader.loadTestsFromTestCase(test_class) for test_class in test_classes]
    combined_suite = unittest.TestSuite(suites)
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(combined_suite)
    
    # 输出结果
    if result.wasSuccessful():
        print(f"\nAll batch processing tests passed ({result.testsRun} tests)")
    else:
        print(f"\nBatch processing tests failed: {len(result.failures)} failures, {len(result.errors)} errors")
        
        for failure in result.failures:
            print(f"\nFailure: {failure[0]}")
            print(failure[1])
        
        for error in result.errors:
            print(f"\nError: {error[0]}")
            print(error[1])