# -*- coding: utf-8 -*-
"""
Pipeline system unit tests

Test the complete pipeline orchestration functionality.
"""

import unittest
import tempfile
import shutil
import os
from pathlib import Path
import numpy as np
from datetime import datetime
from unittest.mock import Mock, patch, MagicMock
import time

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.core.pipeline import (
    DICOMFeaturePipeline, PipelineConfig, FileScanStage, 
    ComponentInitializationStage, FeatureExtractionStage, OutputStage,
    StageResult, PipelineResult
)
from src.core.interfaces import ExtractionResult
from src.core.logger import log_manager
from src.output.data_structures import OutputFormat, CompressionType


class TestPipelineConfig(unittest.TestCase):
    """测试流水线配置"""
    
    def test_pipeline_config_creation(self):
        """测试流水线配置创建"""
        config = PipelineConfig(
            input_directory="/test/input",
            output_directory="/test/output"
        )
        
        self.assertEqual(config.input_directory, "/test/input")
        self.assertEqual(config.output_directory, "/test/output")
        self.assertEqual(config.target_layer, "layer4.2.conv3")
        self.assertEqual(config.image_size, (224, 224))
        self.assertTrue(config.continue_on_error)
        self.assertEqual(config.max_error_rate, 0.5)


class TestStageResult(unittest.TestCase):
    """测试阶段结果"""
    
    def test_stage_result_properties(self):
        """测试阶段结果属性"""
        result = StageResult(
            stage_name="test_stage",
            success=True,
            execution_time=2.5,
            items_processed=100,
            items_succeeded=95,
            items_failed=5
        )
        
        self.assertEqual(result.success_rate, 0.95)
        self.assertEqual(result.processing_rate, 40.0)  # 100/2.5
        self.assertEqual(result.stage_name, "test_stage")


class TestFileScanStage(unittest.TestCase):
    """测试文件扫描阶段"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.temp_dir = tempfile.mkdtemp()
        self.stage = FileScanStage()
        
        # 创建测试文件
        test_files = ["test1.dcm", "test2.DCM", "test3.dcm"]
        for filename in test_files:
            test_file = Path(self.temp_dir) / filename
            test_file.write_text("dummy dicom content")
    
    def tearDown(self):
        """测试清理"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_stage_info(self):
        """测试阶段信息"""
        info = self.stage.get_stage_info()
        self.assertEqual(info.name, "file_scan")
        self.assertTrue(info.is_critical)
        self.assertEqual(info.retry_count, 2)
    
    def test_execute_success(self):
        """测试成功执行文件扫描"""
        config = PipelineConfig(
            input_directory=self.temp_dir,
            output_directory="/tmp/output"
        )
        context = {}
        
        result = self.stage.execute(context, config)
        
        self.assertTrue(result.success)
        self.assertEqual(result.items_processed, 3)
        self.assertEqual(result.items_succeeded, 3)
        self.assertEqual(result.items_failed, 0)
        self.assertIn('input_files', context)
        self.assertEqual(len(context['input_files']), 3)
    
    def test_execute_directory_not_found(self):
        """测试目录不存在的情况"""
        config = PipelineConfig(
            input_directory="/nonexistent/directory",
            output_directory="/tmp/output"
        )
        context = {}
        
        result = self.stage.execute(context, config)
        
        self.assertFalse(result.success)
        self.assertGreater(len(result.error_messages), 0)
    
    def test_recursive_scan(self):
        """测试递归扫描"""
        # 创建子目录和文件
        sub_dir = Path(self.temp_dir) / "subdir"
        sub_dir.mkdir()
        (sub_dir / "sub_test.dcm").write_text("dummy content")
        
        config = PipelineConfig(
            input_directory=self.temp_dir,
            output_directory="/tmp/output",
            recursive_scan=True
        )
        context = {}
        
        result = self.stage.execute(context, config)
        
        self.assertTrue(result.success)
        self.assertEqual(result.items_processed, 4)  # 3原有文件 + 1子目录文件


class TestComponentInitializationStage(unittest.TestCase):
    """测试组件初始化阶段"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.stage = ComponentInitializationStage()
    
    def test_stage_info(self):
        """测试阶段信息"""
        info = self.stage.get_stage_info()
        self.assertEqual(info.name, "component_init")
        self.assertTrue(info.is_critical)
        self.assertEqual(info.retry_count, 1)
    
    @patch('src.data.loaders.DICOMLoaderFactory.create_standard_loader')
    @patch('src.data.preprocessors.PreprocessorFactory.create_resnet_preprocessor')
    @patch('src.models.feature_extractors.FeatureExtractorFactory.create_resnet50_extractor')
    @patch('src.processing.batch_factory.BatchProcessingFactory.create_batch_manager')
    @patch('src.processing.batch_factory.BatchProcessingFactory.create_dicom_processing_strategy')
    @patch('src.output.output_manager.FeatureOutputManager')
    def test_execute_success(self, mock_output_manager, mock_strategy, mock_batch,
                           mock_extractor, mock_preprocessor, mock_loader):
        """测试成功执行组件初始化"""
        # 设置模拟对象
        mock_loader.return_value = Mock()
        mock_preprocessor.return_value = Mock()
        mock_extractor.return_value = Mock(device='cpu')
        mock_batch.return_value = Mock()
        mock_strategy.return_value = Mock()
        mock_output_manager.return_value = Mock()
        
        config = PipelineConfig(
            input_directory="/test/input",
            output_directory="/test/output"
        )
        context = {}
        
        result = self.stage.execute(context, config)
        
        self.assertTrue(result.success)
        self.assertEqual(result.items_processed, 6)
        self.assertEqual(result.items_succeeded, 6)
        
        # 验证上下文中包含所有组件
        expected_components = [
            'dicom_loader', 'preprocessor', 'feature_extractor',
            'batch_manager', 'output_manager', 'processing_strategy'
        ]
        for component in expected_components:
            self.assertIn(component, context)
    
    @patch('src.data.loaders.DICOMLoaderFactory.create_standard_loader')
    def test_execute_partial_failure(self, mock_loader):
        """测试部分组件初始化失败"""
        # 设置加载器失败
        mock_loader.side_effect = Exception("Loader initialization failed")
        
        config = PipelineConfig(
            input_directory="/test/input",
            output_directory="/test/output"
        )
        context = {}
        
        result = self.stage.execute(context, config)
        
        self.assertFalse(result.success)
        self.assertGreater(len(result.error_messages), 0)


class TestFeatureExtractionStage(unittest.TestCase):
    """测试特征提取阶段"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.stage = FeatureExtractionStage()
    
    def test_stage_info(self):
        """测试阶段信息"""
        info = self.stage.get_stage_info()
        self.assertEqual(info.name, "feature_extraction")
        self.assertTrue(info.is_critical)
        self.assertEqual(info.timeout_seconds, 3600)
    
    def test_execute_missing_components(self):
        """测试缺少必要组件时的处理"""
        config = PipelineConfig(
            input_directory="/test/input",
            output_directory="/test/output"
        )
        context = {'input_files': ['test1.dcm', 'test2.dcm']}
        
        result = self.stage.execute(context, config)
        
        self.assertFalse(result.success)
        self.assertGreater(len(result.error_messages), 0)
    
    def test_execute_no_input_files(self):
        """测试没有输入文件时的处理"""
        config = PipelineConfig(
            input_directory="/test/input",
            output_directory="/test/output"
        )
        context = {
            'input_files': [],
            'batch_manager': Mock(),
            'processing_strategy': Mock()
        }
        
        result = self.stage.execute(context, config)
        
        self.assertFalse(result.success)
        self.assertGreater(len(result.error_messages), 0)
    
    def test_execute_success(self):
        """测试成功执行特征提取"""
        # 创建模拟的批处理结果
        mock_batch_results = [
            {
                'file_path': 'test1.dcm',
                'features': np.random.randn(2048),
                'feature_shape': (2048,),
                'metadata': {'test': 'data'}
            },
            {
                'file_path': 'test2.dcm',
                'features': np.random.randn(2048),
                'feature_shape': (2048,),
                'metadata': {'test': 'data'}
            }
        ]
        
        mock_batch_manager = Mock()
        mock_batch_manager.process_batch.return_value = mock_batch_results
        
        config = PipelineConfig(
            input_directory="/test/input",
            output_directory="/test/output"
        )
        context = {
            'input_files': ['test1.dcm', 'test2.dcm'],
            'batch_manager': mock_batch_manager,
            'processing_strategy': Mock()
        }
        
        result = self.stage.execute(context, config)
        
        self.assertTrue(result.success)
        self.assertEqual(result.items_processed, 2)
        self.assertEqual(result.items_succeeded, 2)
        self.assertIn('feature_dataset', context)
        
        # 验证批处理管理器被正确调用
        mock_batch_manager.start_processing_session.assert_called_once_with(2)
        mock_batch_manager.end_processing_session.assert_called_once()


class TestOutputStage(unittest.TestCase):
    """测试输出阶段"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.stage = OutputStage()
        self.temp_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        """测试清理"""
        shutil.rmtree(self.temp_dir, ignore_errors=True)
    
    def test_stage_info(self):
        """测试阶段信息"""
        info = self.stage.get_stage_info()
        self.assertEqual(info.name, "output")
        self.assertFalse(info.is_critical)  # 输出失败不算致命
        self.assertEqual(info.retry_count, 2)
    
    def test_execute_missing_dataset(self):
        """测试缺少特征数据集时的处理"""
        config = PipelineConfig(
            input_directory="/test/input",
            output_directory=self.temp_dir
        )
        context = {'output_manager': Mock()}
        
        result = self.stage.execute(context, config)
        
        self.assertFalse(result.success)
        self.assertGreater(len(result.error_messages), 0)
    
    def test_execute_success(self):
        """测试成功执行输出"""
        from src.output.data_structures import FeatureDataset, FeatureRecord, OutputResult
        
        # 创建模拟特征数据集
        records = []
        for i in range(2):
            record = FeatureRecord(
                file_path=f"test_{i}.dcm",
                features=np.random.randn(100),
                feature_dimensions=(100,),
                metadata={},
                extraction_timestamp=datetime.now(),
                processing_time=1.0,
                success=True
            )
            records.append(record)
        
        dataset = FeatureDataset(records)
        
        # 创建模拟输出管理器
        mock_output_manager = Mock()
        mock_output_results = {
            'numpy': OutputResult(
                success=True,
                output_files=[str(Path(self.temp_dir) / "features.npy")],
                metadata_files=[],
                total_records=2,
                successful_records=2,
                failed_records=0,
                output_size_bytes=1024,
                processing_time=0.5
            )
        }
        mock_output_manager.save_features_multi_format.return_value = mock_output_results
        
        config = PipelineConfig(
            input_directory="/test/input",
            output_directory=self.temp_dir,
            output_formats=[OutputFormat.NUMPY]
        )
        context = {
            'feature_dataset': dataset,
            'output_manager': mock_output_manager
        }
        
        result = self.stage.execute(context, config)
        
        self.assertTrue(result.success)
        self.assertEqual(result.items_processed, 1)  # 1种输出格式
        self.assertEqual(result.items_succeeded, 1)
        self.assertIn('output_files', context)


class TestDICOMFeaturePipeline(unittest.TestCase):
    """测试DICOM特征提取流水线"""
    
    def setUp(self):
        """测试设置"""
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.temp_input_dir = tempfile.mkdtemp(prefix="pipeline_input_")
        self.temp_output_dir = tempfile.mkdtemp(prefix="pipeline_output_")
        
        # 创建测试DICOM文件
        test_files = ["test1.dcm", "test2.dcm"]
        for filename in test_files:
            test_file = Path(self.temp_input_dir) / filename
            test_file.write_text("dummy dicom content")
        
        self.pipeline = DICOMFeaturePipeline()
    
    def tearDown(self):
        """测试清理"""
        shutil.rmtree(self.temp_input_dir, ignore_errors=True)
        shutil.rmtree(self.temp_output_dir, ignore_errors=True)
    
    def test_pipeline_initialization(self):
        """测试流水线初始化"""
        self.assertIsNotNone(self.pipeline)
        self.assertEqual(len(self.pipeline.stages), 4)
        self.assertIsInstance(self.pipeline.stages[0], FileScanStage)
        self.assertIsInstance(self.pipeline.stages[1], ComponentInitializationStage)
        self.assertIsInstance(self.pipeline.stages[2], FeatureExtractionStage)
        self.assertIsInstance(self.pipeline.stages[3], OutputStage)
    
    def test_create_pipeline_config(self):
        """测试创建流水线配置"""
        config_dict = {
            'target_layer': 'layer4.2.conv3',
            'image_size': [256, 256],
            'batch_size': 16,
            'output_formats': ['numpy', 'json']
        }
        
        pipeline_config = self.pipeline._create_pipeline_config(
            self.temp_input_dir, self.temp_output_dir, config_dict
        )
        
        self.assertEqual(pipeline_config.input_directory, self.temp_input_dir)
        self.assertEqual(pipeline_config.output_directory, self.temp_output_dir)
        self.assertEqual(pipeline_config.target_layer, 'layer4.2.conv3')
        self.assertEqual(pipeline_config.image_size, (256, 256))
        self.assertEqual(pipeline_config.batch_size, 16)
        self.assertEqual(len(pipeline_config.output_formats), 2)
    
    @patch.object(FileScanStage, 'execute')
    def test_execute_pipeline_stage_failure(self, mock_scan_execute):
        """测试关键阶段失败时的处理"""
        # 设置文件扫描阶段失败
        mock_scan_execute.return_value = StageResult(
            stage_name="file_scan",
            success=False,
            execution_time=1.0,
            items_processed=0,
            items_succeeded=0,
            items_failed=1,
            error_messages=["Scan failed"]
        )
        
        config = {
            'target_layer': 'layer4.2.conv3',
            'output_formats': ['numpy']
        }
        
        result = self.pipeline.execute_pipeline(
            self.temp_input_dir, self.temp_output_dir, config
        )
        
        self.assertIsInstance(result, ExtractionResult)
        self.assertEqual(result.successful_extractions, 0)
        self.assertGreater(len(result.error_log), 0)
    
    def test_validate_pipeline_components(self):
        """测试验证流水线组件"""
        # 这个测试可能会因为依赖项而失败，但应该不会抛出异常
        is_valid = self.pipeline.validate_pipeline_components()
        self.assertIsInstance(is_valid, bool)
    
    def test_convert_to_extraction_result(self):
        """测试转换为提取结果格式"""
        stage_results = [
            StageResult(
                stage_name="file_scan",
                success=True,
                execution_time=1.0,
                items_processed=2,
                items_succeeded=2,
                items_failed=0
            ),
            StageResult(
                stage_name="feature_extraction",
                success=True,
                execution_time=5.0,
                items_processed=2,
                items_succeeded=2,
                items_failed=0
            )
        ]
        
        pipeline_result = PipelineResult(
            success=True,
            total_execution_time=10.0,
            stage_results=stage_results,
            input_files_found=2,
            input_files_processed=2,
            features_extracted=2,
            output_files_created=["features.npy"],
            error_summary={},
            warnings=[]
        )
        
        extraction_result = self.pipeline._convert_to_extraction_result(pipeline_result)
        
        self.assertIsInstance(extraction_result, ExtractionResult)
        self.assertEqual(extraction_result.total_images, 2)
        self.assertEqual(extraction_result.successful_extractions, 2)
        self.assertEqual(extraction_result.failed_extractions, 0)
        self.assertEqual(extraction_result.processing_time, 10.0)
        self.assertEqual(len(extraction_result.output_files), 1)


if __name__ == '__main__':
    # 创建测试套件
    test_classes = [
        TestPipelineConfig,
        TestStageResult,
        TestFileScanStage,
        TestComponentInitializationStage,
        TestFeatureExtractionStage,
        TestOutputStage,
        TestDICOMFeaturePipeline
    ]
    
    loader = unittest.TestLoader()
    suites = [loader.loadTestsFromTestCase(test_class) for test_class in test_classes]
    combined_suite = unittest.TestSuite(suites)
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(combined_suite)
    
    # 输出结果
    if result.wasSuccessful():
        print(f"\nAll pipeline tests passed ({result.testsRun} tests)")
    else:
        print(f"\nPipeline tests failed: {len(result.failures)} failures, {len(result.errors)} errors")
        
        for failure in result.failures:
            print(f"\nFailure: {failure[0]}")
            print(failure[1])
        
        for error in result.errors:
            print(f"\nError: {error[0]}")
            print(error[1])