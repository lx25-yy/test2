# -*- coding: utf-8 -*-
"""
DICOM Loader Unit Tests

Test various functions of DICOMLoader to ensure compliance with interface specifications and error handling requirements.
"""

import unittest
import tempfile
import shutil
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock
import numpy as np
import pydicom
from pydicom.dataset import FileDataset
from pydicom.datadict import DicomDictionary
from pydicom.uid import ImplicitVRLittleEndian

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.loaders import DICOMLoader, DICOMLoaderFactory
from src.core.interfaces import DICOMImage
from src.core.exceptions import DICOMLoadError, DICOMValidationError
from src.core.logger import log_manager


class TestDICOMLoader(unittest.TestCase):
    """DICOM加载器测试类"""
    
    def setUp(self):
        """测试前准备"""
        # 配置测试日志
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        # 创建临时测试目录
        self.test_dir = Path(tempfile.mkdtemp())
        
        # 创建DICOM加载器实例
        self.loader = DICOMLoader(validate_on_load=True, force_pixel_data=True)
        
        # 创建测试DICOM数据集
        self.test_dataset = self._create_test_dicom_dataset()
        
    def tearDown(self):
        """测试后清理"""
        # 清理临时目录
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def _create_test_dicom_dataset(self) -> FileDataset:
        """创建测试用的DICOM数据集"""
        # 创建基本的DICOM数据集
        file_meta = pydicom.Dataset()
        file_meta.MediaStorageSOPClassUID = "1.2.840.10008.5.1.4.1.1.2"
        file_meta.MediaStorageSOPInstanceUID = "1.2.3.4.5.6.7.8.9"
        file_meta.TransferSyntaxUID = ImplicitVRLittleEndian
        
        dataset = FileDataset("test", {}, file_meta=file_meta, preamble=b"\0" * 128)
        
        # 添加必需的标签
        dataset.SOPClassUID = "1.2.840.10008.5.1.4.1.1.2"
        dataset.SOPInstanceUID = "1.2.3.4.5.6.7.8.9"
        dataset.StudyInstanceUID = "1.2.3.4.5.6.7.8"
        dataset.SeriesInstanceUID = "1.2.3.4.5.6.7"
        dataset.PatientID = "TEST001"
        dataset.PatientName = "Test^Patient"
        dataset.Modality = "CT"
        dataset.StudyDate = "20240101"
        dataset.SeriesDate = "20240101"
        
        # 添加图像信息
        dataset.Rows = 256
        dataset.Columns = 256
        dataset.BitsAllocated = 16
        dataset.BitsStored = 16
        dataset.SamplesPerPixel = 1
        dataset.PhotometricInterpretation = "MONOCHROME2"
        dataset.PixelSpacing = [1.0, 1.0]
        
        # 创建测试像素数据
        pixel_data = np.random.randint(0, 4096, (256, 256), dtype=np.uint16)
        dataset.PixelData = pixel_data.tobytes()
        
        return dataset
    
    def _save_test_dicom(self, filename: str, dataset: FileDataset = None) -> Path:
        """保存测试DICOM文件"""
        if dataset is None:
            dataset = self.test_dataset
        
        file_path = self.test_dir / filename
        dataset.save_as(str(file_path))
        return file_path
    
    def test_load_valid_dicom_file(self):
        """测试加载有效的DICOM文件"""
        # 保存测试文件
        test_file = self._save_test_dicom("test.dcm")
        
        # 加载文件
        dicom_image = self.loader.load_dicom_file(str(test_file))
        
        # 验证结果
        self.assertIsInstance(dicom_image, DICOMImage)
        self.assertEqual(dicom_image.file_path, str(test_file))
        self.assertIsInstance(dicom_image.pixel_data, np.ndarray)
        self.assertEqual(dicom_image.modality, "CT")
        self.assertEqual(dicom_image.patient_id, "TEST001")
        self.assertIsInstance(dicom_image.metadata, dict)
        
        # 验证像素数据形状
        self.assertEqual(len(dicom_image.pixel_data.shape), 3)  # (height, width, channels)
    
    def test_load_nonexistent_file(self):
        """测试加载不存在的文件"""
        nonexistent_file = self.test_dir / "nonexistent.dcm"
        
        with self.assertRaises(DICOMLoadError) as context:
            self.loader.load_dicom_file(str(nonexistent_file))
        
        self.assertIn("文件不存在", str(context.exception))
    
    def test_load_invalid_dicom_file(self):
        """测试加载无效的DICOM文件"""
        # 创建无效文件
        invalid_file = self.test_dir / "invalid.dcm"
        with open(invalid_file, 'w') as f:
            f.write("This is not a DICOM file")
        
        with self.assertRaises(DICOMLoadError) as context:
            self.loader.load_dicom_file(str(invalid_file))
        
        self.assertIn("无效的DICOM文件", str(context.exception))
    
    def test_load_dicom_without_pixel_data(self):
        """测试加载没有像素数据的DICOM文件"""
        # 创建没有像素数据的数据集
        dataset_no_pixels = self.test_dataset.copy()
        del dataset_no_pixels.PixelData
        
        test_file = self._save_test_dicom("no_pixels.dcm", dataset_no_pixels)
        
        with self.assertRaises(DICOMLoadError) as context:
            self.loader.load_dicom_file(str(test_file))
        
        self.assertIn("像素数据", str(context.exception))
    
    def test_validate_dicom_valid_file(self):
        """测试验证有效的DICOM文件"""
        test_file = self._save_test_dicom("valid.dcm")
        
        result = self.loader.validate_dicom(str(test_file))
        
        self.assertTrue(result)
    
    def test_validate_dicom_invalid_file(self):
        """测试验证无效文件"""
        # 测试不存在的文件
        result = self.loader.validate_dicom(str(self.test_dir / "nonexistent.dcm"))
        self.assertFalse(result)
        
        # 测试无效的DICOM文件
        invalid_file = self.test_dir / "invalid.dcm"
        with open(invalid_file, 'w') as f:
            f.write("Not a DICOM file")
        
        result = self.loader.validate_dicom(str(invalid_file))
        self.assertFalse(result)
    
    def test_scan_directory_with_dicom_files(self):
        """测试扫描包含DICOM文件的目录"""
        # 创建多个测试文件
        test_files = []
        for i in range(3):
            test_file = self._save_test_dicom(f"test_{i}.dcm")
            test_files.append(str(test_file))
        
        # 创建非DICOM文件
        (self.test_dir / "not_dicom.txt").write_text("Not a DICOM file")
        
        # 扫描目录
        found_files = self.loader.scan_directory(str(self.test_dir))
        
        # 验证结果
        self.assertEqual(len(found_files), 3)
        for test_file in test_files:
            self.assertIn(test_file, found_files)
    
    def test_scan_empty_directory(self):
        """测试扫描空目录"""
        empty_dir = self.test_dir / "empty"
        empty_dir.mkdir()
        
        found_files = self.loader.scan_directory(str(empty_dir))
        
        self.assertEqual(len(found_files), 0)
    
    def test_scan_nonexistent_directory(self):
        """测试扫描不存在的目录"""
        nonexistent_dir = self.test_dir / "nonexistent"
        
        with self.assertRaises(DICOMLoadError) as context:
            self.loader.scan_directory(str(nonexistent_dir))
        
        self.assertIn("目录不存在", str(context.exception))
    
    def test_load_batch(self):
        """测试批量加载文件"""
        # 创建多个测试文件
        test_files = []
        for i in range(3):
            test_file = self._save_test_dicom(f"batch_{i}.dcm")
            test_files.append(str(test_file))
        
        # 添加一个不存在的文件
        test_files.append(str(self.test_dir / "nonexistent.dcm"))
        
        # 批量加载
        loaded_images, errors = self.loader.load_batch(test_files)
        
        # 验证结果
        self.assertEqual(len(loaded_images), 3)  # 3个成功
        self.assertEqual(len(errors), 1)         # 1个失败
        
        for dicom_image in loaded_images:
            self.assertIsInstance(dicom_image, DICOMImage)
    
    def test_statistics(self):
        """测试统计信息"""
        # 重置统计信息
        self.loader.reset_statistics()
        
        # 创建测试文件
        test_file = self._save_test_dicom("stats_test.dcm")
        
        # 加载文件
        self.loader.load_dicom_file(str(test_file))
        
        # 检查统计信息
        stats = self.loader.get_statistics()
        
        self.assertEqual(stats['files_processed'], 1)
        self.assertEqual(stats['files_loaded'], 1)
        self.assertEqual(stats['files_failed'], 0)
        self.assertEqual(stats['success_rate'], 1.0)
    
    def test_metadata_extraction(self):
        """测试元数据提取"""
        test_file = self._save_test_dicom("metadata_test.dcm")
        
        dicom_image = self.loader.load_dicom_file(str(test_file))
        
        # 验证元数据
        metadata = dicom_image.metadata
        
        self.assertIn('patient_id', metadata)
        self.assertIn('modality', metadata)
        self.assertIn('study_date', metadata)
        self.assertIn('height', metadata)
        self.assertIn('width', metadata)
        
        self.assertEqual(metadata['patient_id'], 'TEST001')
        self.assertEqual(metadata['modality'], 'CT')
        self.assertEqual(metadata['height'], 256)
        self.assertEqual(metadata['width'], 256)
    
    def test_pixel_data_processing(self):
        """测试像素数据处理"""
        test_file = self._save_test_dicom("pixel_test.dcm")
        
        dicom_image = self.loader.load_dicom_file(str(test_file))
        
        # 验证像素数据
        pixel_data = dicom_image.pixel_data
        
        self.assertIsInstance(pixel_data, np.ndarray)
        self.assertEqual(len(pixel_data.shape), 3)  # (height, width, channels)
        self.assertGreaterEqual(pixel_data.min(), 0)
        self.assertLessEqual(pixel_data.max(), 255)  # 应该被归一化到0-255
    
    def test_validation_with_missing_tags(self):
        """测试缺少必需标签的验证"""
        # 创建缺少必需标签的数据集
        incomplete_dataset = self.test_dataset.copy()
        del incomplete_dataset.SOPClassUID
        
        test_file = self._save_test_dicom("incomplete.dcm", incomplete_dataset)
        
        with self.assertRaises(DICOMValidationError) as context:
            self.loader.load_dicom_file(str(test_file))
        
        self.assertIn("SOPClassUID", str(context.exception))
    
    @patch('pydicom.dcmread')
    def test_load_with_pydicom_exception(self, mock_dcmread):
        """测试pydicom读取异常处理"""
        mock_dcmread.side_effect = Exception("读取错误")
        
        test_file = self._save_test_dicom("exception_test.dcm")
        
        with self.assertRaises(DICOMLoadError) as context:
            self.loader.load_dicom_file(str(test_file))
        
        self.assertIn("读取文件失败", str(context.exception))


class TestDICOMLoaderFactory(unittest.TestCase):
    """DICOM加载器工厂测试类"""
    
    def test_create_standard_loader(self):
        """测试创建标准加载器"""
        loader = DICOMLoaderFactory.create_standard_loader()
        
        self.assertIsInstance(loader, DICOMLoader)
        self.assertTrue(loader.validate_on_load)
        self.assertTrue(loader.force_pixel_data)
    
    def test_create_fast_loader(self):
        """测试创建快速加载器"""
        loader = DICOMLoaderFactory.create_fast_loader()
        
        self.assertIsInstance(loader, DICOMLoader)
        self.assertFalse(loader.validate_on_load)
        self.assertTrue(loader.force_pixel_data)
    
    def test_create_metadata_only_loader(self):
        """测试创建仅元数据加载器"""
        loader = DICOMLoaderFactory.create_metadata_only_loader()
        
        self.assertIsInstance(loader, DICOMLoader)
        self.assertTrue(loader.validate_on_load)
        self.assertFalse(loader.force_pixel_data)
    
    def test_create_custom_loader(self):
        """测试创建自定义加载器"""
        loader = DICOMLoaderFactory.create_custom_loader(
            validate_on_load=False,
            force_pixel_data=False
        )
        
        self.assertIsInstance(loader, DICOMLoader)
        self.assertFalse(loader.validate_on_load)
        self.assertFalse(loader.force_pixel_data)


class TestDICOMLoaderIntegration(unittest.TestCase):
    """DICOM加载器集成测试"""
    
    def setUp(self):
        """测试前准备"""
        # 配置测试日志
        from src.core.config import LoggingConfig
        log_config = LoggingConfig(log_level="ERROR", console_output=False)
        log_manager.configure_logging(log_config)
        
        self.test_dir = Path(tempfile.mkdtemp())
        self.loader = DICOMLoader()
    
    def tearDown(self):
        """测试后清理"""
        if self.test_dir.exists():
            shutil.rmtree(self.test_dir)
    
    def test_real_dicom_workflow(self):
        """测试真实的DICOM工作流程"""
        # 这个测试需要真实的DICOM文件，在这里我们模拟一个完整的工作流程
        
        # 1. 检查当前目录是否有DICOM文件
        current_dir = Path(".")
        dicom_files = []
        
        # 查找.dcm文件
        for dcm_file in current_dir.glob("*.dcm"):
            if dcm_file.is_file():
                dicom_files.append(str(dcm_file))
        
        if not dicom_files:
            self.skipTest("没有找到真实的DICOM文件进行集成测试")
        
        # 2. 扫描目录
        try:
            found_files = self.loader.scan_directory(str(current_dir))
            self.assertGreater(len(found_files), 0)
        except Exception as e:
            self.fail(f"目录扫描失败: {e}")
        
        # 3. 批量加载（限制数量以避免测试时间过长）
        test_files = found_files[:3]  # 只测试前3个文件
        
        try:
            loaded_images, errors = self.loader.load_batch(test_files)
            
            # 验证加载结果
            self.assertGreater(len(loaded_images), 0)
            
            for dicom_image in loaded_images:
                self.assertIsInstance(dicom_image, DICOMImage)
                self.assertIsInstance(dicom_image.pixel_data, np.ndarray)
                self.assertIsInstance(dicom_image.metadata, dict)
                
        except Exception as e:
            self.fail(f"批量加载失败: {e}")
        
        # 4. 检查统计信息
        stats = self.loader.get_statistics()
        self.assertGreaterEqual(stats['files_processed'], len(test_files))


if __name__ == '__main__':
    # 创建测试套件
    loader_suite = unittest.TestLoader().loadTestsFromTestCase(TestDICOMLoader)
    factory_suite = unittest.TestLoader().loadTestsFromTestCase(TestDICOMLoaderFactory)
    integration_suite = unittest.TestLoader().loadTestsFromTestCase(TestDICOMLoaderIntegration)
    
    # 合并测试套件
    combined_suite = unittest.TestSuite([loader_suite, factory_suite, integration_suite])
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(combined_suite)
    
    # Output test results
    if result.wasSuccessful():
        print(f"\nAll tests passed ({result.testsRun} tests)")
    else:
        print(f"\nTests failed: {len(result.failures)} failures, {len(result.errors)} errors")
        
        for failure in result.failures:
            print(f"\nFailure: {failure[0]}")
            print(failure[1])
        
        for error in result.errors:
            print(f"\nError: {error[0]}")
            print(error[1])